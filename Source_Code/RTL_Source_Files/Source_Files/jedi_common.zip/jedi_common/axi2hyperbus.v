

module axi2hyperbus # (parameter idw = 7) (
// Global inputs
input             clk         ,
input             resetn      ,

// HyperBUS I/O
output reg      o_hr_csb      ,
output reg      o_hr_rwds_z   ,
output reg [1:0]o_hr_rwds_o   ,
output reg      o_hr_dq_z     ,
output reg[15:0]o_hr_dq_o     ,

input  [1:0]    i_hr_rwds_i   ,
input  [15:0]   i_hr_dq_i     ,

// AXI Slave port
// Read Address Channel
input     [idw:0] ARID        ,
input      [31:0] ARADDR      ,
input       [3:0] ARREGION    , // ignore
input       [7:0] ARLEN       ,
input       [2:0] ARSIZE      , // ignore
input       [1:0] ARBURST     , // ignore
input             ARLOCK      , // ignore
input       [3:0] ARCACHE     , // ignore
input       [2:0] ARPROT      , // ignore
input       [3:0] ARQOS       , // ignore
input             ARVALID     ,
output reg        ARREADY     ,
// Read Channel
output    [idw:0] RID         ,
output     [63:0] RDATA       ,
output      [1:0] RRESP       , // 0
output reg        RLAST       ,
output reg        RVALID      ,
input             RREADY      ,

// Write Address Channel
input     [idw:0] AWID        ,
input      [31:0] AWADDR      ,
input       [3:0] AWREGION    , // ignore
input       [7:0] AWLEN       ,
input       [2:0] AWSIZE      , // ignore
input       [1:0] AWBURST     , // ignore
input             AWLOCK      , // ignore
input       [3:0] AWCACHE     , // ignore
input       [2:0] AWPROT      , // ignore
input       [3:0] AWQOS       , // ignore
input             AWVALID     ,
output reg        AWREADY     ,
// Write Channel
input     [idw:0] WID         ,
input      [63:0] WDATA       ,
input       [7:0] WSTRB       , // ignore
input             WLAST       ,
input             WVALID      ,
output            WREADY      ,
// Write Response Channel
output    [idw:0] BID         ,
output      [1:0] BRESP       , // 0
output reg        BVALID      ,
input             BREADY 
);

reg		write_rdy; // write ready, store all write data
reg		write_cmd_rdy; // capture write AXI command
reg		read_rdy;  // read ready
reg		read_cmd_rdy;  // capture read AXI command
reg	[8:0]	write_len;
reg	[8:0]	read_len;
reg	[31:0]	write_addr;
reg	[31:0]	read_addr;

wire	[15:0]	wr_fifo_out;
wire	[15:0]	rd_fifo_in;

reg	[7:0]	hr_dq_i_d; // latch lsb only
reg		half_delay; // rwds_i == 01

wire		rd_fifo_wren;
wire		rd_fifo_rden;
wire		rd_fifo_full;
wire		rd_fifo_empty;
wire		rd_fifo_amfull;
wire	[63:0]	rd_fifo_dout;
reg	[7:0]	rd_cnt;

reg	[4:0]	gap_cnt;

reg	[10:0]	rfill_cnt;

wire		wr_fifo_wren;
wire		wr_fifo_rden;
wire		wr_fifo_full;
wire		wr_fifo_empty;
wire		wr_fifo_amfull;

// state machine
parameter [3:0] 
	S_INIT    = 4'b0000, // initialize
	S_WAIT    = 4'b0001, // wait for command
	S_WCMD0   = 4'b0010, // write command0
	S_WCMD1   = 4'b0011, // write command1
	S_WCMD2   = 4'b0100, // write command2
	S_WGAP    = 4'b0101, // wait write GAP
	S_WDO     = 4'b0110, // Data writing
	S_RCMD0   = 4'b1010, // read command0
	S_RCMD1   = 4'b1011, // read command1
	S_RCMD2   = 4'b1100, // read command2
	S_RGAP    = 4'b1101, // wait read GAP
	S_RFILL   = 4'b1110, // fill fifo
	S_RFILLD  = 4'b1001, // half delay 
	S_RDO     = 4'b1111; // Data reading

reg     [3:0]   state;
reg     [3:0]   nstate;

// constant
parameter [4:0] C_WGAP = 5'd9;
parameter [4:0] C_RGAP = 5'd16;

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	state <= S_INIT;
    else               
	state <= nstate;
end

always @(*)
begin
    case(state)
	S_INIT:
	    nstate = S_WAIT;
	S_WAIT:
	    nstate = write_rdy ? S_WCMD0 : read_rdy ? S_RCMD0 : S_WAIT;
	S_WCMD0:
	    nstate = S_WCMD1;
	S_WCMD1:
	    nstate = S_WCMD2;
	S_WCMD2:
	    nstate = S_WGAP;
	S_WGAP:
	    nstate = (gap_cnt == C_WGAP) ? S_WDO : S_WGAP;
	S_WDO:
	    nstate = wr_fifo_empty ? S_WAIT : S_WDO;
	S_RCMD0:
	    nstate = S_RCMD1;
	S_RCMD1:
	    nstate = S_RCMD2;
	S_RCMD2:
	    nstate = S_RGAP;
	S_RGAP:
	    nstate = (gap_cnt == C_RGAP) ? S_RFILL : S_RGAP;
	S_RFILL:
	    nstate = (rfill_cnt[10:2] == read_len) ? ((half_delay == 1'b1) ? S_RFILLD : S_RDO) : S_RFILL;
	S_RFILLD:
	    nstate = S_RDO;
	S_RDO:
	    nstate = (rd_fifo_rden && (rd_cnt == 8'd0)) ?  S_WAIT : S_RDO;
	default:
	    nstate = S_INIT;
    endcase
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	gap_cnt <= 5'd0;
    else if((state == S_WGAP) || (state == S_RGAP))
	gap_cnt <= gap_cnt + 5'd1;
    else
	gap_cnt <= 5'd0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	rfill_cnt <= 11'd1;
    else if(state == S_RFILL)
	rfill_cnt <= rfill_cnt + 11'd1;
    else
	rfill_cnt <= 11'd1;
end

// HyperBUS drive {{{

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	o_hr_csb <= 1'b1;
    else case (state)
	S_INIT ,
        S_WAIT ,
	S_RDO  : o_hr_csb <= 1'b1;
	default: o_hr_csb <= 1'b0;
    endcase
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	o_hr_rwds_z <= 1'b1;
    else case (state)
	S_WGAP ,
	S_WDO  : o_hr_rwds_z <= 1'b0;
	default: o_hr_rwds_z <= 1'b1;
    endcase
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	o_hr_rwds_o <= 2'b0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	o_hr_dq_z <= 1'b1;
    else case (state)
	S_WCMD0,
	S_WCMD1,
	S_WCMD2,
	S_WGAP ,
	S_WDO  ,
	S_RCMD0,
	S_RCMD1,
	S_RCMD2: o_hr_dq_z <= 1'b0;
	default: o_hr_dq_z <= 1'b1;
    endcase
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	o_hr_dq_o <= 16'b0;
    else case (state)
	S_WCMD0: o_hr_dq_o <= {3'b001, 1'b0, write_addr[31:20]};
	S_WCMD1: o_hr_dq_o <= write_addr[19:4];
	S_WCMD2: o_hr_dq_o <= {13'b0, write_addr[3:1]};
	S_WDO  : o_hr_dq_o <= wr_fifo_out;
	S_RCMD0: o_hr_dq_o <= {3'b101, 1'b0, read_addr[31:20]};
	S_RCMD1: o_hr_dq_o <= read_addr[19:4];
	S_RCMD2: o_hr_dq_o <= {13'b0, read_addr[3:1]};
	default: o_hr_dq_o <= 16'b0;
    endcase
end

// HyperBUS drive }}}

// write command & data capture {{{
always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	AWREADY <= 1'b0;
    else if(state == S_INIT)
	AWREADY <= 1'b1;
    else if((state == S_WDO) && (wr_fifo_empty))
	AWREADY <= 1'b1;
    else if(AWVALID)
	AWREADY <= 1'b0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	write_cmd_rdy <= 1'b0;
    else if(AWREADY && AWVALID)
	write_cmd_rdy <= 1'b1;
    else if(state == S_WCMD0)
	write_cmd_rdy <= 1'b0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	write_addr <= 32'b0;
    else if(AWREADY && AWVALID)
	write_addr <= AWADDR;
end

wire	[8:0]	awlen_p1;
assign awlen_p1 = AWLEN + 9'd1;

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	write_len <= 9'b0;
    else if(AWREADY && AWVALID)
	write_len <= awlen_p1[8:0];
end



assign wr_fifo_wren = WVALID && WREADY;

assign WREADY = (!wr_fifo_amfull) && write_cmd_rdy;

assign wr_fifo_rden = (state == S_WDO) && (!wr_fifo_empty);

axi_fifo64_16 u_axi_fifo_wr(
    .wr_data_i    (WDATA          ),
    .rd_data_o    (wr_fifo_out    ),
    .almost_full_o(wr_fifo_amfull ),
    .wr_clk_i     (clk            ),
    .rd_clk_i     (clk            ),
    .empty_o      (wr_fifo_empty  ),
    .full_o       (wr_fifo_full   ),
    .rd_en_i      (wr_fifo_rden   ),
    .rst_i        (!resetn        ),
    .rp_rst_i     (!resetn        ),
    .wr_en_i      (wr_fifo_wren   )
);

reg	[idw:0]	wid_lat;

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	wid_lat <= 0;
    else if(AWREADY && AWVALID)
	wid_lat <= AWID;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	write_rdy <= 1'b0;
    else if(WVALID && WREADY && WLAST)
	write_rdy <= 1'b1;
    else if(state == S_WCMD0)
	write_rdy <= 1'b0;
end

assign BID = wid_lat;
assign BRESP  = 2'b0;

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	BVALID <= 1'b0;
    else if(WVALID && WREADY && WLAST)
	BVALID <= 1'b1;
    else if(BREADY)
	BVALID <= 1'b0;
end

// write command & data capture }}}

// read command & data handle {{{
reg	[idw:0]	rid_lat;

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	ARREADY <= 1'b0;
    else if(state == S_INIT)
	ARREADY <= 1'b1;
    else if(RREADY && RVALID && RLAST)
	ARREADY <= 1'b1;
    else if(ARVALID)
	ARREADY <= 1'b0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	read_cmd_rdy <= 1'b0;
    else if(ARREADY && ARVALID)
	read_cmd_rdy <= 1'b1;
    else if(state == S_RCMD0)
	read_cmd_rdy <= 1'b0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	read_addr <= 32'b0;
    else if(ARREADY && ARVALID)
	read_addr <= ARADDR;
end

wire	[8:0]	arlen_p1;
assign arlen_p1 = ARLEN + 9'd1;

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	read_len <= 9'b0;
    else if(ARREADY && ARVALID)
	read_len <= arlen_p1[8:0];
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	rid_lat <= 0;
    else if(ARREADY && ARVALID)
	rid_lat <= ARID;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	half_delay <= 1'b0;
    else 
	half_delay <= (i_hr_rwds_i == 2'b01);
end

always @(posedge clk)
begin
    hr_dq_i_d <= i_hr_dq_i[7:0];
end


//assign rd_fifo_wren = ((state == S_RFILL) && ((i_hr_rwds_i == 2'b10) || (half_delay == 1'b1))) || (state == S_RFILLD);
assign rd_fifo_wren = ((state == S_RFILL) && ((i_hr_rwds_i != 2'b01) || (half_delay == 1'b1))) || (state == S_RFILLD);
// Handle no strobe case as aligned strobe - out-of-range access causes no strobe

assign rd_fifo_rden = (!rd_fifo_empty) && (RREADY || (!RVALID));
assign rd_fifo_in = (i_hr_rwds_i == 2'b10) ? i_hr_dq_i : {hr_dq_i_d, i_hr_dq_i[15:8]};

axi_fifo16_64 u_axi_fifo_rd(
    .wr_data_i    (rd_fifo_in     ),
    .rd_data_o    (rd_fifo_dout   ),
    .almost_full_o(rd_fifo_amfull ),
    .wr_clk_i     (clk            ),
    .rd_clk_i     (clk            ),
    .empty_o      (rd_fifo_empty  ),
    .full_o       (rd_fifo_full   ),
    .rd_en_i      (rd_fifo_rden   ),
    .rst_i        (!resetn        ),
    .rp_rst_i     (!resetn        ),
    .wr_en_i      (rd_fifo_wren   )
);

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	RVALID <= 1'b0;
    else if(rd_fifo_rden)
	RVALID <= 1'b1;
    else if(RREADY)
	RVALID <= 1'b0;
end

assign RDATA = rd_fifo_dout;

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	rd_cnt <= 8'b0;
    else if(ARREADY && ARVALID)
	rd_cnt <= ARLEN;
    else if(rd_fifo_rden)
	rd_cnt <= rd_cnt - 8'd1;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	RLAST <= 1'b0;
    else if(rd_fifo_rden && (rd_cnt == 8'd0))
	RLAST <= 1'b1;
    else if(RREADY)
	RLAST <= 1'b0;
end

always @(posedge clk or negedge resetn) 
begin
    if(resetn == 1'b0) 
	read_rdy <= 1'b0;
    else if((read_cmd_rdy == 1'b1) && (rd_fifo_empty == 1'b1))
	read_rdy <= 1'b1;
    else if(rd_fifo_empty != 1'b0)
	read_rdy <= 1'b0;
end

assign RRESP = 2'b0;
assign RID = rid_lat;

// read command & data handle }}}

endmodule

// vim:foldmethod=marker:
//
