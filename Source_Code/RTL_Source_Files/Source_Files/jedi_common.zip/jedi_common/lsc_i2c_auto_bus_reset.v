
module lsc_i2c_auto_bus_reset (
input             clk     , // 24MHz clock
input             resetn  ,

input             i_sda   ,
output            o_scl   ,

output reg        o_resetn
);

parameter [7:0]	C_PERIOD    = 8'd120; // 120 for 24MHz clock
parameter [23:0] C_TIMEOVER = 24'd2400000; // 100ms for 24MHz clock;

reg	[23:0]  stuck_cnt;
reg	[7:0]	period_cnt;
reg	[3:0]	pulse_cnt;

reg	[7:0]	rst_cnt;

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0) 
	stuck_cnt <= 24'b0;
    else if(i_sda == 1'b0)
	stuck_cnt <= stuck_cnt + 24'd1;
    else 
	stuck_cnt <= 24'b0;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0) 
	pulse_cnt <= 4'd0;
    else if(stuck_cnt == C_TIMEOVER)
	pulse_cnt <= 4'd9;
    else if((pulse_cnt != 4'd0) && (period_cnt == C_PERIOD))
	pulse_cnt <= pulse_cnt - 4'd1;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0) 
	period_cnt <= 8'd0;
    else if(pulse_cnt != 4'd0)
	period_cnt <= (period_cnt == C_PERIOD) ? 8'd0 : (period_cnt + 8'd1);
    else
	period_cnt <= 8'd0;
end

assign o_scl = (period_cnt > {1'b0, C_PERIOD[7:1]}) ? 1'b0 : 1'bz;

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0) 
	rst_cnt <= 8'd0;
    else if((pulse_cnt == 4'd1) && (period_cnt == C_PERIOD))
	rst_cnt <= 8'd0;
    else if(rst_cnt != 8'hff)
	rst_cnt <= rst_cnt + 8'd1;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0) 
	o_resetn <= 1'd0;
    else 
	o_resetn <= (rst_cnt == 8'hff);
end

endmodule
