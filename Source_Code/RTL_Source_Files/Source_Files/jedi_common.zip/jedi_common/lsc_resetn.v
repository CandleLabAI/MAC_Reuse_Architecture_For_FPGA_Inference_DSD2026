
module lsc_resetn(
input             clk    , // 4x faster clock (min)

input             i_resetn,
output reg        o_resetn
);

reg	[7:0]	rst_cnt;

always @(posedge clk or negedge i_resetn)
begin
    if(i_resetn == 1'b0) 
	rst_cnt <= 8'd0;
    else if(rst_cnt != 8'hff)
	rst_cnt <= rst_cnt + 8'd1;
end

always @(posedge clk or negedge i_resetn)
begin
    if(i_resetn == 1'b0) 
	o_resetn <= 1'd0;
    else 
	o_resetn <= (rst_cnt == 8'hff);
end

endmodule
