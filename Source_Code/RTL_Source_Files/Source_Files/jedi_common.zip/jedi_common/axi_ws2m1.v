

module axi_ws2m1 # (parameter dw = 63, idw = 3, lw = 7, stw = ((dw-7)/8)) (
// Global inputs
input            ACLK      ,
input            ARESETn   ,

// Slave port S0 AXI WS5M1 mux
input    [idw:0] IDMASKS0  ,
// Write Address Channel
input    [idw:0] AWIDS0    ,
input     [31:0] AWADDRS0  ,
input      [3:0] AWREGIONS0,
input     [lw:0] AWLENS0   ,
input      [2:0] AWSIZES0  ,
input      [1:0] AWBURSTS0 ,
input            AWLOCKS0  ,
input      [3:0] AWCACHES0 ,
input      [2:0] AWPROTS0  ,
input      [3:0] AWQOSS0   ,
input            AWVALIDS0 ,
output           AWREADYS0 ,
// Write Channel
input    [idw:0] WIDS0     ,
input     [dw:0] WDATAS0   ,
input    [stw:0] WSTRBS0   ,
input            WLASTS0   ,
input            WVALIDS0  ,
output           WREADYS0  ,
// Write Response Channel
output   [idw:0] BIDS0     ,
output     [1:0] BRESPS0   ,
output           BVALIDS0  ,
input            BREADYS0  ,

// Slave port S1 AXI WS5M1 mux
input    [idw:0] IDMASKS1  ,
// Write Address Channel
input    [idw:0] AWIDS1    ,
input     [31:0] AWADDRS1  ,
input      [3:0] AWREGIONS1,
input     [lw:0] AWLENS1   ,
input      [2:0] AWSIZES1  ,
input      [1:0] AWBURSTS1 ,
input            AWLOCKS1  ,
input      [3:0] AWCACHES1 ,
input      [2:0] AWPROTS1  ,
input      [3:0] AWQOSS1   ,
input            AWVALIDS1 ,
output           AWREADYS1 ,
// Write Channel
input    [idw:0] WIDS1     ,
input     [dw:0] WDATAS1   ,
input    [stw:0] WSTRBS1   ,
input            WLASTS1   ,
input            WVALIDS1  ,
output           WREADYS1  ,
// Write Response Channel
output   [idw:0] BIDS1     ,
output     [1:0] BRESPS1   ,
output           BVALIDS1  ,
input            BREADYS1  ,

// Slave port S2 AXI WS5M1 mux
input    [idw:0] IDMASKS2  ,
// Write Address Channel
input    [idw:0] AWIDS2    ,
input     [31:0] AWADDRS2  ,
input      [3:0] AWREGIONS2,
input     [lw:0] AWLENS2   ,
input      [2:0] AWSIZES2  ,
input      [1:0] AWBURSTS2 ,
input            AWLOCKS2  ,
input      [3:0] AWCACHES2 ,
input      [2:0] AWPROTS2  ,
input      [3:0] AWQOSS2   ,
input            AWVALIDS2 ,
output           AWREADYS2 ,
// Write data Channel
input    [idw:0] WIDS2     ,
input     [dw:0] WDATAS2   ,
input    [stw:0] WSTRBS2   ,
input            WLASTS2   ,
input            WVALIDS2  ,
output           WREADYS2  ,
// Write Response Channel
output   [idw:0] BIDS2     ,
output     [1:0] BRESPS2   ,
output           BVALIDS2  ,
input            BREADYS2  ,  

//Master 0 port AXI WS5M1 mux
// Write Address Channel
output reg[idw:0]AWIDM0    ,
output reg [31:0]AWADDRM0  ,
output reg  [3:0]AWREGIONM0,
output reg [lw:0]AWLENM0   ,
output reg  [2:0]AWSIZEM0  ,
output reg  [1:0]AWBURSTM0 ,
output reg       AWLOCKM0  ,
output reg  [3:0]AWCACHEM0 ,
output reg  [2:0]AWPROTM0  ,
output reg  [3:0]AWQOSM0   ,
output reg       AWVALIDM0 ,
input            AWREADYM0 ,
// Write Channel
output reg[idw:0]WIDM0     ,
output reg [dw:0]WDATAM0   ,
output reg[stw:0]WSTRBM0   ,
output reg       WLASTM0   ,
output reg       WVALIDM0  ,
input            WREADYM0  ,
// Write Response Channel
input    [idw:0] BIDM0     ,
input      [1:0] BRESPM0   ,
input            BVALIDM0  ,
output           BREADYM0
);

reg	[7:0]	issue_cnt;

// Write Address, Data Channel
reg        [2:0] ws_sel;	// 0: no select
				// 1: S0
				// 2: S1
				// 3: S2
				// 4: S3
				// 5: S4
always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0) 
	ws_sel <= 3'd0;
    else if(WLASTM0 & WVALIDM0 & WREADYM0 & (issue_cnt <= 8'd1))        // TBD
	ws_sel <= 3'd0;
    else if(ws_sel == 3'b0) begin
	ws_sel <= AWVALIDS0 ? 3'd1 : (AWVALIDS1 ? 3'd2 : (AWVALIDS2 ? 3'd3 : 3'd0)); 
    end
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0) 
	issue_cnt <= 8'b0;
    else if(ws_sel == 3'd0)
	issue_cnt <= 8'b0;
    else if((AWVALIDM0 && AWREADYM0) && (!(WVALIDM0 && WREADYM0 && WLASTM0)))
	issue_cnt <= issue_cnt + 8'd1;
    else if(WVALIDM0 && WREADYM0 && WLASTM0)
	issue_cnt <= issue_cnt - 8'd1;
end

assign AWREADYS0 = (ws_sel == 3'd1) ? AWREADYM0 : 1'b0;
assign AWREADYS1 = (ws_sel == 3'd2) ? AWREADYM0 : 1'b0;
assign AWREADYS2 = (ws_sel == 3'd3) ? AWREADYM0 : 1'b0;

assign WREADYS0 = (ws_sel == 3'd1) ? WREADYM0 : 1'b0;
assign WREADYS1 = (ws_sel == 3'd2) ? WREADYM0 : 1'b0;
assign WREADYS2 = (ws_sel == 3'd3) ? WREADYM0 : 1'b0; 

always @(*)
begin
    case(ws_sel)
    3'd1: begin
	AWIDM0    = AWIDS0;
	AWADDRM0  = AWADDRS0;
	AWREGIONM0= AWREGIONS0;
	AWLENM0   = AWLENS0;
	AWSIZEM0  = AWSIZES0;
	AWBURSTM0 = AWBURSTS0;
	AWLOCKM0  = AWLOCKS0;
	AWCACHEM0 = AWCACHES0;
	AWPROTM0  = AWPROTS0;
	AWQOSM0   = AWQOSS0;
	AWVALIDM0 = AWVALIDS0;
	WIDM0     = WIDS0;
	WDATAM0   = WDATAS0;
	WSTRBM0   = WSTRBS0;
	WLASTM0   = WLASTS0;
	WVALIDM0  = WVALIDS0;
    end
    3'd2: begin
	AWIDM0    = AWIDS1;
	AWADDRM0  = AWADDRS1;
	AWREGIONM0= AWREGIONS1;
	AWLENM0   = AWLENS1;
	AWSIZEM0  = AWSIZES1;
	AWBURSTM0 = AWBURSTS1;
	AWLOCKM0  = AWLOCKS1;
	AWCACHEM0 = AWCACHES1;
	AWPROTM0  = AWPROTS1;
	AWQOSM0   = AWQOSS1;
	AWVALIDM0 = AWVALIDS1;
	WIDM0     = WIDS1;
	WDATAM0   = WDATAS1;
	WSTRBM0   = WSTRBS1;
	WLASTM0   = WLASTS1;
	WVALIDM0  = WVALIDS1;
    end
    3'd3: begin 
	AWIDM0    = AWIDS2;
	AWADDRM0  = AWADDRS2;
	AWREGIONM0= AWREGIONS2;
	AWLENM0   = AWLENS2;
	AWSIZEM0  = AWSIZES2;
	AWBURSTM0 = AWBURSTS2;
	AWLOCKM0  = AWLOCKS2;
	AWCACHEM0 = AWCACHES2;
	AWPROTM0  = AWPROTS2;
	AWQOSM0   = AWQOSS2;
	AWVALIDM0 = AWVALIDS2;
	WIDM0     = WIDS2;
	WDATAM0   = WDATAS2;
	WSTRBM0   = WSTRBS2;
	WLASTM0   = WLASTS2;
	WVALIDM0  = WVALIDS2;
    end
    default: begin
	AWIDM0    = 0;
	AWADDRM0  = 0;
	AWREGIONM0= 0;
	AWLENM0   = 0;
	AWSIZEM0  = 0;
	AWBURSTM0 = 0;
	AWLOCKM0  = 0;
	AWCACHEM0 = 0;
	AWPROTM0  = 0;
	AWQOSM0   = 0;
	AWVALIDM0 = 0;
	WIDM0     = 0;
	WDATAM0   = 0;
	WSTRBM0   = 0;
	WLASTM0   = 0;
	WVALIDM0  = 0;
    end
    endcase
end

// Write Response Channel
assign BREADYM0 = ((BIDM0 & IDMASKS0) == (AWIDS0 & IDMASKS0)) ? BREADYS0 : 
                  ((BIDM0 & IDMASKS1) == (AWIDS1 & IDMASKS1)) ? BREADYS1 :
 		          ((BIDM0 & IDMASKS2) == (AWIDS2 & IDMASKS2)) ? BREADYS2 : 1'b0;

assign BVALIDS0 = ((BIDM0 & IDMASKS0) == (AWIDS0 & IDMASKS0)) & BVALIDM0; 
assign BVALIDS1 = ((BIDM0 & IDMASKS1) == (AWIDS1 & IDMASKS1)) & BVALIDM0; 
assign BVALIDS2 = ((BIDM0 & IDMASKS2) == (AWIDS2 & IDMASKS2)) & BVALIDM0; 

assign BRESPS0 = BRESPM0;
assign BRESPS1 = BRESPM0;
assign BRESPS2 = BRESPM0;
assign BIDS0 = BIDM0[idw:0];
assign BIDS1 = BIDM0[idw:0];
assign BIDS2 = BIDM0[idw:0];

endmodule
