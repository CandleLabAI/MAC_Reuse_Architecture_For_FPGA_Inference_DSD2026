
`timescale 1 ns / 100 ps

module lsc_hyperbus_io (
input		clki          ,
input		clkq          ,
input           resetn        ,

// from controller
input           i_hr_csb      ,
input           i_hr_rwds_z   ,
input  [1:0]    i_hr_rwds_o   ,
input           i_hr_dq_z     ,
input  [15:0]   i_hr_dq_o     ,

// to controller
output [1:0]    o_hr_rwds_i   ,
output [15:0]   o_hr_dq_i     ,

// HyperBUS I/O
output          hr_ck         ,
output          hr_ckn        ,
output          hr_csb        ,
output          hr_rstb       ,
inout           hr_rwds       ,
inout   [7:0]   hr_dq         
);

parameter NX_01B = 1'b0;

wire		w_hr_rwds_o0 ;
wire		w_hr_rwds_o1 ;
wire		w_hr_rwds_i0 ;
wire		w_hr_rwds_i1 ;
wire	[7:0]	w_hr_dqo0 ;
wire	[7:0]	w_hr_dqo1 ;
wire	[7:0]	w_hr_dqi0 ;
wire	[7:0]	w_hr_dqi1 ;

wire		w_hr_rwds_zo;

wire		w_hr_rwds_o;
wire		w_hr_rwds_i;

wire		w_hr_dq_zo;

wire	[7:0]	w_hr_dq_o ;
wire	[7:0]	w_hr_dq_i ;

reg		r_hr_rwds_z_d1;
reg		r_hr_rwds_z_d2;
reg		r_hr_rwds_z_d;
reg		r_hr_dq_z_d1;
reg		r_hr_dq_z_d2;
reg		r_hr_dq_z_d;

always @(posedge clki)
begin
    r_hr_rwds_z_d1 <= i_hr_rwds_z;
    r_hr_rwds_z_d2 <= r_hr_rwds_z_d1;
    r_hr_rwds_z_d  <= (NX_01B == 1'b1) ? r_hr_rwds_z_d2 : r_hr_rwds_z_d1;
    r_hr_dq_z_d1   <= i_hr_dq_z;
    r_hr_dq_z_d2   <= r_hr_dq_z_d1;
    r_hr_dq_z_d    <= (NX_01B == 1'b1) ?  r_hr_dq_z_d2 : r_hr_dq_z_d1;
end


assign hr_rstb = resetn;

ODDRX1 u_oddrx1f_hr_clkp  (
    .D0  (1'b1          ),
    .D1  (1'b0          ),
    .SCLK(clkq          ),
    .RST (!resetn       ),
    .Q   (hr_ck         )
);

ODDRX1 u_oddrx1f_hr_clkn  (
    .D0  (1'b0          ),
    .D1  (1'b1          ),
    .SCLK(clkq          ),
    .RST (!resetn       ),
    .Q   (hr_ckn        )
);

ODDRX1 u_oddrx1f_hr_csb  (
    .D0  (i_hr_csb      ),
    .D1  (i_hr_csb      ),
    .SCLK(clki          ),
    .RST (!resetn       ),
    .Q   (hr_csb        )
);

OFD1P3DX u_hr_rwds_z (
    .D   (r_hr_rwds_z_d ), 
    .SP  (1'b1          ), 
    .CK  (clki          ), 
    .CD  (!resetn       ), 
    .Q   (w_hr_rwds_zo  )
);

BB u_hr_rwds_io (
    .I   (w_hr_rwds_o   ), 
    .T   (w_hr_rwds_zo  ), 
    .O   (w_hr_rwds_i   ),
    .B   (hr_rwds       )
);

IDDRX1 u_iddr_rwds  (
    .D   (w_hr_rwds_i   ),
    .RST (!resetn       ),
    .SCLK(clki          ),
//    .SCLK(clkq          ),
    .Q0  (o_hr_rwds_i[1]),
    .Q1  (o_hr_rwds_i[0])
);

ODDRX1 u_oddr_rwds  (
    .D0  (i_hr_rwds_o[1]),
    .D1  (i_hr_rwds_o[0]),
    .SCLK(clki          ),
    .RST (!resetn       ),
    .Q   (w_hr_rwds_o   )
);

OFD1P3DX u_hr_dq_z (
    .D   (r_hr_dq_z_d   ), 
    .SP  (1'b1          ), 
    .CK  (clki          ), 
    .CD  (!resetn       ), 
    .Q   (w_hr_dq_zo    )
);

BB u_hr_dq_io [7:0] (
    .I   (w_hr_dq_o      ), 
    .T   (w_hr_dq_zo     ), 
    .O   (w_hr_dq_i      ),
    .B   (hr_dq          )
);

IDDRX1 u_iddr_hrdq [7:0] (
    .D   (w_hr_dq_i      ),
    .RST (!resetn        ),
    .SCLK(clki           ),
//    .SCLK(clkq           ),
    .Q0  (o_hr_dq_i[15:8]),
    .Q1  (o_hr_dq_i[7 :0])
);

ODDRX1 u_oddr_hrdq [7:0]  (
    .D0  (i_hr_dq_o[15:8]),
    .D1  (i_hr_dq_o[7 :0]),
    .SCLK(clki           ),
    .RST (!resetn        ),
    .Q   (w_hr_dq_o      )
);

endmodule


// vim:foldmethod=marker:
//
