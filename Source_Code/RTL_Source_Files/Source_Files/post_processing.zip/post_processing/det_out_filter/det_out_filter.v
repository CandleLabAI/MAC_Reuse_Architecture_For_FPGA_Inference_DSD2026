
`timescale 1ns/10ps

module det_out_filter	#(parameter NUM_ANCHOR	= 12'd1372,	// number of anchors
									NUM_GRID	= 9'd196,	// number of grids
									NUM_X_GRID	= 4'd14,	// number of X grids
									NUM_Y_GRID	= 4'd14,	// number of Y grids
									NUM_FRAC	= 10,		// bit width of fractional part
									OVLP_TH_2X	= 5,		// overlap threshold 2X (inverse ratio: union / overlap)
									PIC_WIDTH	= 224,		// picture width
									PIC_HEIGHT	= 224,		// picture height
									NUM_CLASS	= 5,		// number of classes (check bit-width of feature counter)
									TOP_N_DET	= 10)		// number of detections
(
  input									clk,			// data out clock
  input									resetn,
  input signed [15:0]					i_conf_th,		// confidence threshold
  input									i_out_start,	// output start indication
  input									i_data_en,		// ML output enable
  input signed [15:0]					i_data,			// ML output data
  
  output wire							o_out_en,		// output enable
  output wire [NUM_CLASS*TOP_N_DET-1:0]	o_cls_bmap,		// class bitmap output
  output wire [TOP_N_DET-1:0]			o_bbox_bmap,	// valid bitmap output
  output wire [31:0]					o_bbox_00,		// bounding box coordinate 00
  output wire [31:0]					o_bbox_01,		// bounding box coordinate 01
  output wire [31:0]					o_bbox_02,		// bounding box coordinate 02
  output wire [31:0]					o_bbox_03,		// bounding box coordinate 03
  output wire [31:0]					o_bbox_04,		// bounding box coordinate 04
  output wire [31:0]					o_bbox_05,		// bounding box coordinate 05
  output wire [31:0]					o_bbox_06,		// bounding box coordinate 06
  output wire [31:0]					o_bbox_07,		// bounding box coordinate 07
  output wire [31:0]					o_bbox_08,		// bounding box coordinate 08
  output wire [31:0]					o_bbox_09		// bounding box coordinate 09
);

	// internal signals
	reg					r_data_en;			// data eanble
	reg signed [15:0]	r_data;				// data
	reg signed [15:0]	r_data_1d;			// data (1 cycle delay)
	reg signed [15:0]	r_data_2d;			// data (2 cycle delay)
	reg signed [15:0]	r_data_3d;			// data (3 cycle delay)
	reg signed [15:0]	r_data_4d;			// data (4 cycle delay)
	reg	   [11:0]		r_anchor_cnt;		// anchor counter
	wire				w_anchor_cnt_end;	// anchor count end
	reg	   [3:0]		r_feature_cnt;		// feature counter
	wire				w_feature_cnt_end;	// feature count end
	reg					r_conf_en;			// confidence score enable
	wire				w_conf_en;			// confidence score enable
	wire signed [15:0]	w_conf_score;		// confidence score
	wire				w_conf_out_en;		// confidence output enable
	wire	    [4:0]	w_num_conf;			// number of confidence score > threshold
	reg					r_cls_en;			// class probability enable
	reg					r_cls_en_1d;		// class probability enable (1-cycle delay)
	reg					r_cls_en_2d;		// class probability enable (2-cycle delay)
	reg					r_cls_en_3d;		// class probability enable (3-cycle delay)
	wire				w_cls_en;			// class probability enable
	wire signed [15:0]	w_cls_prob;			// class probability data
	wire				w_cls_out_en;		// class bitmap output enable
	reg					r_bbox_en;			// bounding box enable
	reg					r_bbox_en_1d;		// bounding box enable (1-cycle delay)
	reg					r_bbox_en_2d;		// bounding box enable (2-cycle delay)
	reg					r_bbox_en_3d;		// bounding box enable (3-cycle delay)
	wire				w_bbox_en;			// bounding box enable
	wire signed [15:0]	w_bbox_data;		// bounding box data
	wire	    [15:0]	w_conf_00;			// confidence score 00
	wire	    [15:0]	w_conf_01;			// confidence score 01
	wire	    [15:0]	w_conf_02;			// confidence score 02
	wire	    [15:0]	w_conf_03;			// confidence score 03
	wire	    [11:0]	w_idx_00;			// sorted index 00
	wire	    [11:0]	w_idx_01;			// sorted index 01
	wire	    [11:0]	w_idx_02;			// sorted index 02
	wire	    [11:0]	w_idx_03;			// sorted index 03
	wire	    [11:0]	w_idx_04;			// sorted index 04
	wire	    [11:0]	w_idx_05;			// sorted index 05
	wire	    [11:0]	w_idx_06;			// sorted index 06
	wire	    [11:0]	w_idx_07;			// sorted index 07
	wire	    [11:0]	w_idx_08;			// sorted index 08
	wire	    [11:0]	w_idx_09;			// sorted index 09
	wire [NUM_CLASS*TOP_N_DET-1:0]	w_cls_bmap;		// class bitmap	
	wire [TOP_N_DET-1:0]    		w_tot_det;

	assign w_anchor_cnt_end	 = r_anchor_cnt == (NUM_ANCHOR - 1);
	assign w_feature_cnt_end = w_anchor_cnt_end && (r_feature_cnt == (NUM_CLASS+4));
	assign w_conf_en	 = r_conf_en;
	assign w_conf_score	 = r_data_1d;
	assign w_cls_en		 = r_cls_en_3d;
	assign w_cls_prob	 = r_data_4d;
	assign w_bbox_en	 = r_bbox_en_3d;
	assign w_bbox_data	 = r_data_4d;
	//assign w_bbox_en	 = r_bbox_en;
	//assign w_bbox_data	 = r_data_1d;
	//assign o_num_conf      = w_num_conf;

/****************************************************************************/
  //Control Part													
 //****************************************************************************/

	// input buffering
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_data_en	<= 1'b0;
		else
			r_data_en	<= i_data_en;
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_data		<= 16'h0;
			r_data_1d	<= 16'h0;
			r_data_2d	<= 16'h0;
			r_data_3d	<= 16'h0;
			r_data_4d	<= 16'h0;
		end
		else begin
			r_data		<= i_data;
			r_data_1d	<= r_data;
			r_data_2d	<= r_data_1d;
			r_data_3d	<= r_data_2d;
			r_data_4d	<= r_data_3d;
		end
	end

	// anchor counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_cnt	<= 12'h0;
		else if (i_out_start)
			r_anchor_cnt	<= 12'h0;
		else if (r_data_en) begin
			if (w_feature_cnt_end)
			  r_anchor_cnt	<= 12'h0;
			else if (w_anchor_cnt_end)
			  r_anchor_cnt	<= 12'h0;
			else
			  r_anchor_cnt	<= r_anchor_cnt + 12'h1;
		end
	end

	// feature counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_feature_cnt	<= 4'h0;
		else if (i_out_start)
			r_feature_cnt	<= 4'h0;
		else if (r_data_en && w_anchor_cnt_end)
			r_feature_cnt	<= r_feature_cnt + 4'h1;
	end

	// conference score
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_conf_en	<= 1'b0;
		else if (i_out_start)
			r_conf_en	<= 1'b0;
		else
			r_conf_en	<= r_data_en && (r_feature_cnt == 0);
	end

	// class
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
		   r_cls_en	<= 1'b0;
		else if (i_out_start)
		  r_cls_en	<= 1'b0;
		else
		  r_cls_en	<= r_data_en && ((r_feature_cnt >= 1) && (r_feature_cnt <= NUM_CLASS));
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
		  r_cls_en_1d	<= 1'b0;
		  r_cls_en_2d	<= 1'b0;
		  r_cls_en_3d	<= 1'b0;
		end
		else begin
		  r_cls_en_1d	<= r_cls_en;
		  r_cls_en_2d	<= r_cls_en_1d;
		  r_cls_en_3d	<= r_cls_en_2d;
		end
	end

	// bounding box
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
		  r_bbox_en	<= 1'b0;
		else if (i_out_start)
		  r_bbox_en	<= 1'b0;
		else
	//	  r_bbox_en	<= r_data_en && ((r_feature_cnt == 1) ||										 (r_feature_cnt == 2) ||(r_feature_cnt == 3) ||(r_feature_cnt == 4));
		  r_bbox_en	<= r_data_en && (r_feature_cnt > NUM_CLASS) && (r_feature_cnt <= (NUM_CLASS + 4));
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
		  r_bbox_en_1d	<= 1'b0;
		  r_bbox_en_2d	<= 1'b0;
		  r_bbox_en_3d	<= 1'b0;
		end
		else begin
		  r_bbox_en_1d	<= r_bbox_en;
		  r_bbox_en_2d	<= r_bbox_en_1d;
		  r_bbox_en_3d	<= r_bbox_en_2d;
		end
	end

/****************************************************************************/
/* Instantiation*/													
/****************************************************************************/

	// sort confidence score
	det_sort_conf	#( .NUM_ANCHOR	(NUM_ANCHOR	),	// number of anchors
			   .TOP_N_DET	(TOP_N_DET	))	// top N detection
		u_det_sort_conf
	(
		.clk		(clk		),
		.resetn		(resetn		),
		.i_conf_th	(i_conf_th	),
		.i_out_start(i_out_start	),
		.i_conf_en	(r_conf_en	),
		.i_conf_score(w_conf_score	),
		.o_out_en	(w_conf_out_en	),
		.o_num_conf	(w_num_conf	),
		.o_tot_det	(w_tot_det	),
		.o_conf_00	(w_conf_00	),
		.o_conf_01	(w_conf_01	),
		.o_conf_02	(w_conf_02	),
		.o_conf_03	(w_conf_03	),
		.o_idx_00	(w_idx_00	),
		.o_idx_01	(w_idx_01	),
		.o_idx_02	(w_idx_02	),
		.o_idx_03	(w_idx_03	),
		.o_idx_04	(w_idx_04	),
		.o_idx_05	(w_idx_05	),
		.o_idx_06	(w_idx_06	),
		.o_idx_07	(w_idx_07	),
		.o_idx_08	(w_idx_08	),
		.o_idx_09	(w_idx_09	)
	);

// identify class
	det_st_class	#( .NUM_ANCHOR	(NUM_ANCHOR	),	// number of anchors
					   .NUM_GRID	(NUM_GRID	),	// number of grids
					   .NUM_CLASS	(NUM_CLASS	),	// number of classes
					   .TOP_N_DET	(TOP_N_DET	))	// number of detection
		u_det_st_class
	(
		.clk		(clk		),		// data out clock
		.resetn		(resetn		),		// reset
		.i_out_start(i_out_start	),		// out start
		.i_cls_en	(w_cls_en	),		// class probability enable
		.i_cls_prob	(w_cls_prob	),		// class probability
		.i_idx_00	(w_idx_00	),		// sorted index 00
		.i_idx_01	(w_idx_01	),		// sorted index 01
		.i_idx_02	(w_idx_02	),		// sorted index 02
		.i_idx_03	(w_idx_03	),		// sorted index 03
		.i_idx_04	(w_idx_04	),		// sorted index 04
		.i_idx_05	(w_idx_05	),		// sorted index 05
		.i_idx_06	(w_idx_06	),		// sorted index 06
		.i_idx_07	(w_idx_07	),		// sorted index 07
		.i_idx_08	(w_idx_08	),		// sorted index 08
		.i_idx_09	(w_idx_09	),		// sorted index 09
		.o_out_en	(w_cls_out_en	),		// output enable
		.o_cls_bmap	(o_cls_bmap	)		// class bitmap output
	);


	// store bounding box
	det_st_bbox #(	.NUM_ANCHOR		(NUM_ANCHOR	),	// number of anchors
					.NUM_GRID		(NUM_GRID	),	// number of grids
					.NUM_X_GRID		(NUM_X_GRID	),	// number of X grids
					.NUM_Y_GRID		(NUM_Y_GRID	),	// number of Y grids
					.NUM_FRAC		(NUM_FRAC	),	// fractional part (11 bits)
					.OVLP_TH_2X		(OVLP_TH_2X	),	// overlap threshold x 2
					.PIC_WIDTH		(PIC_WIDTH	),	// picture width
					.PIC_HEIGHT		(PIC_HEIGHT	),	// picture height
					.NUM_CLASS		(NUM_CLASS	),	// number of classes
					.TOP_N_DET		(TOP_N_DET	))	// number of detection
		u_det_st_bbox
	(
		.clk		(clk		),
		.resetn		(resetn		),
		.i_out_start(i_out_start	),
		.i_num_conf	(w_num_conf	),
		.i_tot_det	(w_tot_det	),
		.i_cls_bmap	(o_cls_bmap	),
		.i_bbox_en	(w_bbox_en	),
		.i_bbox_data(w_bbox_data	),
		.i_idx_00	(w_idx_00	),
		.i_idx_01	(w_idx_01	),
		.i_idx_02	(w_idx_02	),
		.i_idx_03	(w_idx_03	),
		.i_idx_04	(w_idx_04	),
		.i_idx_05	(w_idx_05	),
		.i_idx_06	(w_idx_06	),
		.i_idx_07	(w_idx_07	),
		.i_idx_08	(w_idx_08	),
		.i_idx_09	(w_idx_09	),
		.o_bbox_00	(o_bbox_00	),
		.o_bbox_01	(o_bbox_01	),
		.o_bbox_02	(o_bbox_02	),
		.o_bbox_03	(o_bbox_03	),
		.o_bbox_04	(o_bbox_04	),
		.o_bbox_05	(o_bbox_05	),
		.o_bbox_06	(o_bbox_06	),
		.o_bbox_07	(o_bbox_07	),
		.o_bbox_08	(o_bbox_08	),
		.o_bbox_09	(o_bbox_09	),
		.tot_det	(o_bbox_bmap),
		.o_out_en	(o_out_en	)
	);


endmodule

// vim:foldmethod=marker:
//
