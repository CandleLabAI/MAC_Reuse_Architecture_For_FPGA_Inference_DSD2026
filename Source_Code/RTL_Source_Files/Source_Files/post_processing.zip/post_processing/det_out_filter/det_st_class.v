
`timescale 1ns/10ps

module det_st_class	#(parameter NUM_ANCHOR	= 12'd1372,	// number of anchors
								NUM_GRID	= 9'd196,	// number of grids
								NUM_CLASS	= 3,		// number of classes
								TOP_N_DET	= 10)		// number of detection
(
	input				clk,				// data out clock
	input				resetn,
	input				i_out_start,			// out start
	input				i_cls_en,			// class probability enable
	input signed [15:0]	i_cls_prob,			// class probability
	input	     [11:0]	i_idx_00,			// sorted index 00
	input	     [11:0]	i_idx_01,			// sorted index 01
	input	     [11:0]	i_idx_02,			// sorted index 02
	input	     [11:0]	i_idx_03,			// sorted index 03
	input	     [11:0]	i_idx_04,			// sorted index 04
	input	     [11:0]	i_idx_05,			// sorted index 05
	input	     [11:0]	i_idx_06,			// sorted index 06
	input	     [11:0]	i_idx_07,			// sorted index 07
	input	     [11:0]	i_idx_08,			// sorted index 08
	input	     [11:0]	i_idx_09,			// sorted index 09
	output reg			o_out_en,			// output enable
	output wire [NUM_CLASS*TOP_N_DET-1:0]	o_cls_bmap	// class bitmap output
);

	// internal signals
	reg			            r_cls_en;				// class prob enable
	reg			            r_cls_en_1d;			// class prob enable (1-cycle delay)
	reg			            r_cls_en_2d;			// class prob enable (2-cycle delay)
	reg [NUM_CLASS-1:0]	    r_cls_ind_bmap;			// class indication bitmap
	wire [NUM_CLASS-1:0]	w_cls_en_bmap;			// class enable bitmap
	reg signed [15:0]	    r_cls_prob;				// class prob
	reg signed [15:0]	    r_cls_prob_1d;			// class prob (1-cycle delay)
	reg signed [15:0]	    r_cls_prob_2d;			// class prob (2-cycle delay)
	reg	   [8:0]	        r_grid_cnt;				// anchor counter (0~63)
	wire	   		        w_grid_cnt_end;			// anchor count end
	reg	   [11:0]	        r_save_anchor_cnt;		// anchor counter saved
	wire	   		        w_rst_save_cnt;			// restore saved count
	reg	   [11:0]	        r_anchor_cnt;			// anchor counter (0~383)
	wire			        w_anchor_cnt_end;		// anchor count end

	reg signed [15:0]	    r_prob[0:TOP_N_DET-1];		// probability saved
	reg [NUM_CLASS-1:0]	    r_cls_bmap[0:TOP_N_DET-1];	// class result
	wire [TOP_N_DET-1:0]	w_cmp_prob;					// compare two class probs of the index
	wire [TOP_N_DET-1:0]	w_cmp_idx;					// compare indices

	assign w_grid_cnt_end	= r_grid_cnt == (NUM_GRID - 1);
	assign w_cls_en_bmap	= {NUM_CLASS{r_cls_en_2d}} & r_cls_ind_bmap;
	assign w_rst_save_cnt	= w_grid_cnt_end && !r_cls_ind_bmap[NUM_CLASS-1];
	assign w_anchor_cnt_end	= r_anchor_cnt == (NUM_ANCHOR - 1) && (r_cls_ind_bmap[NUM_CLASS-1] == 1'b1);
	// compare index
	assign w_cmp_idx[0]	    = (r_anchor_cnt == i_idx_00);
	assign w_cmp_idx[1]	    = (r_anchor_cnt == i_idx_01);
	assign w_cmp_idx[2]	    = (r_anchor_cnt == i_idx_02);
	assign w_cmp_idx[3]	    = (r_anchor_cnt == i_idx_03);
	assign w_cmp_idx[4]	    = (r_anchor_cnt == i_idx_04);
	assign w_cmp_idx[5]	    = (r_anchor_cnt == i_idx_05);
	assign w_cmp_idx[6]	    = (r_anchor_cnt == i_idx_06);
	assign w_cmp_idx[7]	    = (r_anchor_cnt == i_idx_07);
	assign w_cmp_idx[8]	    = (r_anchor_cnt == i_idx_08);
	assign w_cmp_idx[9]	    = (r_anchor_cnt == i_idx_09);
	
	// input register
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_cls_en		<= 1'b0;
			r_cls_en_1d		<= 1'b0;
			r_cls_en_2d		<= 1'b0;
			r_cls_prob		<= 16'h0;
			r_cls_prob_1d	<= 16'h0;
			r_cls_prob_2d	<= 16'h0;
		end
		else begin
			r_cls_en		<= i_cls_en;
			r_cls_en_1d		<= r_cls_en;
			r_cls_en_2d		<= r_cls_en_1d;
			r_cls_prob		<= $signed(i_cls_prob);
			r_cls_prob_1d	<= r_cls_prob;
			r_cls_prob_2d	<= r_cls_prob_1d;
		end
	end

	// grid counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_grid_cnt	<= 9'h0;
		else if (i_out_start)
			r_grid_cnt	<= 9'h0;
		else if (w_grid_cnt_end)
			r_grid_cnt	<= 9'h0;
		else if (r_cls_en_2d)
			r_grid_cnt	<= r_grid_cnt + 9'h1;
	end

	// class field indication
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_cls_ind_bmap	<= {NUM_CLASS{1'b0}};
		else if (i_out_start)
			r_cls_ind_bmap	<= 'h1;
		else if (w_grid_cnt_end && (NUM_CLASS > 1))			// circular shift
			r_cls_ind_bmap	<= {r_cls_ind_bmap[NUM_CLASS-2:0], r_cls_ind_bmap[NUM_CLASS-1]};
	end

	// anchor counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_save_anchor_cnt	<= 12'h0;
		else if (i_out_start)
			r_save_anchor_cnt	<= 12'h0;
		else if (w_grid_cnt_end && r_cls_ind_bmap[NUM_CLASS-1])
			r_save_anchor_cnt	<= r_anchor_cnt + 12'h1;
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_cnt	<= 12'h0;
		else if (i_out_start)
			r_anchor_cnt	<= 12'h0;
		else if (w_anchor_cnt_end)
			r_anchor_cnt	<= 12'h0;
		else if (r_cls_en_2d) begin
			if (w_rst_save_cnt)
				r_anchor_cnt	<= r_save_anchor_cnt;
			else
				r_anchor_cnt	<= r_anchor_cnt + 12'h1;
		end
	end

	// class storage
	//  - pick 10 class information based on confidence index
	genvar i;
	generate
		for (i = 0; i < TOP_N_DET; i=i+1) begin : ST_CLS
			always @(posedge clk or negedge resetn)
			begin
				if (!resetn)
					r_prob[i]	<= 16'h0;
				else if (i_out_start)
					r_prob[i]	<= 16'h0;
				else if (w_cmp_idx[i]) begin
					if (w_cls_en_bmap[0])
						r_prob[i]	<= r_cls_prob_2d;
					else if (r_cls_en_2d && w_cmp_prob[i])
						r_prob[i]	<= r_cls_prob_2d;
				end
			end

			always @(posedge clk or negedge resetn)
			begin
				if (!resetn)
					r_cls_bmap[i]	<= 'h0;
				else if (i_out_start)
					r_cls_bmap[i]	<= 'h0;
				else if (w_cmp_idx[i]) begin
					if (w_cls_en_bmap[0])
						r_cls_bmap[i]	<= 'h1;
					else if (r_cls_en_2d && w_cmp_prob[i])
						r_cls_bmap[i]	<= r_cls_ind_bmap;
				end
			end

			assign w_cmp_prob[i]	= (r_cls_prob_2d >= r_prob[i]);
		end
	endgenerate

	// class output
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			o_out_en	<= 1'b0;
		else
			o_out_en	<= r_cls_en_2d && w_anchor_cnt_end;
	end

	genvar j;
	for (j = 0; j < TOP_N_DET; j = j + 1)
		assign o_cls_bmap[(j+1)*NUM_CLASS-1:j*NUM_CLASS]	= r_cls_bmap[j];
		

endmodule

// vim:foldmethod=marker:
//
