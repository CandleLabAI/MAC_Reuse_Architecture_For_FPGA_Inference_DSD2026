
`timescale 1ns/10ps

module det_st_bbox #(parameter  NUM_ANCHOR	= 12'd448,	// number of anchors
				                NUM_GRID	= 9'd64,	// number of grids
				                NUM_X_GRID	= 4'd8,		// number of X grids
				                NUM_Y_GRID	= 4'd8,		// number of Y grids
				                NUM_FRAC	= 10,		// fractional part (11 bits)
				                OVLP_TH_2X	= 5,		// overlap threshold x 2 (inverse ratio: union / overlap)
				                PIC_WIDTH	= 128,		// picture width
				                PIC_HEIGHT	= 128,		// picture height
				                NUM_CLASS	= 3,		// number of classes
				                TOP_N_DET	= 10)		// number of detection
(
	input				            clk,			// data out clock
	input				            resetn,
	input				            i_out_start,	// out start
	input	     [4:0]			    i_num_conf,		// number of confidence score > threshold
	input [TOP_N_DET-1:0] 		    i_tot_det,
	input						    i_bbox_en,		// bounding box enable
	input [NUM_CLASS*TOP_N_DET-1:0]	i_cls_bmap,		// class bitmap
	input signed [15:0]				i_bbox_data,	// bounding box data
	input	     [11:0]	            i_idx_00,		// sorted index 00
	input	     [11:0]	            i_idx_01,		// sorted index 01
	input	     [11:0]	            i_idx_02,		// sorted index 02
	input	     [11:0]	            i_idx_03,		// sorted index 03
	input	     [11:0]	            i_idx_04,		// sorted index 04
	input	     [11:0]	            i_idx_05,		// sorted index 05
	input	     [11:0]	            i_idx_06,		// sorted index 06
	input	     [11:0]	            i_idx_07,		// sorted index 07
	input	     [11:0]	            i_idx_08,		// sorted index 08
	input	     [11:0]	            i_idx_09,		// sorted index 09
	output wire  [31:0]	            o_bbox_00,		// bounding box coordinate 00
	output wire  [31:0]	            o_bbox_01,		// bounding box coordinate 01
	output wire  [31:0]	            o_bbox_02,		// bounding box coordinate 02
	output wire  [31:0]	            o_bbox_03,		// bounding box coordinate 03
	output wire  [31:0]	            o_bbox_04,		// bounding box coordinate 04
	output wire  [31:0]	            o_bbox_05,		// bounding box coordinate 05
	output wire  [31:0]	            o_bbox_06,		// bounding box coordinate 06
	output wire  [31:0]	            o_bbox_07,		// bounding box coordinate 07
	output wire  [31:0]	            o_bbox_08,		// bounding box coordinate 08
	output wire  [31:0]	            o_bbox_09,		// bounding box coordinate 09
	output reg [TOP_N_DET-1:0]	    tot_det,		// bounding box bitmap
	output reg						o_out_en		// output enable
);

	// internal signals
	reg				    r_bbox_en;				// bounding box enable
	reg				    r_bbox_en_1d;			// bounding box enable (1-cycle delay)
	reg				    r_bbox_en_2d;			// bounding box enable (2-cycle delay)
	reg				    r_bbox_en_3d;			// bounding box enable (3-cycle delay)
	wire			    w_bbox_en_x;			// bounding box enable x (2-cycle delay)
	wire			    w_bbox_en_y;			// bounding box enable y (2-cycle delay)
	wire			    w_bbox_en_w;			// bounding box enable w (2-cycle delay)
	wire			    w_bbox_en_h;			// bounding box enable h (2-cycle delay)
	reg			        r_bbox_en_x;			// bounding box enable x (3-cycle delay)
	reg			        r_bbox_en_y;			// bounding box enable y (3-cycle delay)
	reg			        r_bbox_en_w;			// bounding box enable w (3-cycle delay)
	reg			        r_bbox_en_h;			// bounding box enable h (3-cycle delay)
	reg signed [15:0]	r_bbox_data;			// bounding box data
	reg signed [15:0]	r_bbox_data_1d;			// bounding box data (1-cycle delay)
	reg signed [15:0]	r_bbox_data_2d;			// bounding box data (2-cycle delay)
	reg	       [3:0]	r_grid_x_cnt;			// grid X counter (0~6)
	reg	       [3:0]	w_nxt_grid_x_cnt;		// next grid X counter
	wire	       		w_grid_x_cnt_end;		// grid X count end
	reg	       [3:0]	r_grid_y_cnt;			// grid Y counter (0~6)
	reg	       [3:0]	w_nxt_grid_y_cnt;		// next grid Y counter
	wire	       		w_grid_y_cnt_end;		// grid Y count end
	reg	       [1:0]	r_field_ind;			// field indication
	reg	       [1:0]	r_field_ind_1d;			// field indication
	wire	       		w_field_cnt_end;		// field count end
	reg	       [3:0]	r_anchor_grid_cnt;		// anchor-per-grid counter
	reg	       [3:0]	w_nxt_anchor_grid_cnt;	// next anchor-per-grid counter
	reg	       [11:0]	r_anchor_cnt;			// anchor counter
	reg	       [11:0]	r_anchor_cnt_save;		// saved anchor counter
	wire	       		w_anchor_cnt_end;		// anchor count end
	reg	       			r_anchor_cnt_end;		// anchor count end
	reg	       [7:0]	w_anchor_x;				// anchor X
	reg	       [7:0]	w_anchor_y;				// anchor Y
	reg	       [7:0]	w_anchor_w;				// anchor W
	reg	       [7:0]	w_anchor_h;				// anchor H
	reg	       [7:0]	r_anchor_x;				// anchor X
	reg	       [7:0]	r_anchor_y;				// anchor Y
	reg	       [7:0]	r_anchor_w;				// anchor W
	reg	       [7:0]	r_anchor_h;				// anchor H
	reg	       [7:0]	r_anchor_x_1d;			// anchor X
	reg	       [7:0]	r_anchor_y_1d;			// anchor Y
	wire signed[24:0]	w_delta_x;				// delta_x * anchor_w
	wire signed[24:0]	w_delta_y;				// delta_y * anchor_h
	wire signed[24:0]	w_delta_w;				// delta_w * anchor_w
	wire signed[24:0]	w_delta_h;				// delta_h * anchor_h
	wire signed[14:0]	w_delta_sft_x;			// signed right shift by 11
	wire signed[14:0]	w_delta_sft_y;			// signed right shift by 11
	wire signed[14:0]	w_delta_sft_w;			// signed right shift by 11
	wire signed[14:0]	w_delta_sft_h;			// signed right shift by 11
	reg signed [12:0]	r_delta_sft_x;			// signed right shift by 11
	reg signed [12:0]	r_delta_sft_y;			// signed right shift by 11
	reg signed [12:0]	r_delta_sft_w;			// signed right shift by 11
	reg signed [12:0]	r_delta_sft_h;			// signed right shift by 11
	wire signed[12:0]	w_bbox_x;				// bounding box X
	wire signed[12:0]	w_bbox_y;				// bounding box Y
	wire signed[12:0]	w_bbox_w;				// bounding box W
	wire signed[12:0]	w_bbox_h;				// bounding box H
	wire       [7:0]  	w_bbox_clp_x;			// clamping
	wire       [7:0]  	w_bbox_clp_y;			// clamping
	wire       [7:0]  	w_bbox_clp_w;			// clamping
	wire       [7:0]  	w_bbox_clp_h;			// clamping
	reg        [7:0]  	r_bbox_x[0:TOP_N_DET-1];// bounding box X or min X
	reg        [7:0]  	r_bbox_y[0:TOP_N_DET-1];// bounding box Y or min X
	reg        [7:0]  	r_bbox_w[0:TOP_N_DET-1];// bounding box W or min X
	reg        [7:0]  	r_bbox_h[0:TOP_N_DET-1];// bounding box H or min X
	wire[TOP_N_DET-1:0]	w_cmp_idx;				// compare indices
	reg [TOP_N_DET-1:0]	r_cmp_idx;				// compare indices
	reg					r_nms_start;			// NMS start
	reg					r_nms_en;				// NMS enable
	reg 	   [4:0]	r_bbox_idx_hi;			// NMS higher index
	wire				w_idx_cnt_end_hi;		// NMS higher index count end
	reg 	   [4:0]	r_bbox_idx_lo;			// NMS lower index
	wire				w_idx_cnt_end_lo;		// NMS higher index count end
	wire				w_nms_end;				// NMS enable end
	wire[NUM_CLASS-1:0]	w_cls_bmap [0:TOP_N_DET-1];	// class bitmap
	wire[NUM_CLASS-1:0]	w_cls_bmap_hi;			// class bitmap for higher index
	wire[NUM_CLASS-1:0]	w_cls_bmap_lo;			// class bitmap for lower index
	reg			        r_nms_en_1d;			// 1-cycle delay of NMS enable
	reg			        r_nms_en_2d;			// 2-cycle delay of NMS enable
	reg			        r_nms_en_3d;			// 3-cycle delay of NMS enable
	reg			        r_nms_end;				// NMS end
	reg			        r_nms_end_1d;			// 1-cycle delay of NMS end
	reg			        r_nms_end_2d;			// 2-cycle delay of NMS end
	reg			        r_nms_end_3d;			// 3-cycle delay of NMS end
	reg			        r_nms_end_4d;			// 4-cycle delay of NMS end
	wire	[7:0]		w_bbox_x_hi;			// bounding box center x (high)
	wire	[7:0]		w_bbox_y_hi;			// bounding box center y (high)
	wire	[7:0]		w_bbox_w_hi;			// bounding box width (high)
	wire	[7:0]		w_bbox_h_hi;			// bounding box height (high)
	wire	[7:0]		w_bbox_x_lo;			// bounding box center x (low)
	wire	[7:0]		w_bbox_y_lo;			// bounding box center y (low)
	wire	[7:0]		w_bbox_w_lo;			// bounding box width (low)
	wire	[7:0]		w_bbox_h_lo;			// bounding box height (low)
	wire	[7:0]		w_bbox_min_x_hi;		// bounding box min X (high)
	wire	[7:0]		w_bbox_min_y_hi;		// bounding box min Y (high)
	wire	[7:0]		w_bbox_max_x_hi;		// bounding box max X (high)
	wire	[7:0]		w_bbox_max_y_hi;		// bounding box max Y (high)
	wire	[7:0]		w_bbox_min_x_lo;		// bounding box min X (low)
	wire	[7:0]		w_bbox_min_y_lo;		// bounding box min Y (low)
	wire	[7:0]		w_bbox_max_x_lo;		// bounding box max X (low)
	wire	[7:0]		w_bbox_max_y_lo;		// bounding box max Y (low)
	reg	    [7:0]		r_bbox_min_x_hi;		// bounding box min X (high)
	reg	    [7:0]		r_bbox_min_y_hi;		// bounding box min Y (high)
	reg	    [7:0]		r_bbox_max_x_hi;		// bounding box max X (high)
	reg	    [7:0]		r_bbox_max_y_hi;		// bounding box max Y (high)
	reg	    [7:0]		r_bbox_min_x_lo;		// bounding box min X (low)
	reg	    [7:0]		r_bbox_min_y_lo;		// bounding box min Y (low)
	reg	    [7:0]		r_bbox_max_x_lo;		// bounding box max X (low)
	reg	    [7:0]		r_bbox_max_y_lo;		// bounding box max Y (low)
	reg [NUM_CLASS-1:0]	r_cls_bmap_hi;			// class bitmap for higher index
	reg [NUM_CLASS-1:0]	r_cls_bmap_lo;		
	reg	    [4:0]		r_bbox_idx_lo_1d;		// NMS lower index (1 cycle delay)
	reg	    [4:0]		r_bbox_idx_lo_2d;		// NMS lower index (2 cycle delay)
	reg	    [4:0]		r_bbox_idx_lo_3d;		// NMS lower index (3 cycle delay)
	wire	[7:0]		w_bbox_width_hi;		// width of high probability
	wire	[7:0]		w_bbox_height_hi;		// height of high probability
	wire	[7:0]		w_bbox_width_lo;		// width of low probability
	wire	[7:0]		w_bbox_height_lo;		// height of low probability
	reg	    [7:0]		r_bbox_width_hi;		// width of high probability
	reg	    [7:0]		r_bbox_height_hi;		// height of high probability
	reg	    [7:0]		r_bbox_width_lo;		// width of low probability
	reg	    [7:0]		r_bbox_height_lo;		// height of low probability
	wire	[17:0]		w_bbox_area_hi;			// area of high probability
	wire	[17:0]		w_bbox_area_lo;			// area of low probability
	reg	    [17:0]		r_bbox_area_hi;			// area of high probability
	reg	    [17:0]		r_bbox_area_lo;			// area of low probability
	wire	[7:0]		w_ovlp_min_x;			// overlap min x
	wire	[7:0]		w_ovlp_min_y;			// overlap min y
	wire	[7:0]		w_ovlp_max_x;			// overlap max x
	wire	[7:0]		w_ovlp_max_y;			// overlap max y
	wire	[7:0]		w_ovlp_width;			// overlap width
	wire	[7:0]		w_ovlp_height;			// overlap height
	reg	    [7:0]		r_ovlp_width;			// overlap width
	reg	    [7:0]		r_ovlp_height;			// overlap height
	reg [NUM_CLASS-1:0]	r_cls_bmap_hi_1d;		// class bitmap for higher index
	reg [NUM_CLASS-1:0]	r_cls_bmap_lo_1d;		// class bitmap for lower index
	wire    [17:0]		w_ovlp_area;			// overlapped area
	reg	    [17:0]		r_ovlp_area;			// overlapped area
	reg [NUM_CLASS-1:0]	r_cls_bmap_hi_2d;		// class bitmap for higher index
	reg [NUM_CLASS-1:0]	r_cls_bmap_lo_2d;		// class bitmap for lower index
	wire [17:0]			w_union_area;			// union area
	wire				w_iou_th_chk;			// IOU threshold check
	reg [TOP_N_DET-1:0] o_bbox_bmap;

	assign w_bbox_en_x	= r_bbox_en_2d && (r_field_ind == 2'h0);
	assign w_bbox_en_y	= r_bbox_en_2d && (r_field_ind == 2'h1);
	assign w_bbox_en_w	= r_bbox_en_2d && (r_field_ind == 2'h2);
	assign w_bbox_en_h	= r_bbox_en_2d && (r_field_ind == 2'h3);
	assign w_grid_x_cnt_end	= r_grid_x_cnt == (NUM_X_GRID - 1);
	assign w_grid_y_cnt_end	= w_grid_x_cnt_end && (r_grid_y_cnt == (NUM_Y_GRID - 1));
	assign w_field_cnt_end	= w_grid_y_cnt_end && (r_field_ind == 2'h3);
	assign w_anchor_cnt_end	= w_field_cnt_end && (r_anchor_cnt == (NUM_ANCHOR - 1));

	// signed right shift by 11, aligned to decimal point
	assign w_delta_sft_x	= w_delta_x >>> NUM_FRAC;
	assign w_delta_sft_y	= w_delta_y >>> NUM_FRAC;
	assign w_delta_sft_w	= w_delta_w >>> NUM_FRAC;
	assign w_delta_sft_h	= w_delta_h >>> NUM_FRAC;

	// box coordinate
	assign w_bbox_x		= $signed({1'b0, r_anchor_x_1d}) + w_delta_sft_x;
	assign w_bbox_y		= $signed({1'b0, r_anchor_y_1d}) + w_delta_sft_y;
	assign w_bbox_w		= w_delta_sft_w;
	assign w_bbox_h		= w_delta_sft_h;

	// clamping
	assign w_bbox_clp_x	= (w_bbox_x < 15'h0)?	8'h0 : (w_bbox_x > 15'shdf)? 8'hdf : w_bbox_x[7:0];
	assign w_bbox_clp_y	= (w_bbox_y < 15'h0)?	8'h0 : (w_bbox_y > 15'shdf)? 8'hdf : w_bbox_y[7:0];
	assign w_bbox_clp_w	= (w_bbox_w < 15'h0)?	8'h0 : (w_bbox_w > 15'shdf)? 8'hdf : w_bbox_w[7:0];
	assign w_bbox_clp_h	= (w_bbox_h < 15'h0)?	8'h0 : (w_bbox_h > 15'shdf)? 8'hdf : w_bbox_h[7:0];

	// compare index
	assign w_cmp_idx[0]		= (r_anchor_cnt == i_idx_00);
	assign w_cmp_idx[1]		= (r_anchor_cnt == i_idx_01);
	assign w_cmp_idx[2]		= (r_anchor_cnt == i_idx_02);
	assign w_cmp_idx[3]		= (r_anchor_cnt == i_idx_03);
	assign w_cmp_idx[4]		= (r_anchor_cnt == i_idx_04);
	assign w_cmp_idx[5]		= (r_anchor_cnt == i_idx_05);
	assign w_cmp_idx[6]		= (r_anchor_cnt == i_idx_06);
	assign w_cmp_idx[7]		= (r_anchor_cnt == i_idx_07);
	assign w_cmp_idx[8]		= (r_anchor_cnt == i_idx_08);
	assign w_cmp_idx[9]		= (r_anchor_cnt == i_idx_09);

	assign w_idx_cnt_end_hi	= r_bbox_idx_hi == (TOP_N_DET - 2);

	assign w_idx_cnt_end_lo	= r_bbox_idx_lo == (TOP_N_DET - 1);
	assign w_nms_end		= w_idx_cnt_end_hi & w_idx_cnt_end_lo;
	assign w_cls_bmap_hi	= w_cls_bmap[r_bbox_idx_hi];
	assign w_cls_bmap_lo	= w_cls_bmap[r_bbox_idx_lo];
	assign w_bbox_x_hi	= r_bbox_x[r_bbox_idx_hi];
	assign w_bbox_y_hi	= r_bbox_y[r_bbox_idx_hi];
	assign w_bbox_w_hi	= r_bbox_w[r_bbox_idx_hi];
	assign w_bbox_h_hi	= r_bbox_h[r_bbox_idx_hi];

	assign w_bbox_x_lo	= r_bbox_x[r_bbox_idx_lo];
	assign w_bbox_y_lo	= r_bbox_y[r_bbox_idx_lo];
	assign w_bbox_w_lo	= r_bbox_w[r_bbox_idx_lo];
	assign w_bbox_h_lo	= r_bbox_h[r_bbox_idx_lo];

	assign w_bbox_min_x_hi	= min_coord(w_bbox_x_hi, w_bbox_w_hi, 8'h0);
	assign w_bbox_min_y_hi	= min_coord(w_bbox_y_hi, w_bbox_h_hi, 8'h0);
	assign w_bbox_max_x_hi	= max_coord(w_bbox_x_hi, w_bbox_w_hi, PIC_WIDTH);
	assign w_bbox_max_y_hi	= max_coord(w_bbox_y_hi, w_bbox_h_hi, PIC_HEIGHT);
	assign w_bbox_min_x_lo	= min_coord(w_bbox_x_lo, w_bbox_w_lo, 8'h0);
	assign w_bbox_min_y_lo	= min_coord(w_bbox_y_lo, w_bbox_h_lo, 8'h0);
	assign w_bbox_max_x_lo	= max_coord(w_bbox_x_lo, w_bbox_w_lo, PIC_WIDTH);
	assign w_bbox_max_y_lo	= max_coord(w_bbox_y_lo, w_bbox_h_lo, PIC_HEIGHT);

	// bounding box area
	assign w_bbox_width_hi	= (r_bbox_min_x_hi >= r_bbox_max_x_hi)? 8'h0 : (r_bbox_max_x_hi - r_bbox_min_x_hi);
	assign w_bbox_height_hi	= (r_bbox_min_y_hi >= r_bbox_max_y_hi)? 8'h0 : (r_bbox_max_y_hi - r_bbox_min_y_hi);
	assign w_bbox_width_lo	= (r_bbox_min_x_lo >= r_bbox_max_x_lo)? 8'h0 : (r_bbox_max_x_lo - r_bbox_min_x_lo);
	assign w_bbox_height_lo	= (r_bbox_min_y_lo >= r_bbox_max_y_lo)? 8'h0 : (r_bbox_max_y_lo - r_bbox_min_y_lo);

	// overlap check
	assign w_ovlp_min_x	= max2(r_bbox_min_x_hi, r_bbox_min_x_lo);
	assign w_ovlp_min_y	= max2(r_bbox_min_y_hi, r_bbox_min_y_lo);
	assign w_ovlp_max_x	= min2(r_bbox_max_x_hi, r_bbox_max_x_lo);
	assign w_ovlp_max_y	= min2(r_bbox_max_y_hi, r_bbox_max_y_lo);

	assign w_ovlp_width	= (w_ovlp_min_x >= w_ovlp_max_x)? 8'h0 : (w_ovlp_max_x - w_ovlp_min_x);
	assign w_ovlp_height	= (w_ovlp_min_y >= w_ovlp_max_y)? 8'h0 : (w_ovlp_max_y - w_ovlp_min_y);


	assign w_bbox_area_hi	= r_bbox_width_hi * r_bbox_height_hi;
	assign w_bbox_area_lo	= r_bbox_width_lo * r_bbox_height_lo;
	assign w_ovlp_area		= r_ovlp_width * r_ovlp_height;

	assign w_union_area	= (r_bbox_area_hi + r_bbox_area_lo - r_ovlp_area);
	assign w_iou_th_chk	= (((r_ovlp_area * OVLP_TH_2X / 2) > w_union_area) || (r_bbox_idx_lo_3d >= i_num_conf))&&
					(r_cls_bmap_hi_2d == r_cls_bmap_lo_2d);

	assign o_bbox_00	= {r_bbox_h[00], r_bbox_w[00], r_bbox_y[00], r_bbox_x[00]};
	assign o_bbox_01	= {r_bbox_h[01], r_bbox_w[01], r_bbox_y[01], r_bbox_x[01]};
	assign o_bbox_02	= {r_bbox_h[02], r_bbox_w[02], r_bbox_y[02], r_bbox_x[02]};
	assign o_bbox_03	= {r_bbox_h[03], r_bbox_w[03], r_bbox_y[03], r_bbox_x[03]};
	assign o_bbox_04	= {r_bbox_h[04], r_bbox_w[04], r_bbox_y[04], r_bbox_x[04]};
	assign o_bbox_05	= {r_bbox_h[05], r_bbox_w[05], r_bbox_y[05], r_bbox_x[05]};
	assign o_bbox_06	= {r_bbox_h[06], r_bbox_w[06], r_bbox_y[06], r_bbox_x[06]};
	assign o_bbox_07	= {r_bbox_h[07], r_bbox_w[07], r_bbox_y[07], r_bbox_x[07]};
	assign o_bbox_08	= {r_bbox_h[08], r_bbox_w[08], r_bbox_y[08], r_bbox_x[08]};
	assign o_bbox_09	= {r_bbox_h[09], r_bbox_w[09], r_bbox_y[09], r_bbox_x[09]};

	//*************************************
	// input interface
	//*************************************

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_bbox_en		<= 1'b0;
			r_bbox_en_1d	<= 1'b0;
			r_bbox_en_2d	<= 1'b0;
			r_bbox_en_3d	<= 1'b0;
			r_bbox_data		<= 16'h0;
			r_bbox_data_1d	<= 16'h0;
			r_bbox_data_2d	<= 16'h0;
		end
		else begin
			r_bbox_en		<= i_bbox_en;
			r_bbox_en_1d	<= r_bbox_en;
			r_bbox_en_2d	<= r_bbox_en_1d;
			r_bbox_en_3d	<= r_bbox_en_2d;
			r_bbox_data		<= $signed(i_bbox_data);
			r_bbox_data_1d	<= r_bbox_data;
			r_bbox_data_2d	<= r_bbox_data_1d;
		end
	end

	//*************************************
	// timing counters
	//*************************************

	// grid X counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_grid_x_cnt	<= 4'h0;
		else if (i_out_start)
			r_grid_x_cnt	<= 4'h0;
		else if (r_bbox_en_2d) begin
			if (w_grid_x_cnt_end)
				r_grid_x_cnt	<= 4'h0;
			else
				r_grid_x_cnt	<= r_grid_x_cnt + 4'h1;
		end
	end

	always @(*)
	begin
		if (i_out_start)
			w_nxt_grid_x_cnt	= 4'h0;
		else if (r_bbox_en_2d) begin
			if (w_grid_x_cnt_end)
				w_nxt_grid_x_cnt = 4'h0;
			else
				w_nxt_grid_x_cnt = r_grid_x_cnt + 4'h1;
		end
		else
			w_nxt_grid_x_cnt	= r_grid_x_cnt;
	end

	// grid Y counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_grid_y_cnt	<= 4'h0;
		else if (i_out_start)
			r_grid_y_cnt	<= 4'h0;
		else if (r_bbox_en_2d && w_grid_x_cnt_end) begin
			if (w_grid_y_cnt_end)
				r_grid_y_cnt	<= 4'h0;
			else
				r_grid_y_cnt	<= r_grid_y_cnt + 4'h1;
		end
	end

	always @(*)
	begin
		if (i_out_start)
			w_nxt_grid_y_cnt	= 4'h0;
		else if (r_bbox_en_2d && w_grid_x_cnt_end) begin
			if (w_grid_y_cnt_end)
				w_nxt_grid_y_cnt = 4'h0;
			else
				w_nxt_grid_y_cnt = r_grid_y_cnt + 4'h1;
		end
		else
			w_nxt_grid_y_cnt	= r_grid_y_cnt;
	end

	// field indication
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_field_ind	<= 2'h0;
		else if (i_out_start)
			r_field_ind	<= 2'h0;
		else if (r_bbox_en_2d && w_grid_y_cnt_end)
			r_field_ind	<= r_field_ind + 2'h1;
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_field_ind_1d	<= 2'h0;
		else
			r_field_ind_1d	<= r_field_ind;
	end

	// anchor-per-grid counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_grid_cnt	<= 4'h0;
		else if (i_out_start)
			r_anchor_grid_cnt	<= 4'h0;
		else if (r_bbox_en_2d) begin
			if (w_anchor_cnt_end)
				r_anchor_grid_cnt <= 4'h0;
			else if (w_field_cnt_end) 
				r_anchor_grid_cnt <= r_anchor_grid_cnt + 4'h1;
		end
	end

	always @(*)
	begin
		if (i_out_start)
			w_nxt_anchor_grid_cnt	= 4'h0;
		else if (r_bbox_en_2d) begin
			if (w_anchor_cnt_end)
				w_nxt_anchor_grid_cnt	= 4'h0;
			else if (w_field_cnt_end)
				w_nxt_anchor_grid_cnt	= r_anchor_grid_cnt + 4'h1;
			else
				w_nxt_anchor_grid_cnt	= r_anchor_grid_cnt;
		end
		else begin
			w_nxt_anchor_grid_cnt	= r_anchor_grid_cnt;
		end
	end

	// anchor counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_cnt	<= 12'h0;
		else if (i_out_start)
			r_anchor_cnt	<= 12'h0;
		else if (r_bbox_en_2d) begin
			if (w_anchor_cnt_end)
				r_anchor_cnt	<= 12'h0;
			else if (w_field_cnt_end)
				r_anchor_cnt	<= r_anchor_cnt + 12'h1;
			else if (w_grid_y_cnt_end)
				r_anchor_cnt	<= r_anchor_cnt_save;
			else
				r_anchor_cnt	<= r_anchor_cnt + 12'h1;
		end
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_cnt_save	<= 12'h0;
		else if (i_out_start)
			r_anchor_cnt_save	<= 12'h0;
		else if (r_bbox_en_2d && w_field_cnt_end)
			r_anchor_cnt_save	<= r_anchor_cnt + 12'h1;
	end

	//*************************************
	// coordinate manipulation
	//*************************************

	// anchor X
	always @(*)
	begin
		case (w_nxt_grid_x_cnt)
            4'h0	: w_anchor_x	= 8'd15;   // changed w_anchor_x values for 0 to 13
			4'h1	: w_anchor_x	= 8'd30;
			4'h2	: w_anchor_x	= 8'd45;
			4'h3	: w_anchor_x	= 8'd60;
			4'h4	: w_anchor_x	= 8'd75;
			4'h5	: w_anchor_x	= 8'd90;
			4'h6	: w_anchor_x	= 8'd105;
			4'h7	: w_anchor_x	= 8'd119;
			4'h8	: w_anchor_x	= 8'd134;
			4'h9	: w_anchor_x	= 8'd149;
			4'ha	: w_anchor_x	= 8'd164;
			4'hb	: w_anchor_x	= 8'd179;
			4'hc	: w_anchor_x	= 8'd194;
			4'hd	: w_anchor_x	= 8'd209;
			default	: w_anchor_x	= 8'd0;
		endcase
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_x	<= 8'h0;
		else if (i_out_start || r_bbox_en_2d)
			r_anchor_x	<= w_anchor_x;
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_x_1d	<= 8'h0;
		else
			r_anchor_x_1d	<= r_anchor_x;
	end

	// anchor Y
	always @(*)
	begin
		case (w_nxt_grid_y_cnt)
            4'h0	: w_anchor_y	= 8'd15;  // changed for w_anchor_y for 0 to 13
			4'h1	: w_anchor_y	= 8'd30;
			4'h2	: w_anchor_y	= 8'd45;
			4'h3	: w_anchor_y	= 8'd60;
			4'h4	: w_anchor_y	= 8'd75;
			4'h5	: w_anchor_y	= 8'd90;
			4'h6	: w_anchor_y	= 8'd105;
			4'h7	: w_anchor_y	= 8'd119;
			4'h8	: w_anchor_y	= 8'd134;
			4'h9	: w_anchor_y	= 8'd149;
			4'ha	: w_anchor_y	= 8'd164;
			4'hb	: w_anchor_y	= 8'd179;
			4'hc	: w_anchor_y	= 8'd194;
			4'hd	: w_anchor_y	= 8'd209;
			default	: w_anchor_y	= 8'd0;
		endcase
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_y	<= 8'h0;
		else if (i_out_start || (r_bbox_en_2d && w_grid_x_cnt_end))
			r_anchor_y	<= w_anchor_y;
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_y_1d	<= 8'h0;
		else
			r_anchor_y_1d	<= r_anchor_y;
	end

	// for # of anchors of 7
	always @(*)
	begin
		case (w_nxt_anchor_grid_cnt)
			4'h0	: begin
				w_anchor_w	= 8'd184;
				w_anchor_h	= 8'd184;
			end
			4'h1	: begin
				w_anchor_w	= 8'd138;
				w_anchor_h	= 8'd138;
			end
			4'h2	: begin
				w_anchor_w	= 8'd92;
				w_anchor_h	= 8'd92;
			end
			4'h3	: begin
				w_anchor_w	= 8'd69;
				w_anchor_h	= 8'd69;
			end
			4'h4	: begin
				w_anchor_w	= 8'd46;
				w_anchor_h	= 8'd46;
			end
			4'h5	: begin
				w_anchor_w	= 8'd34;
				w_anchor_h	= 8'd34;
			end
			4'h6	: begin
				w_anchor_w	= 8'd23;
				w_anchor_h	= 8'd23;
			end
			default	: begin
				w_anchor_w	= 8'd0;
				w_anchor_h	= 8'd0;
			end
		endcase
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_anchor_w	<= 8'h0;
			r_anchor_h	<= 8'h0;
		end
		else if (i_out_start || (r_bbox_en_2d && w_field_cnt_end)) begin
			r_anchor_w	<= w_anchor_w;
			r_anchor_h	<= w_anchor_h;
		end
	end

	//*************************************
	// bounding box storage
	//*************************************

	// pick 30 class information based on confidence index
	genvar i;
	generate
		for (i = 0; i < TOP_N_DET; i=i+1) begin : ST_CLS
			always @(posedge clk or negedge resetn)
			begin
				if (!resetn) begin
					r_bbox_x[i]	<= 8'h0;
					r_bbox_y[i]	<= 8'h0;
					r_bbox_w[i]	<= 8'h0;
					r_bbox_h[i]	<= 8'h0;
				end
				else if (i_out_start) begin
					r_bbox_x[i]	<= 8'h0;
					r_bbox_y[i]	<= 8'h0;
					r_bbox_w[i]	<= 8'h0;
					r_bbox_h[i]	<= 8'h0;
				end
				else if (r_bbox_en_3d && r_cmp_idx[i]) begin
					case (r_field_ind_1d)
						2'h0 :	r_bbox_x[i] <= w_bbox_clp_x;
						2'h1 :	r_bbox_y[i] <= w_bbox_clp_y;
						2'h2 :	r_bbox_w[i] <= w_bbox_clp_w;
						2'h3 :	r_bbox_h[i] <= w_bbox_clp_h;
					endcase
				end
			end
		end
	endgenerate

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_cmp_idx	<= 'h0;
		else
			r_cmp_idx	<= w_cmp_idx;
	end

	//*************************************
	// NMS (non-maximum supporession)
	//*************************************

	// NMS enable
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_anchor_cnt_end	<= 1'b0;
			r_nms_start		<= 1'b0;
		end
		else begin
			r_anchor_cnt_end	<= r_bbox_en_2d && w_anchor_cnt_end;
			r_nms_start		<= r_anchor_cnt_end;
		end
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_nms_en	<= 1'b0;
		else if (i_out_start)
			r_nms_en	<= 1'b0;
		else if (r_nms_start)
			r_nms_en	<= 1'b1;
		else if (w_nms_end)
			r_nms_en	<= 1'b0;
	end

	// index counting
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_bbox_idx_hi	<= 5'h0;
		else if (i_out_start)
			r_bbox_idx_hi	<= 5'h0;
		else if (w_idx_cnt_end_lo)
			r_bbox_idx_hi	<= r_bbox_idx_hi + 5'h1;
	end



	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_bbox_idx_lo	<= 5'h0;
		else if (i_out_start)
			r_bbox_idx_lo	<= 5'h1;
		else if (w_idx_cnt_end_lo)
			r_bbox_idx_lo	<= r_bbox_idx_hi + 5'h2;
		else if (r_nms_en)
			r_bbox_idx_lo	<= r_bbox_idx_lo + 5'h1;
	end
	
	genvar	j;
	for (j = 0; j < TOP_N_DET; j = j + 1)
		assign w_cls_bmap[j] = i_cls_bmap[(j+1)*NUM_CLASS-1:j*NUM_CLASS];

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_nms_en_1d	<= 1'b0;
			r_nms_en_2d	<= 1'b0;
			r_nms_en_3d	<= 1'b0;
			r_nms_end	<= 1'b0;
			r_nms_end_1d	<= 1'b0;
			r_nms_end_2d	<= 1'b0;
			r_nms_end_3d	<= 1'b0;
			r_nms_end_4d	<= 1'b0;
		end
		else begin
			r_nms_en_1d	<= r_nms_en;
			r_nms_en_2d	<= r_nms_en_1d;
			r_nms_en_3d	<= r_nms_en_2d;
			r_nms_end	<= w_nms_end;
			r_nms_end_1d	<= r_nms_end;
			r_nms_end_2d	<= r_nms_end_1d;
			r_nms_end_3d	<= r_nms_end_2d;
			r_nms_end_4d	<= r_nms_end_3d;
		end
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_bbox_min_x_hi		<= 8'h0;
			r_bbox_min_y_hi		<= 8'h0;
			r_bbox_max_x_hi		<= 8'h0;
			r_bbox_max_y_hi		<= 8'h0;
			r_bbox_min_x_lo		<= 8'h0;
			r_bbox_min_y_lo		<= 8'h0;
			r_bbox_max_x_lo		<= 8'h0;
			r_bbox_max_y_lo		<= 8'h0;
			r_cls_bmap_hi		<= 'h0;
			r_cls_bmap_lo		<= 'h0;
		end
		else if (r_nms_en) begin
			r_bbox_min_x_hi		<= w_bbox_min_x_hi;
			r_bbox_min_y_hi		<= w_bbox_min_y_hi;
			r_bbox_max_x_hi		<= w_bbox_max_x_hi;
			r_bbox_max_y_hi		<= w_bbox_max_y_hi;
			r_bbox_min_x_lo		<= w_bbox_min_x_lo;
			r_bbox_min_y_lo		<= w_bbox_min_y_lo;
			r_bbox_max_x_lo		<= w_bbox_max_x_lo;
			r_bbox_max_y_lo		<= w_bbox_max_y_lo;
			r_cls_bmap_hi		<= w_cls_bmap_hi;
			r_cls_bmap_lo		<= w_cls_bmap_lo;
		end
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_bbox_idx_lo_1d	<= 5'h0;
			r_bbox_idx_lo_2d	<= 5'h0;
			r_bbox_idx_lo_3d	<= 5'h0;
		end
		else begin
			r_bbox_idx_lo_1d	<= r_bbox_idx_lo;
			r_bbox_idx_lo_2d	<= r_bbox_idx_lo_1d;
			r_bbox_idx_lo_3d	<= r_bbox_idx_lo_2d;
		end
	end



	// overlapped area
	//	- not using IOU, just using area
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_bbox_width_hi		<= 8'h0;
			r_bbox_height_hi	<= 8'h0;
			r_bbox_width_lo		<= 8'h0;
			r_bbox_height_lo	<= 8'h0;
			r_ovlp_width		<= 8'h0;
			r_ovlp_height		<= 8'h0;
			r_cls_bmap_hi_1d	<= 'h0;
			r_cls_bmap_lo_1d	<= 'h0;
		end
		else if (r_nms_en_1d) begin
			r_bbox_width_hi		<= w_bbox_width_hi;
			r_bbox_height_hi	<= w_bbox_height_hi;
			r_bbox_width_lo		<= w_bbox_width_lo;
			r_bbox_height_lo	<= w_bbox_height_lo;
			r_ovlp_width		<= w_ovlp_width;
			r_ovlp_height		<= w_ovlp_height;
			r_cls_bmap_hi_1d	<= r_cls_bmap_hi;
			r_cls_bmap_lo_1d	<= r_cls_bmap_lo;
		end
	end

	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_bbox_area_hi	  <= 18'h0;
			r_bbox_area_lo	  <= 18'h0;
			r_ovlp_area	  <= 18'h0;
			r_cls_bmap_hi_2d  <= 'h0;
			r_cls_bmap_lo_2d  <= 'h0;
		end
		else if (r_nms_en_2d) begin
			r_bbox_area_hi	  <= w_bbox_area_hi;
			r_bbox_area_lo	  <= w_bbox_area_lo;
			r_ovlp_area	  <= w_ovlp_area;
			r_cls_bmap_hi_2d  <= r_cls_bmap_hi_1d;
			r_cls_bmap_lo_2d  <= r_cls_bmap_lo_1d;
		end
	end

	// valid bitmap
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			o_bbox_bmap	<= 'h0;
		else if (i_out_start)
			o_bbox_bmap	<= {TOP_N_DET{1'b1}};
		else if (r_nms_start && (i_num_conf == 5'h0))
			o_bbox_bmap	<= {TOP_N_DET{1'b0}};
		else if (r_nms_en_3d && w_iou_th_chk)
			o_bbox_bmap[r_bbox_idx_lo_3d]	<= 1'b0;
	end

	// bounding box output
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			o_out_en	<= 1'b0;
		else
			o_out_en	<= r_nms_end_4d;
	end
	
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			tot_det	<= 1'b0;
		else
			tot_det	<= o_bbox_bmap & i_tot_det;
	end

	// multiplier
	//	- effective bit range of r_anchor_{w,h} is [6:0] (20~120).
	det_mult	u_delta_x
	(
		.clk_i		(clk ),
		.clk_en_i	(r_bbox_en_2d),
		.rst_i		(~resetn),
		.data_a_i	(r_bbox_data_2d	),
		.data_b_i	({1'b0, r_anchor_w[7:0]}),
		.result_o	(w_delta_x)
	);

	det_mult	u_delta_y
	(
		.clk_i		(clk),
		.clk_en_i	(r_bbox_en_2d),
		.rst_i		(~resetn),
		.data_a_i	(r_bbox_data_2d),
		.data_b_i	({1'b0, r_anchor_h[7:0]}),
		.result_o	(w_delta_y)
	);

	det_mult	u_delta_w
	(
		.clk_i		(clk),
		.clk_en_i	(r_bbox_en_2d),
		.rst_i		(~resetn),
		.data_a_i	(r_bbox_data_2d	),
		.data_b_i	({1'b0, r_anchor_w[7:0]}),
		.result_o	(w_delta_w	)
	);

	det_mult	u_delta_h
	(
		.clk_i		(clk),
		.clk_en_i	(r_bbox_en_2d),
		.rst_i		(~resetn),
		.data_a_i	(r_bbox_data_2d	),
		.data_b_i	({1'b0, r_anchor_h[7:0]}),
		.result_o	(w_delta_h)
	);


	//*************************************
	// functions
	//*************************************

	// minimum coordinate
	function	[7:0]	min_coord;
		input		[7:0]	center;
		input		[7:0]	range;
		input		[7:0]	min_range;

		reg signed	[9:0]	coord;

		begin
			coord		= $signed({1'b0, center}) - $signed({2'h0, range[7:1]});
			min_coord	= (coord < $signed({2'h0, min_range}))? min_range : coord[7:0];
		end

	endfunction

	// maximum coordinate
	function	[7:0]	max_coord;
		input		[7:0]	center;
		input		[7:0]	range;
		input		[7:0]	max_range;

		reg signed	[9:0]	coord;

		begin
			coord		= $signed({1'b0, center}) + $signed({2'h0, range[7:1]}) - 10'sh1;
			max_coord	= (coord >= $signed({2'h0, max_range}))? max_range - 1 : coord[7:0];
		end

	endfunction

	// maximum of 2
	function	[7:0]	max2;
		input	[7:0]	a;
		input	[7:0]	b;

		begin
			max2	= (a >= b)? a : b;
		end

	endfunction

	// minimum of 2
	function	[7:0]	min2;
		input	[7:0]	a;
		input	[7:0]	b;

		begin
			min2	= (a < b)? a : b;
		end

	endfunction


endmodule

// vim:foldmethod=marker:
//
