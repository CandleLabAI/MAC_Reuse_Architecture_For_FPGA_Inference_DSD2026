
`timescale 1ns/10ps

module det_sort_conf	#(parameter NUM_ANCHOR	= 12'd448,		// number of anchors
									TOP_N_DET	= 5'd10)		// top N detection
(
	input			   			clk,					// data out clock
	input			   			resetn,
	input signed [15:0]	   		i_conf_th,				// confidence threshold
	input			   			i_out_start,				// out start
	input			   			i_conf_en,				// confidence score enable
	input signed [15:0]	   		i_conf_score,			// confidence score
	output reg		   			o_out_en,				// output enable
	output reg   [4:0]	   		o_num_conf,				// number of conf score (> threshold)
	output reg [TOP_N_DET-1:0]  o_tot_det,
	output wire [15:0]	   		o_conf_00,				// confidence score 00
	output wire [15:0]	   		o_conf_01,				// confidence score 01
	output wire [15:0]	   		o_conf_02,				// confidence score 02
	output wire [15:0]	   		o_conf_03,				// confidence score 03
	output wire [11:0]	   		o_idx_00,				// sorted index 00
	output wire [11:0]	   		o_idx_01,				// sorted index 01
	output wire [11:0]	   		o_idx_02,				// sorted index 02
	output wire [11:0]	   		o_idx_03,				// sorted index 03
	output wire [11:0]	   		o_idx_04,				// sorted index 04
	output wire [11:0]	   		o_idx_05,				// sorted index 05
	output wire [11:0]	   		o_idx_06,				// sorted index 06
	output wire [11:0]	   		o_idx_07,				// sorted index 07
	output wire [11:0]	   		o_idx_08,				// sorted index 08
	output wire [11:0]	   		o_idx_09				// sorted index 09
);

	// internal signals
	reg		  		  r_conf_en;			// conf score enable
	reg		  		  r_conf_en_1d;			// conf score enable (1-cycle delay)
	reg		  		  r_conf_en_2d;			// conf score enable (2-cycle delay)
	reg signed [15:0] r_conf_score;			// conf score
	reg signed [15:0] r_conf_score_1d;		// conf score (1-cycle delay)
	reg signed [15:0] r_conf_score_2d;		// conf score (2-cycle delay)
	reg	   [11:0] 	  r_anchor_cnt;			// anchor counter (0~293)
	wire		  	  w_anchor_cnt_end;		// anchor count end
	wire		  	  w_out_en;				// output enable timing

	reg signed [15:0] r_sort_conf [0:TOP_N_DET];	// sorted confidence score
	reg	   [11:0] 	  r_sort_idx [0:TOP_N_DET];	// sorted index

	wire [TOP_N_DET:0] w_cmp_conf;			// compare confidence score
	wire [TOP_N_DET:1] w_cmp_update;		// update enable based on comparison of conf_score

	assign w_anchor_cnt_end	= r_anchor_cnt == NUM_ANCHOR;
	assign w_out_en			= r_conf_en_2d && (r_anchor_cnt == (NUM_ANCHOR - 1));
	assign w_cmp_conf[0]	= 0;

	assign o_idx_00		= r_sort_idx[1];
	assign o_idx_01		= r_sort_idx[2];
	assign o_idx_02		= r_sort_idx[3];
	assign o_idx_03		= r_sort_idx[4];
	assign o_idx_04		= r_sort_idx[5];
	assign o_idx_05		= r_sort_idx[6];
	assign o_idx_06		= r_sort_idx[7];
	assign o_idx_07		= r_sort_idx[8];
	assign o_idx_08		= r_sort_idx[9];
	assign o_idx_09		= r_sort_idx[10];

	// input register
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn) begin
			r_conf_en	<= 1'b0;
			r_conf_en_1d	<= 1'b0;
			r_conf_en_2d	<= 1'b0;
			r_conf_score	<= 16'h0;
			r_conf_score_1d	<= 16'h0;
			r_conf_score_2d	<= 16'h0;
		end
		else begin
			r_conf_en	<= i_conf_en;
			r_conf_en_1d	<= r_conf_en;
			r_conf_en_2d	<= r_conf_en_1d;
			r_conf_score	<= $signed(i_conf_score);
			r_conf_score_1d	<= r_conf_score;
			r_conf_score_2d	<= r_conf_score_1d;
		end
	end

	// anchor counter
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			r_anchor_cnt	<= 12'h0;
		else if (i_out_start)
			r_anchor_cnt	<= 12'h0;
		else if (r_conf_en_2d && !w_anchor_cnt_end)
			r_anchor_cnt	<= r_anchor_cnt + 12'h1;
	end

	// compare and update
	//  - pick 10 largest confidence anchors
	genvar i;
	generate
		for (i = 1; i <= TOP_N_DET; i=i+1) begin : CMP_CONF	// i = index + 1 due to initial condition (1 ~ 30)
			always @(posedge clk or negedge resetn)
			begin
				if (!resetn) begin
					r_sort_conf[i]	<= 16'h0;
					r_sort_idx[i]	<= 12'h0;
				end
				else if (i_out_start) begin
					r_sort_conf[i]	<= 16'h8000;
					r_sort_idx[i]	<= 12'h0;
				end
				else if (r_conf_en_2d) begin
					if (w_cmp_update[i]) begin
						r_sort_conf[i]	<= r_conf_score_2d;
						r_sort_idx[i]	<= r_anchor_cnt;
					end
					else if (w_cmp_conf[i]) begin
						r_sort_conf[i]	<= r_sort_conf[i-1];
						r_sort_idx[i]	<= r_sort_idx[i-1];
					end
				end
			end
			assign w_cmp_conf[i]	= (r_conf_score_2d >= r_sort_conf[i]) && (r_conf_score_2d >= i_conf_th);
			assign w_cmp_update[i]	= ~w_cmp_conf[i-1] & w_cmp_conf[i];
		end
	endgenerate

	// number of confidence score 
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)	begin
			o_num_conf	<= 5'h0;
			o_tot_det	<={TOP_N_DET{1'b0}};
		end
		else if (i_out_start)
			o_num_conf	<= 5'h0;
		else if (r_conf_en_2d && |w_cmp_conf && o_num_conf < TOP_N_DET) begin
			o_num_conf	<= o_num_conf + 5'h1;
			o_tot_det[o_num_conf]	<= 1'b1;
		end
	end

	// output timing
	always @(posedge clk or negedge resetn)
	begin
		if (!resetn)
			o_out_en	<= 1'b0;
		else
			o_out_en	<= w_out_en;
	end

endmodule

// vim:foldmethod=marker:
//
