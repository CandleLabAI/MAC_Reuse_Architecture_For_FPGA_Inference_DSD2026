// ====================================================================
// Single Stage operations of squareroot calculations captured in this
// module. This has to be instantiated for HWIDTH times in the
// wrapper to get the final square root value of the given number
// DWIDTH= Input DATA WIDTH
// HWIDTH= Half of input data width,also the output data width
// RWIDTH= intermediate recurrent data width=HWIDTH+2.
// ====================================================================
module square_root #(
   parameter DWIDTH = 36,
   parameter RWIDTH = 20,
   parameter HWIDTH = 18
   )
   (
   input                        clk       ,
   input                        resetn    ,
   input                        valid_in  ,
   input           [DWIDTH-1:0] a_in      ,
   input           [RWIDTH-1:0] r_in      ,
   input           [HWIDTH-1:0] q_in      ,

   output reg                   valid_out ,
   output reg      [DWIDTH-1:0] a_out     ,
   output reg      [RWIDTH-1:0] r_out     ,
   output reg      [HWIDTH-1:0] q_out
);

// ====================================================================
//internal variables
// ====================================================================
   wire [RWIDTH-1:0] left, right;
   reg  [RWIDTH-1:0] r_r01 ;
   reg  [DWIDTH-1:0] a_r01 ;
   reg  [HWIDTH-1:0] q_r01 ;
   reg               valid_01;
// ====================================================================
// logic begins 
// ====================================================================
   assign left  = {r_in[HWIDTH-1:0],a_in[DWIDTH-1:DWIDTH-2]} ;
   assign right = {q_in,r_in[RWIDTH-1],1'b1}     ;
   // assign q_out = {q_r01[HWIDTH-2:0],!r_out[RWIDTH-1]};
   
   always@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         a_out     <= 0;
         q_out     <= 0;
         r_out     <= 0;
         r_r01     <= 0;
         a_r01     <= 0;
         q_r01     <= 0;
         valid_01  <= 0;
         valid_out <= 0;
      end
      else begin
         // #1
         a_r01     <= {a_in[DWIDTH-3:0],2'b0};
         r_r01     <= (r_in[RWIDTH-1]) ? left + right : left - right;
         q_r01     <= q_in;
         valid_01  <= valid_in;

         // #2
         a_out     <= a_r01;
         r_out     <= r_r01;
         q_out     <= {q_r01[HWIDTH-2:0],!r_r01[RWIDTH-1]};
         valid_out <= valid_01;
       end
   end

// ====================================================================
// logic ends 
// ====================================================================

endmodule
// ====================================================================
