module minimum(
    input          	clk,
    input         	resetn,
    input   [4:0]  	valid_in,
    
    input   [17:0]  distance_0,
    input   [17:0]  distance_1,
    input   [17:0]  distance_2,
    input   [17:0]  distance_3,
    input   [17:0]  distance_4,
    
    output  [4:0]   valid_out,
    output  [16:0]  minimum,
    output  [9:0]   index
);
 
wire [16:0] dst_0;
wire [16:0] dst_1;
wire [16:0] dst_2;
wire [16:0] dst_3;
wire [16:0] dst_4;

reg  [16:0]  minimum_reg;
reg  [9:0]   index_reg;
reg  [4:0]   min_dist_vld;

assign minimum = minimum_reg;
assign index   = index_reg;  
assign valid_out = min_dist_vld;

assign dst_0 = (valid_in[0]) ? distance_0 : 18'd65535;
assign dst_1 = (valid_in[1]) ? distance_1 : 18'd65535;
assign dst_2 = (valid_in[2]) ? distance_2 : 18'd65535;
assign dst_3 = (valid_in[3]) ? distance_3 : 18'd65535;
assign dst_4 = (valid_in[4]) ? distance_4 : 18'd65535;

always@(posedge clk or negedge resetn) begin
	if (!resetn) begin
		minimum_reg <= 17'h0;
		index_reg	<= 10'h0;
	end
	else begin
	    min_dist_vld <= valid_in;
		if((dst_0<=dst_1) && (dst_0<=dst_2) && (dst_0<=dst_3) && (dst_0<=dst_4)) begin 
			minimum_reg <= dst_0;
			index_reg   <= 10'd0;
		end
		else if((dst_1<=dst_0) && (dst_1<=dst_2) && (dst_1<=dst_3) && (dst_1<=dst_4)) begin
			minimum_reg <= dst_1;
			index_reg 	<= 10'd1;
		end
		else if((dst_2<=dst_0) && (dst_2<=dst_1) && (dst_2<=dst_3) && (dst_2<=dst_4)) begin
			minimum_reg <= dst_2;
			index_reg 	<= 10'd2; 
		end
		else if((dst_3<=dst_0) && (dst_3<=dst_1) && (dst_3<=dst_2) && (dst_3<=dst_4)) begin
			minimum_reg <= dst_3;
			index_reg 	<= 10'd3;
		end
		else begin
			minimum_reg <= dst_4;
			index_reg 	<= 10'd4;
		end
	end
  end
endmodule
