// =================================================================================================
//Centroid_tracker algorithm 
// =================================================================================================

module centroid_tracker  #(
    parameter INPUT_WIDTH       = 5'd8,
    parameter NUM_CLASS         = 5'd5,
    parameter MULT_FACTOR_WIDTH = 5'd8,
    parameter FP_WIDTH          = 5'd16,//INPUT_WIDTH+MULT_FACTOR_WIDTH,
    parameter ID_WIDTH          = 4'd10,//4'd10 or 4'd8
    parameter OP_WIDTH          = 6'd32,
    parameter IMG_WIDTH         = 8'd224,
    parameter IMG_HEIGHT        = 8'd224,
    parameter DEL_MAX           = 5'd25
    )(
    input                                 clk,
    input                                 resetn,
    input                                 i_vs,
    input  [(INPUT_WIDTH*4)-1:0]          i_bbox_00  , // x1, y1, x2, y2 
    input  [(INPUT_WIDTH*4)-1:0]          i_bbox_01  ,
    input  [(INPUT_WIDTH*4)-1:0]          i_bbox_02  ,
    input  [(INPUT_WIDTH*4)-1:0]          i_bbox_03  ,
    input  [(INPUT_WIDTH*4)-1:0]          i_bbox_04  ,
    input  [4:0]                          i_bbox_bmap,//TOP_N_DET-1
    input  [(5*NUM_CLASS)-1:0]            i_cls_bmap,    
    output [4:0]                     	  o_box_vld,//To indicate how many of them are valid out of 5
    output [(5*NUM_CLASS)-1:0]        	  o_cls_bmap,
    output [(ID_WIDTH*NUM_CLASS)-1:0]     count_list,
    output [OP_WIDTH-1:0]                 final_tracklist1,
    output [OP_WIDTH-1:0]                 final_tracklist2,
    output [OP_WIDTH-1:0]                 final_tracklist3,
    output [OP_WIDTH-1:0]                 final_tracklist4,
    output [OP_WIDTH-1:0]                 final_tracklist5,
	output [63:0]                         frame_count
);

// =================================================================================================
    //Registers, wires and Arrays
// =================================================================================================

reg         [3:0]       state;
reg         [3:0]       exit_state;
                        
reg         [4:0]       old_tracklist_match_flag;
                        
reg         [2:0]       old_tracklist_id_0;
reg         [63:0]      old_tracklist_frame_count_0;
reg         [4:0]       old_tracklist_frame_classname_0;
reg         [9:0]       old_tracklist_match_count_0;
reg signed  [25:0]  	old_tracklist_centroid_0[0:1];
reg signed  [25:0]      old_tracklist_detection_0[0:3];
    
reg         [2:0]       old_tracklist_id_1;
reg         [63:0]      old_tracklist_frame_count_1;
reg         [4:0]       old_tracklist_frame_classname_1;
reg         [9:0]       old_tracklist_match_count_1;
reg signed  [25:0]      old_tracklist_centroid_1[0:1];
reg signed  [25:0]      old_tracklist_detection_1[0:3];
    
reg         [2:0]       old_tracklist_id_2;
reg         [63:0]      old_tracklist_frame_count_2;
reg         [4:0]       old_tracklist_frame_classname_2;
reg         [9:0]       old_tracklist_match_count_2;
reg signed  [25:0]      old_tracklist_centroid_2[0:1];
reg signed  [25:0]      old_tracklist_detection_2[0:3];
    
reg         [2:0]       old_tracklist_id_3;
reg         [63:0]      old_tracklist_frame_count_3;
reg         [4:0]       old_tracklist_frame_classname_3;
reg         [9:0]       old_tracklist_match_count_3;
reg signed  [25:0]      old_tracklist_centroid_3[0:1];
reg signed  [25:0]      old_tracklist_detection_3[0:3];
    
reg         [2:0]       old_tracklist_id_4;
reg         [63:0]      old_tracklist_frame_count_4;
reg         [4:0]       old_tracklist_frame_classname_4;
reg         [9:0]       old_tracklist_match_count_4;
reg signed  [25:0]      old_tracklist_centroid_4[0:1];
reg signed  [25:0]      old_tracklist_detection_4[0:3];

reg         [4:0]       new_tracklist_match_flag;                   
reg         [2:0]       new_tracklist_id_0;
reg         [63:0]      new_tracklist_frame_count_0;
reg         [4:0]       new_tracklist_frame_classname_0;
reg         [9:0]       new_tracklist_match_count_0;
reg signed  [25:0]      new_tracklist_centroid_0[0:1];
reg signed  [25:0]      new_tracklist_detection_0[0:3];
    
reg         [2:0]       new_tracklist_id_1;
reg         [63:0]      new_tracklist_frame_count_1;
reg         [4:0]       new_tracklist_frame_classname_1;
reg         [9:0]       new_tracklist_match_count_1;
reg signed  [25:0]      new_tracklist_centroid_1[0:1];
reg signed  [25:0]      new_tracklist_detection_1[0:3];
    
reg         [2:0]       new_tracklist_id_2;
reg         [63:0]      new_tracklist_frame_count_2;
reg         [4:0]       new_tracklist_frame_classname_2;
reg         [9:0]       new_tracklist_match_count_2;
reg signed  [25:0]      new_tracklist_centroid_2[0:1];
reg signed  [25:0]      new_tracklist_detection_2[0:3];
    
reg         [2:0]   new_tracklist_id_3;
reg         [63:0]  new_tracklist_frame_count_3;
reg         [4:0]   new_tracklist_frame_classname_3;
reg         [9:0]   new_tracklist_match_count_3;
reg signed  [25:0]  new_tracklist_centroid_3[0:1];
reg signed  [25:0]  new_tracklist_detection_3[0:3];
    
reg         [2:0]   new_tracklist_id_4;
reg         [63:0]  new_tracklist_frame_count_4;
reg         [4:0]   new_tracklist_frame_classname_4;
reg         [9:0]   new_tracklist_match_count_4;
reg signed  [25:0]  new_tracklist_centroid_4[0:1];
reg signed  [25:0]  new_tracklist_detection_4[0:3];

reg         [4:0]   new_tracklist_updated;      
reg         [2:0]   id ;                            
reg         [2:0]   bbox_bmap_cnt;              
reg         [2:0]   new_tracklist_updated_cnt;  
reg         [9:0]   circle_id;                     
reg         [9:0]   octagon_id ;                        
reg         [9:0]   square_id;                  
reg         [9:0]   triangle_id ;                       
reg         [9:0]   plus_id ;                       
reg         [3:0]   i;                          
reg         [3:0]   j;                          
reg                 min_dist_en;                    
reg         [4:0]   xy_diff_val;                
reg signed  [15:0]  x_diff_0;                   
reg signed  [15:0]  y_diff_0;                   
reg signed  [15:0]  x_diff_1;                   
reg signed  [15:0]  y_diff_1;                   
reg signed  [15:0]  x_diff_2;                   
reg signed  [15:0]  y_diff_2;                   
reg signed  [15:0]  x_diff_3;                   
reg signed  [15:0]  y_diff_3;                   
reg signed  [15:0]  x_diff_4;                   
reg signed  [15:0]  y_diff_4;                   
reg                 strt_median;                
reg         [19:0]  div_val;                        
reg         [63:0]  frame_count;
reg                 zero_frame;
reg         [4:0] 	final_bbox_vld_reg;
reg         [24:0] 	final_bbox_cls_reg;
reg         [49:0] 	final_count_list_reg;

wire        [4:0]	r_cls_bmap [4:0];
wire        [24:0]  cls_bmap_o ;
reg signed [26:0]   track_item_centroid_0  [0:1];
reg signed [26:0]   track_item_centroid_1  [0:1];
reg signed [26:0]   track_item_centroid_2  [0:1];
reg signed [26:0]   track_item_centroid_3  [0:1];
reg signed [26:0]   track_item_centroid_4  [0:1];
reg signed [26:0]   track_item_detection_0 [0:3];
reg signed [26:0]   track_item_detection_1 [0:3];
reg signed [26:0]   track_item_detection_2 [0:3];
reg signed [26:0]   track_item_detection_3 [0:3];
reg signed [26:0]   track_item_detection_4 [0:3];
wire signed [31:0]  sorted_0;
wire signed [31:0]  sorted_1;
wire signed [31:0]  sorted_2;
wire signed [31:0]  sorted_3;
wire signed [31:0]  sorted_4;
reg signed [31:0]   tracker_sorted_0;
reg signed [31:0]   tracker_sorted_1;
reg signed [31:0]   tracker_sorted_2;
reg signed [31:0]   tracker_sorted_3;
reg signed [31:0]   tracker_sorted_4;
reg 	   [49:0]   count_list_reg;
wire signed [19:0]  avg_delx;
wire signed [19:0]  avg_dely;
reg          [4:0]  min_dist_val;
reg          [4:0]  min_dist_val_1d;
reg                 sqr_op_distance_vld_0; 
reg                 sqr_op_distance_vld_1; 
reg                 sqr_op_distance_vld_2; 
reg                 sqr_op_distance_vld_3; 
reg                 sqr_op_distance_vld_4; 

wire 		[4:0] 	bbox_bmap_o;
reg 		[2:0]   median_valid;

reg signed [26:0]   distance_0 [0:1];
reg signed [26:0]   distance_1 [0:1];
reg signed [26:0]   distance_2 [0:1];
reg signed [26:0]   distance_3 [0:1];
reg signed [26:0]   distance_4 [0:1];
reg 		[5:0]   tracklist_match_flag;
reg 				strt_div;
reg signed [19:0]   sum_delx;
reg signed [19:0]   sum_dely;
reg signed [31:0]   final_tracklist_0_reg;
reg signed [31:0]   final_tracklist_1_reg;
reg signed [31:0]   final_tracklist_2_reg;
reg signed [31:0]   final_tracklist_3_reg;
reg signed [31:0]   final_tracklist_4_reg;
wire [4:0] 			min_dist_vld;
wire signed [16:0]  min_dist;
wire                median_donex;
wire                median_doney;
wire signed [15:0]  op_medianx;
wire signed [15:0]  op_mediany;
wire                sort_done;
wire                avg_delx_valid;
wire                avg_dely_valid;
wire [9:0]			min_dist_index;

wire	[17:0]	    sqrt_distance_0;
wire	[17:0]	    sqrt_distance_1;
wire	[17:0]	    sqrt_distance_2;
wire	[17:0]	    sqrt_distance_3;
wire	[17:0]	    sqrt_distance_4;

reg	[17:0]	        sqrt_dist_0;
reg	[17:0]	        sqrt_dist_1;
reg	[17:0]	        sqrt_dist_2;
reg	[17:0]	        sqrt_dist_3;
reg	[17:0]	        sqrt_dist_4;

wire 	[34:0]	    sqr_op_distance_0;
wire 	[34:0]	    sqr_op_distance_1;
wire 	[34:0]	    sqr_op_distance_2;
wire 	[34:0]	    sqr_op_distance_3;
wire 	[34:0]	    sqr_op_distance_4;

reg out_update;

reg [4:0] 			new_tracker_updated;
reg 				min_dist_set;
reg [2:0] 			final_zero_cnt;
reg signed [19:0] 	tempx[0:4];
reg signed [19:0] 	tempy[0:4];

reg [4:0] 			track_vld;
reg [4:0] 			track_count;
reg [4:0] 			valid_min;
reg [4:0] 			track_count_prev;
wire                sqrt_distance_vld_4;
wire                sqrt_distance_vld_3;
wire                sqrt_distance_vld_2;
wire                sqrt_distance_vld_1;
wire                sqrt_distance_vld_0;
reg [4:0] 			tracker_limit;
wire signed [26:0]  current_centroid_0  [0:1];
wire signed [26:0]  current_centroid_1  [0:1];
wire signed [26:0]  current_centroid_2  [0:1];
reg [4:0]			r_cls_bmap_new [0:4];

reg i_vs_d1;
//reg [4:0] bbox_bmap_o_new;
// =================================================================================================
	// Local parameter declarations
// =================================================================================================
localparam FP_WIDTH1          = 5'd17;
localparam ADDR_DEPTH         = 5'd25;
localparam ADDR_WIDTH         = 3'd5;
localparam DATA_WIDTH         = 5'd16;

localparam ST_IDLE            = 8'h0;
localparam ST_FIRST_FRAME     = 8'h1;
localparam ST_SHIFT_TRACKLIST = 5'd2;
localparam ST_NEW_TRACKLIST   = 5'd3;
localparam ST_MATCH_TRACKLIST = 5'd4;
localparam ST_TRACKER         = 5'd5;
localparam ST_MATCH_VERIFY    = 5'd6;
localparam ST_MIN_DIST        = 5'd7;
localparam ST_MAX_DIST        = 5'd8;
localparam ST_UPDATE_DELTAS   = 5'd9;
localparam ST_MEDIAN          = 5'd10;
localparam ST_AVERAGE         = 5'd11;
localparam ST_DIV_DONE        = 5'd12;
localparam ST_FINAL           = 5'd13;

localparam MIN_THRESHOLD = 17'd12800;
//localparam MIN_THRESHOLD = 17'd6400;  

assign o_box_vld			= final_bbox_vld_reg;
assign o_cls_bmap			= final_bbox_cls_reg;
assign count_list			= final_count_list_reg;
assign final_tracklist1		= final_tracklist_0_reg;
assign final_tracklist2		= final_tracklist_1_reg;
assign final_tracklist3		= final_tracklist_2_reg;
assign final_tracklist4		= final_tracklist_3_reg;
assign final_tracklist5		= final_tracklist_4_reg;

assign r_cls_bmap[0] = cls_bmap_o[4:0];
assign r_cls_bmap[1] = cls_bmap_o[9:5];
assign r_cls_bmap[2] = cls_bmap_o[14:10];
assign r_cls_bmap[3] = cls_bmap_o[19:15];
assign r_cls_bmap[4] = cls_bmap_o[24:20];

assign current_centroid_0[0] = $signed({2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0});
assign current_centroid_0[1] = $signed({2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0});

assign current_centroid_1[0] = $signed({2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0});
assign current_centroid_1[1] = $signed({2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0});

assign current_centroid_2[0] = $signed({2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0});
assign current_centroid_2[1] = $signed({2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0});

//frame counter and flag to mark first frame
always@(posedge clk or negedge resetn) begin
	if(!resetn) begin
		frame_count <= 64'd0;//{ID_WIDTH{1'b0}};
		zero_frame  <= 1'b1;
        i_vs_d1  <= 1'b0;		
	end
	else begin
		i_vs_d1 <= i_vs;
		if(i_vs & !i_vs_d1) begin
		    zero_frame <= 1'b0;
			if (zero_frame) frame_count <= frame_count; 
			else frame_count <= frame_count + 1'b1;
		end
	end
end

// ================================================================================================
always @(posedge clk, negedge resetn) begin
    
    if (!resetn) begin
        state                               <= ST_IDLE;
        exit_state                          <= ST_IDLE;

        old_tracklist_match_flag            <= 5'b0;
        old_tracklist_id_0                  <= 3'b0;
        old_tracklist_frame_count_0         <= 64'd0;
        old_tracklist_frame_classname_0     <= 5'b0;
        old_tracklist_match_count_0         <= 10'd0;
        old_tracklist_centroid_0[0]         <= 26'h0;
        old_tracklist_centroid_0[1]         <= 26'h0;
        old_tracklist_detection_0[0]        <= 26'h0;
        old_tracklist_detection_0[1]        <= 26'h0;
        old_tracklist_detection_0[2]        <= 26'h0;
        old_tracklist_detection_0[3]        <= 26'h0;
        

        old_tracklist_id_1                  <= 3'b0;
        old_tracklist_frame_count_1         <= 64'd0;
        old_tracklist_frame_classname_1     <= 5'b0;
        old_tracklist_match_count_1         <= 10'd0;
        old_tracklist_centroid_1[0]         <= 26'h0;
        old_tracklist_centroid_1[1]         <= 26'h0;
        old_tracklist_detection_1[0]        <= 26'h0;
        old_tracklist_detection_1[1]        <= 26'h0;
        old_tracklist_detection_1[2]        <= 26'h0;
        old_tracklist_detection_1[3]        <= 26'h0;
        

        old_tracklist_id_2                  <= 3'b0;
        old_tracklist_frame_count_2         <= 64'd0;
        old_tracklist_frame_classname_2     <= 5'b0;
        old_tracklist_match_count_2         <= 10'd0;
        old_tracklist_centroid_2[0]         <= 26'h0;
        old_tracklist_centroid_2[1]         <= 26'h0;
        old_tracklist_detection_2[0]        <= 26'h0;
        old_tracklist_detection_2[1]        <= 26'h0;
        old_tracklist_detection_2[2]        <= 26'h0;
        old_tracklist_detection_2[3]        <= 26'h0;
        

        old_tracklist_id_3                  <= 3'b0;
        old_tracklist_frame_count_3         <= 64'd0;
        old_tracklist_frame_classname_3     <= 5'b0;
        old_tracklist_match_count_3         <= 10'd0;
        old_tracklist_centroid_3[0]         <= 26'h0;
        old_tracklist_centroid_3[1]         <= 26'h0;
        old_tracklist_detection_3[0]        <= 26'h0;
        old_tracklist_detection_3[1]        <= 26'h0;
        old_tracklist_detection_3[2]        <= 26'h0;
        old_tracklist_detection_3[3]        <= 26'h0;
		

        old_tracklist_id_4                  <= 3'b0;
        old_tracklist_frame_count_4         <= 64'd0;
        old_tracklist_frame_classname_4     <= 5'b0;
        old_tracklist_match_count_4         <= 10'd0;
        old_tracklist_centroid_4[0]         <= 26'h0;
        old_tracklist_centroid_4[1]         <= 26'h0;
        old_tracklist_detection_4[0]        <= 26'h0;
        old_tracklist_detection_4[1]        <= 26'h0;
        old_tracklist_detection_4[2]        <= 26'h0;
        old_tracklist_detection_4[3]        <= 26'h0;

        new_tracklist_match_flag            <= 5'b0;
        new_tracklist_id_0                  <= 3'b0;
        new_tracklist_frame_count_0         <= 64'd0;
        new_tracklist_frame_classname_0     <= 5'b0;
        new_tracklist_match_count_0         <= 10'd0;
        new_tracklist_centroid_0[0]         <= 26'h0;
        new_tracklist_centroid_0[1]         <= 26'h0;
        new_tracklist_detection_0[0]        <= 26'h0;
        new_tracklist_detection_0[1]        <= 26'h0;
        new_tracklist_detection_0[2]        <= 26'h0;
        new_tracklist_detection_0[3]        <= 26'h0;
        

        new_tracklist_id_1                  <= 3'b0;
        new_tracklist_frame_count_1         <= 64'd0;
        new_tracklist_frame_classname_1     <= 5'd0;
        new_tracklist_match_count_1         <= 10'd0;
        new_tracklist_centroid_1[0]         <= 26'h0;
        new_tracklist_centroid_1[1]         <= 26'h0;
        new_tracklist_detection_1[0]        <= 26'h0;
        new_tracklist_detection_1[1]        <= 26'h0;
        new_tracklist_detection_1[2]        <= 26'h0;
        new_tracklist_detection_1[3]        <= 26'h0;
        

        new_tracklist_id_2                  <= 3'b0;
        new_tracklist_frame_count_2         <= 64'd0;
        new_tracklist_frame_classname_2     <= 5'b0;
        new_tracklist_match_count_2         <= 10'd0;
        new_tracklist_centroid_2[0]         <= 26'h0;
        new_tracklist_centroid_2[1]         <= 26'h0;
        new_tracklist_detection_2[0]        <= 26'h0;
        new_tracklist_detection_2[1]        <= 26'h0;
        new_tracklist_detection_2[2]        <= 26'h0;
        new_tracklist_detection_2[3]        <= 26'h0;
        

        new_tracklist_id_3                  <= 3'b0;
        new_tracklist_frame_count_3         <= 64'd0;
        new_tracklist_frame_classname_3     <= 5'b0;
        new_tracklist_match_count_3         <= 10'd0;
        new_tracklist_centroid_3[0]         <= 26'h0;
        new_tracklist_centroid_3[1]         <= 26'h0;
        new_tracklist_detection_3[0]        <= 26'h0;
        new_tracklist_detection_3[1]        <= 26'h0;
        new_tracklist_detection_3[2]        <= 26'h0;
        new_tracklist_detection_3[3]        <= 26'h0;
        

        new_tracklist_id_4                  <= 3'b0;
        new_tracklist_frame_count_4         <= 64'd0;
        new_tracklist_frame_classname_4     <= 5'b0;
        new_tracklist_match_count_4         <= 10'd0;
        new_tracklist_centroid_4[0]         <= 26'h0;
        new_tracklist_centroid_4[1]         <= 26'h0;
        new_tracklist_detection_4[0]        <= 26'h0;
        new_tracklist_detection_4[1]        <= 26'h0;
        new_tracklist_detection_4[2]        <= 26'h0;
        new_tracklist_detection_4[3]        <= 26'h0;

        track_item_centroid_0[0]            <= 26'h0;
        track_item_centroid_0[1]            <= 26'h0;
        track_item_centroid_1[0]            <= 26'h0;
        track_item_centroid_1[1]            <= 26'h0;
        track_item_centroid_2[0]            <= 26'h0;
        track_item_centroid_2[1]            <= 26'h0;
        track_item_centroid_3[0]            <= 26'h0;
        track_item_centroid_3[1]            <= 26'h0;
        track_item_centroid_4[0]            <= 26'h0;
        track_item_centroid_4[1]            <= 26'h0;
                    
        track_item_detection_0[0]           <= 26'h0;
        track_item_detection_0[1]           <= 26'h0;
        track_item_detection_0[2]           <= 26'h0;
        track_item_detection_0[3]           <= 26'h0;
        track_item_detection_1[0]           <= 26'h0;
        track_item_detection_1[1]           <= 26'h0;
        track_item_detection_1[2]           <= 26'h0;
        track_item_detection_1[3]           <= 26'h0;
        track_item_detection_2[0]           <= 26'h0;
        track_item_detection_2[1]           <= 26'h0;
        track_item_detection_2[2]           <= 26'h0;
        track_item_detection_2[3]           <= 26'h0;
        track_item_detection_3[0]           <= 26'h0;
        track_item_detection_3[1]           <= 26'h0;
        track_item_detection_3[2]           <= 26'h0;
        track_item_detection_3[3]           <= 26'h0;
        track_item_detection_3[0]           <= 26'h0;
        track_item_detection_3[1]           <= 26'h0;
        track_item_detection_3[2]           <= 26'h0;
        track_item_detection_3[3]           <= 26'h0;


        new_tracklist_updated               <= 5'b0;
        id                                  <= 3'b0;
        bbox_bmap_cnt                       <= 3'b0;
        new_tracklist_updated_cnt           <= 3'b0;


        circle_id                           <= 12'h0;
        octagon_id                          <= 12'h0;
        square_id                           <= 12'h0;
        triangle_id                         <= 12'h0;
        plus_id                             <= 12'h0;

        i                                   <= 4'h0;
        j                                   <= 4'h0;

        min_dist_en                         <= 1'b0;
        count_list_reg                      <= 50'h0;

        xy_diff_val                         <= 5'b0;
        x_diff_0                            <= 16'h0;
        y_diff_0                            <= 16'h0;
        x_diff_1                            <= 16'h0;
        y_diff_1                            <= 16'h0;
        x_diff_2                            <= 16'h0;
        y_diff_2                            <= 16'h0;
        x_diff_3                            <= 16'h0;
        y_diff_3                            <= 16'h0;
        x_diff_4                            <= 16'h0;
        y_diff_4                            <= 16'h0;
        
        strt_median                         <= 1'b0;
        div_val                             <= 20'h0;
        
        median_valid                        <= 3'b0;
		min_dist_val 			   			<= 5'b0;
		out_update			    			<= 1'b0;
	
	    final_bbox_vld_reg					<= 5'h0;
	    final_bbox_cls_reg					<= 25'h0;
	    final_count_list_reg				<= 50'h0;
        
	    final_tracklist_0_reg              <= 32'h0; 
	    final_tracklist_1_reg              <= 32'h0; 
	    final_tracklist_2_reg              <= 32'h0; 
	    final_tracklist_3_reg              <= 32'h0; 
	    final_tracklist_4_reg              <= 32'h0; 
        
	    distance_0[0]                      <= 26'h0;
	    distance_0[1]                      <= 26'h0;
	    distance_1[0]                      <= 26'h0;
	    distance_1[1]                      <= 26'h0;
	    distance_2[0]                      <= 26'h0;
	    distance_2[1]                      <= 26'h0;
	    distance_3[0]                      <= 26'h0;
	    distance_3[1]                      <= 26'h0;
	    distance_4[0]                      <= 26'h0;
	    distance_4[1]                      <= 26'h0; 
        
	    new_tracklist_match_count_1 	   <= 10'd0;
	    sum_delx                           <= 20'd0;
	    sum_dely                           <= 20'd0; 
        
        min_dist_set 					   <= 1'b0;
        final_zero_cnt                     <= 3'h0;  
        track_count_prev                   <= 5'd0;
        valid_min                          <= 5'd0;
        
        sqrt_dist_0                        <= 18'd0;
        sqrt_dist_1                        <= 18'd0;
        sqrt_dist_2                        <= 18'd0;
        sqrt_dist_3                        <= 18'd0;
        sqrt_dist_4                        <= 18'd0;
	    
	    r_cls_bmap_new[0]                  <= 5'h0;
        r_cls_bmap_new[1]                  <= 5'h0;
        r_cls_bmap_new[2]                  <= 5'h0;
        r_cls_bmap_new[3]                  <= 5'h0;
        r_cls_bmap_new[4]                  <= 5'h0;

    end
    else begin
        
        case (state)
            
            ST_IDLE : begin
                if (sort_done ) begin //& bbox_bmap_o != 5'b0
                    state <= ST_SHIFT_TRACKLIST;
                end
		out_update <= 1'b0;
        valid_min <= 5'b0;
            end
            
            
            ST_SHIFT_TRACKLIST : begin    
                state <= ST_NEW_TRACKLIST;
                
                old_tracklist_match_flag[0]         <= new_tracklist_match_flag[0];
                old_tracklist_id_0                  <= new_tracklist_id_0;
                old_tracklist_frame_count_0         <= new_tracklist_frame_count_0;    
                old_tracklist_frame_classname_0     <= new_tracklist_frame_classname_0;
                old_tracklist_match_count_0         <= new_tracklist_match_count_0;
                old_tracklist_centroid_0[0]         <= new_tracklist_centroid_0[0]; 
                old_tracklist_centroid_0[1]         <= new_tracklist_centroid_0[1]; 
                old_tracklist_detection_0[0]        <= new_tracklist_detection_0[0];
                old_tracklist_detection_0[1]        <= new_tracklist_detection_0[1];
                old_tracklist_detection_0[2]        <= new_tracklist_detection_0[2];
                old_tracklist_detection_0[3]        <= new_tracklist_detection_0[3];
                
                old_tracklist_match_flag[1]         <= new_tracklist_match_flag[1];
                old_tracklist_id_1                  <= new_tracklist_id_1;
                old_tracklist_frame_count_1         <= new_tracklist_frame_count_1;    
                old_tracklist_frame_classname_1     <= new_tracklist_frame_classname_1;
                old_tracklist_match_count_1         <= new_tracklist_match_count_1;
                old_tracklist_centroid_1[0]         <= new_tracklist_centroid_1[0]; 
                old_tracklist_centroid_1[1]         <= new_tracklist_centroid_1[1]; 
                old_tracklist_detection_1[0]        <= new_tracklist_detection_1[0];
                old_tracklist_detection_1[1]        <= new_tracklist_detection_1[1];
                old_tracklist_detection_1[2]        <= new_tracklist_detection_1[2];
                old_tracklist_detection_1[3]        <= new_tracklist_detection_1[3];
                
                old_tracklist_match_flag[2]         <= new_tracklist_match_flag[2];
                old_tracklist_id_2                  <= new_tracklist_id_2;
                old_tracklist_frame_count_2         <= new_tracklist_frame_count_2;       
                old_tracklist_frame_classname_2     <= new_tracklist_frame_classname_2;
                old_tracklist_match_count_2         <= new_tracklist_match_count_2;
                old_tracklist_centroid_2[0]         <= new_tracklist_centroid_2[0]; 
                old_tracklist_centroid_2[1]         <= new_tracklist_centroid_2[1]; 
                old_tracklist_detection_2[0]        <= new_tracklist_detection_2[0];
                old_tracklist_detection_2[1]        <= new_tracklist_detection_2[1];
                old_tracklist_detection_2[2]        <= new_tracklist_detection_2[2];
                old_tracklist_detection_2[3]        <= new_tracklist_detection_2[3];
                
                old_tracklist_match_flag[3]         <= new_tracklist_match_flag[3];
                old_tracklist_id_3                  <= new_tracklist_id_3;
                old_tracklist_frame_count_3         <= new_tracklist_frame_count_3;       
                old_tracklist_frame_classname_3     <= new_tracklist_frame_classname_3;
                old_tracklist_match_count_3         <= new_tracklist_match_count_3;
                old_tracklist_centroid_3[0]         <= new_tracklist_centroid_3[0]; 
                old_tracklist_centroid_3[1]         <= new_tracklist_centroid_3[1]; 
                old_tracklist_detection_3[0]        <= new_tracklist_detection_3[0];
                old_tracklist_detection_3[1]        <= new_tracklist_detection_3[1];
                old_tracklist_detection_3[2]        <= new_tracklist_detection_3[2];
                old_tracklist_detection_3[3]        <= new_tracklist_detection_3[3];    
                
                old_tracklist_match_flag[4]         <= new_tracklist_match_flag[4];
                old_tracklist_id_4                  <= new_tracklist_id_4;
                old_tracklist_frame_count_4         <= new_tracklist_frame_count_4;    
                old_tracklist_frame_classname_4     <= new_tracklist_frame_classname_4;
                old_tracklist_match_count_4         <= new_tracklist_match_count_4;
                old_tracklist_centroid_4[0]         <= new_tracklist_centroid_4[0]; 
                old_tracklist_centroid_4[1]         <= new_tracklist_centroid_4[1]; 
                old_tracklist_detection_4[0]        <= new_tracklist_detection_4[0];
                old_tracklist_detection_4[1]        <= new_tracklist_detection_4[1];
                old_tracklist_detection_4[2]        <= new_tracklist_detection_4[2];
                old_tracklist_detection_4[3]        <= new_tracklist_detection_4[3];
                track_count_prev <= track_count; 

                track_item_centroid_0[0]  <= new_tracklist_centroid_0[0] + tempx[0];
                track_item_centroid_0[1]  <= new_tracklist_centroid_0[1] + tempy[0];
                track_item_centroid_1[0]  <= new_tracklist_centroid_1[0] + tempx[1];
                track_item_centroid_1[1]  <= new_tracklist_centroid_1[1] + tempy[1];
                track_item_centroid_2[0]  <= new_tracklist_centroid_2[0] + tempx[2];
                track_item_centroid_2[1]  <= new_tracklist_centroid_2[1] + tempy[2];
                track_item_centroid_3[0]  <= new_tracklist_centroid_3[0] + tempx[3];
                track_item_centroid_3[1]  <= new_tracklist_centroid_3[1] + tempy[3];
                track_item_centroid_4[0]  <= new_tracklist_centroid_4[0] + tempx[4];
                track_item_centroid_4[1]  <= new_tracklist_centroid_4[1] + tempy[4];
                
                track_item_detection_0[0] <= new_tracklist_detection_0[0] + tempx[0];
                track_item_detection_0[1] <= new_tracklist_detection_0[1] + tempy[0];
                track_item_detection_0[2] <= new_tracklist_detection_0[2] + tempx[0];
                track_item_detection_0[3] <= new_tracklist_detection_0[3] + tempy[0];
                track_item_detection_1[0] <= new_tracklist_detection_1[0] + tempx[1];
                track_item_detection_1[1] <= new_tracklist_detection_1[1] + tempy[1];
                track_item_detection_1[2] <= new_tracklist_detection_1[2] + tempx[1];
                track_item_detection_1[3] <= new_tracklist_detection_1[3] + tempy[1];
                track_item_detection_2[0] <= new_tracklist_detection_2[0] + tempx[2]; 
                track_item_detection_2[1] <= new_tracklist_detection_2[1] + tempy[2];
                track_item_detection_2[2] <= new_tracklist_detection_2[2] + tempx[2]; 
                track_item_detection_2[3] <= new_tracklist_detection_2[3] + tempy[2];
                track_item_detection_3[0] <= new_tracklist_detection_3[0] + tempx[3]; 
                track_item_detection_3[1] <= new_tracklist_detection_3[1] + tempy[3];
                track_item_detection_3[2] <= new_tracklist_detection_3[2] + tempx[3];
                track_item_detection_3[3] <= new_tracklist_detection_3[3] + tempy[3];
                track_item_detection_4[0] <= new_tracklist_detection_4[0] + tempx[4]; 
                track_item_detection_4[1] <= new_tracklist_detection_4[1] + tempy[4];
                track_item_detection_4[2] <= new_tracklist_detection_4[2] + tempx[4];
                track_item_detection_4[3] <= new_tracklist_detection_4[3] + tempy[4];       
            end
            
            ST_NEW_TRACKLIST : begin
                
                state <= ST_MATCH_TRACKLIST;
                
                if ((track_item_centroid_0[0] > 26'b0 && track_item_centroid_0[0] < IMG_WIDTH*256) && (track_item_centroid_0[1] > 26'b0 && track_item_centroid_0[1] < IMG_HEIGHT*256)) begin
                    new_tracklist_updated[0]    <= 1'b1; 
                    //new_tracklist_frame_count_0 <= frame_count;
                    new_tracklist_centroid_0[0] <= track_item_centroid_0[0];
                    new_tracklist_centroid_0[1] <= track_item_centroid_0[1];
                    new_tracklist_detection_0[0] <= track_item_detection_0[0]; 
                    new_tracklist_detection_0[1] <= track_item_detection_0[1]; 
                    new_tracklist_detection_0[2] <= track_item_detection_0[2]; 
                    new_tracklist_detection_0[3] <= track_item_detection_0[3]; 
                end
		        else begin 
					r_cls_bmap_new[0]			 <= r_cls_bmap_new[1]; 	
					//bbox_bmap_o_new[0]			 <= bbox_bmap_o_new[1];
                    old_tracklist_centroid_0[0]  <= old_tracklist_centroid_1[0] ;
                    old_tracklist_centroid_0[1]  <= old_tracklist_centroid_1[1] ;
                    old_tracklist_detection_0[0] <= old_tracklist_detection_1[0];
                    old_tracklist_detection_0[1] <= old_tracklist_detection_1[1];
                    old_tracklist_detection_0[2] <= old_tracklist_detection_1[2];
                    old_tracklist_detection_0[3] <= old_tracklist_detection_1[3];
                    
                    new_tracklist_updated[0]     <= 1'b0; 
                    new_tracklist_centroid_0[0]  <= track_item_centroid_1[0];
                    new_tracklist_centroid_0[1]  <= track_item_centroid_1[1];
                    new_tracklist_detection_0[0] <= track_item_detection_1[0]; 
                    new_tracklist_detection_0[1] <= track_item_detection_1[1]; 
                    new_tracklist_detection_0[2] <= track_item_detection_1[2]; 
                    new_tracklist_detection_0[3] <= track_item_detection_1[3]; 
		        end
                
                if ((track_item_centroid_1[0] > 'b0 && track_item_centroid_1[0] < IMG_WIDTH*256) && (track_item_centroid_1[1] > 'b0 && track_item_centroid_1[1] < IMG_HEIGHT*256)) begin
                      new_tracklist_updated[1]    <= 1'b1;
                      //new_tracklist_frame_count_1 <= frame_count;
                      new_tracklist_centroid_1[0] <= track_item_centroid_1[0];
                      new_tracklist_centroid_1[1] <= track_item_centroid_1[1];
                      new_tracklist_detection_1[0] <= track_item_detection_1[0]; 
                      new_tracklist_detection_1[1] <= track_item_detection_1[1]; 
                      new_tracklist_detection_1[2] <= track_item_detection_1[2]; 
                      new_tracklist_detection_1[3] <= track_item_detection_1[3]; 
                end         
	        	else begin
					r_cls_bmap_new[1]			 <= r_cls_bmap_new[2]; 
					//bbox_bmap_o_new[1]			 <= bbox_bmap_o_new[2];
                    old_tracklist_centroid_1[0]  <= old_tracklist_centroid_2[0] ;
                    old_tracklist_centroid_1[1]  <= old_tracklist_centroid_2[1] ;
                    old_tracklist_detection_1[0] <= old_tracklist_detection_2[0];
                    old_tracklist_detection_1[1] <= old_tracklist_detection_2[1];
                    old_tracklist_detection_1[2] <= old_tracklist_detection_2[2];
                    old_tracklist_detection_1[3] <= old_tracklist_detection_2[3];
 
                    new_tracklist_updated[1]    <= 1'b0; 
                    new_tracklist_centroid_1[0] <= track_item_centroid_2[0];
                    new_tracklist_centroid_1[1] <= track_item_centroid_2[1];
                    new_tracklist_detection_1[0] <= track_item_detection_2[0]; 
                    new_tracklist_detection_1[1] <= track_item_detection_2[1]; 
                    new_tracklist_detection_1[2] <= track_item_detection_2[2]; 
                    new_tracklist_detection_1[3] <= track_item_detection_2[3]; 
	        	end
                
                if ((track_item_centroid_2[0] > 'b0 && track_item_centroid_2[0] < IMG_WIDTH*256) && (track_item_centroid_2[1] > 'b0 && track_item_centroid_2[1] < IMG_HEIGHT*256)) begin
                      new_tracklist_updated[2]    <= 1'b1;
                      //new_tracklist_frame_count_2 <= frame_count;
                      new_tracklist_centroid_2[0] <= track_item_centroid_2[0];
                      new_tracklist_centroid_2[1] <= track_item_centroid_2[1];
                      new_tracklist_detection_2[0] <= track_item_detection_2[0]; 
                      new_tracklist_detection_2[1] <= track_item_detection_2[1]; 
                      new_tracklist_detection_2[2] <= track_item_detection_2[2]; 
                      new_tracklist_detection_2[3] <= track_item_detection_2[3]; 
                end 
	        	else begin
					r_cls_bmap_new[2]			 <= r_cls_bmap_new[3]; 
					//bbox_bmap_o_new[2]			 <= bbox_bmap_o_new[3];
                    old_tracklist_centroid_2[0]  <= old_tracklist_centroid_3[0] ;
                    old_tracklist_centroid_2[1]  <= old_tracklist_centroid_3[1] ;
                    old_tracklist_detection_2[0] <= old_tracklist_detection_3[0];
                    old_tracklist_detection_2[1] <= old_tracklist_detection_3[1];
                    old_tracklist_detection_2[2] <= old_tracklist_detection_3[2];
                    old_tracklist_detection_2[3] <= old_tracklist_detection_3[3];
                    
                    new_tracklist_updated[2]    <= 1'b0; 
                    new_tracklist_centroid_2[0] <= track_item_centroid_3[0];
                    new_tracklist_centroid_2[1] <= track_item_centroid_3[1];
                    new_tracklist_detection_2[0] <= track_item_detection_3[0]; 
                    new_tracklist_detection_2[1] <= track_item_detection_3[1]; 
                    new_tracklist_detection_2[2] <= track_item_detection_3[2]; 
                    new_tracklist_detection_2[3] <= track_item_detection_3[3]; 
	        	end
                
                if ((track_item_centroid_3[0] > 'b0 && track_item_centroid_3[0] < IMG_WIDTH*256) && (track_item_centroid_3[1] > 'b0 && track_item_centroid_3[1] < IMG_HEIGHT*256)) begin
                      new_tracklist_updated[3]    <= 1'b1;
                      //new_tracklist_frame_count_3 <= frame_count;
                      new_tracklist_centroid_3[0] <= track_item_centroid_3[0];
                      new_tracklist_centroid_3[1] <= track_item_centroid_3[1];
                      new_tracklist_detection_3[0] <= track_item_detection_3[0]; 
                      new_tracklist_detection_3[1] <= track_item_detection_3[1]; 
                      new_tracklist_detection_3[2] <= track_item_detection_3[2]; 
                      new_tracklist_detection_3[3] <= track_item_detection_3[3]; 
                    end             
		        else begin
					r_cls_bmap_new[3]		     <= r_cls_bmap_new[4]; 
					//bbox_bmap_o_new[3]			 <= bbox_bmap_o_new[4];
                    old_tracklist_centroid_3[0]  <= old_tracklist_centroid_4[0] ;
                    old_tracklist_centroid_3[1]  <= old_tracklist_centroid_4[1] ;
                    old_tracklist_detection_3[0] <= old_tracklist_detection_4[0];
                    old_tracklist_detection_3[1] <= old_tracklist_detection_4[1];
                    old_tracklist_detection_3[2] <= old_tracklist_detection_4[2];
                    old_tracklist_detection_3[3] <= old_tracklist_detection_4[3];

                    new_tracklist_updated[3]    <= 1'b0; 
                    new_tracklist_centroid_3[0] <= track_item_centroid_4[0];
                    new_tracklist_centroid_3[1] <= track_item_centroid_4[1];
                    new_tracklist_detection_3[0] <= track_item_detection_4[0]; 
                    new_tracklist_detection_3[1] <= track_item_detection_4[1]; 
                    new_tracklist_detection_3[2] <= track_item_detection_4[2]; 
                    new_tracklist_detection_3[3] <= track_item_detection_4[3]; 
		        end
                
                if ((track_item_centroid_4[0] > 'b0 && track_item_centroid_4[0] < IMG_WIDTH*256) && (track_item_centroid_4[1] > 'b0 && track_item_centroid_4[1] < IMG_HEIGHT*256)) begin
                      new_tracklist_updated[4]    <= 1'b1;
                      //new_tracklist_frame_count_4 <= frame_count;
                      new_tracklist_centroid_4[0] <= track_item_centroid_4[0];
                      new_tracklist_centroid_4[1] <= track_item_centroid_4[1];
                      new_tracklist_detection_4[0] <= track_item_detection_4[0]; 
                      new_tracklist_detection_4[1] <= track_item_detection_4[1]; 
                      new_tracklist_detection_4[2] <= track_item_detection_4[2]; 
                      new_tracklist_detection_4[3] <= track_item_detection_4[3]; 
                    end
		        else begin
                    new_tracklist_updated[4]    <= 1'b0; 
		        end
                
            end
            
            ST_MATCH_TRACKLIST : begin
                new_tracklist_match_flag <= 5'b0;
                id <= 3'b0;
                bbox_bmap_cnt <= bbox_bmap_o[0] + bbox_bmap_o[1] + bbox_bmap_o[2] + bbox_bmap_o[3] + bbox_bmap_o[4];
                
                if (new_tracklist_updated == 5'b0) begin
                    state <= ST_FIRST_FRAME;
                    exit_state <= ST_UPDATE_DELTAS;
                end
                else begin
                    state <= ST_MATCH_VERIFY;
                end
                
            end
            
            ST_FIRST_FRAME : begin
				r_cls_bmap_new[id] <= r_cls_bmap[id];
				//bbox_bmap_o_new    <= bbox_bmap_o;
                circle_id 	<=  circle_id   + (r_cls_bmap[id] == 5'h1  & bbox_bmap_o[id]);              
                octagon_id  <=  octagon_id  + (r_cls_bmap[id] == 5'h2  & bbox_bmap_o[id]);
                square_id  	<=  square_id   + (r_cls_bmap[id] == 5'h4  & bbox_bmap_o[id]);        
                triangle_id <=  triangle_id + (r_cls_bmap[id] == 5'h8  & bbox_bmap_o[id]);              
                plus_id     <=  plus_id     + (r_cls_bmap[id] == 5'h10 & bbox_bmap_o[id]);
                state      	<=  ST_TRACKER; 
            end
            
            ST_TRACKER : begin

                case (id) 
                    3'h0 : begin
                        if (new_tracker_updated[0]) begin
                            new_tracklist_match_flag[0]     <= 1'b0;  
                            new_tracklist_id_0              <= id;
                            new_tracklist_frame_count_0     <= frame_count;
                            new_tracklist_frame_classname_0 <= r_cls_bmap[id];
                            new_tracklist_match_count_0     <= 16'h0;
                            new_tracklist_centroid_0[0]     <= {2'b0,tracker_sorted_0[31:24],7'd0} + {2'b0,tracker_sorted_0[15:8] ,7'd0};
                            new_tracklist_centroid_0[1]     <= {2'b0,tracker_sorted_0[23:16],7'd0} + {2'b0,tracker_sorted_0[7:0]  ,7'd0};
                            new_tracklist_detection_0[0]    <= {1'b0,tracker_sorted_0[31:24],8'd0}; 
                            new_tracklist_detection_0[1]    <= {1'b0,tracker_sorted_0[23:16],8'd0};
                            new_tracklist_detection_0[2]    <= {1'b0,tracker_sorted_0[15:8] ,8'd0};
                            new_tracklist_detection_0[3]    <= {1'b0,tracker_sorted_0[7:0]  ,8'd0};
                        end
                    end
                    
                    3'h1 : begin
                        if (new_tracker_updated[1]) begin
                          new_tracklist_match_flag[1]     <= 1'b0;  
                          new_tracklist_id_1              <= id;
                          new_tracklist_frame_count_1     <= frame_count;
                          new_tracklist_frame_classname_1 <= r_cls_bmap[id];
                          new_tracklist_match_count_1     <= 16'h0;
                          new_tracklist_centroid_1[0]     <= {2'b0,tracker_sorted_1[31:24],7'd0} + {2'b0,tracker_sorted_1[15:8] ,7'd0};
                          new_tracklist_centroid_1[1]     <= {2'b0,tracker_sorted_1[23:16],7'd0} + {2'b0,tracker_sorted_1[7:0]  ,7'd0};
                          new_tracklist_detection_1[0]    <= {1'b0,tracker_sorted_1[31:24],8'd0}; 
                          new_tracklist_detection_1[1]    <= {1'b0,tracker_sorted_1[23:16],8'd0};
                          new_tracklist_detection_1[2]    <= {1'b0,tracker_sorted_1[15:8] ,8'd0};
                          new_tracklist_detection_1[3]    <= {1'b0,tracker_sorted_1[7:0]  ,8'd0};    
                        end             
                    end
                    
                    3'h2 : begin
                        if (new_tracker_updated[2]) begin
                            new_tracklist_match_flag[2]     <= 1'b0;  
                            new_tracklist_id_2              <= id;
                            new_tracklist_frame_count_2     <= frame_count;
                            new_tracklist_frame_classname_2 <= r_cls_bmap[id];
                            new_tracklist_match_count_2     <= 16'h0;
                            new_tracklist_centroid_2[0]     <= {2'b0,tracker_sorted_2[31:24],7'd0} + {2'b0,tracker_sorted_2[15:8] ,7'd0};
                            new_tracklist_centroid_2[1]     <= {2'b0,tracker_sorted_2[23:16],7'd0} + {2'b0,tracker_sorted_2[7:0]  ,7'd0};
                            new_tracklist_detection_2[0]    <= {1'b0,tracker_sorted_2[31:24],8'd0}; 
                            new_tracklist_detection_2[1]    <= {1'b0,tracker_sorted_2[23:16],8'd0};
                            new_tracklist_detection_2[2]    <= {1'b0,tracker_sorted_2[15:8] ,8'd0};
                            new_tracklist_detection_2[3]    <= {1'b0,tracker_sorted_2[7:0]  ,8'd0};       
                        end          
                    end
                    
                    
                    3'h3 : begin
                        if (new_tracker_updated[3]) begin
                            new_tracklist_match_flag[3]     <= 1'b0;  
                            new_tracklist_id_3              <= id;
                            new_tracklist_frame_count_3     <= frame_count;
                            new_tracklist_frame_classname_3 <= r_cls_bmap[id];
                            new_tracklist_match_count_3     <= 16'h0;
                            new_tracklist_centroid_3[0]     <= {2'b0,tracker_sorted_3[31:24],7'd0} + {2'b0,tracker_sorted_3[15:8] ,7'd0};
                            new_tracklist_centroid_3[1]     <= {2'b0,tracker_sorted_3[23:16],7'd0} + {2'b0,tracker_sorted_3[7:0]  ,7'd0};
                            new_tracklist_detection_3[0]    <= {1'b0,tracker_sorted_3[31:24],8'd0}; 
                            new_tracklist_detection_3[1]    <= {1'b0,tracker_sorted_3[23:16],8'd0};
                            new_tracklist_detection_3[2]    <= {1'b0,tracker_sorted_3[15:8] ,8'd0};
                            new_tracklist_detection_3[3]    <= {1'b0,tracker_sorted_3[7:0]  ,8'd0};  
                        end               
                    end
                    
                    3'h4 : begin
                        if (new_tracker_updated[4]) begin
                            new_tracklist_match_flag[4]     <= 1'b0;  
                            new_tracklist_id_4              <= id;
                            new_tracklist_frame_count_4     <= frame_count;
                            new_tracklist_frame_classname_4 <= r_cls_bmap[id];
                            new_tracklist_match_count_4     <= 16'h0;
                            new_tracklist_centroid_4[0]     <= {2'b0,tracker_sorted_4[31:24],7'd0} + {2'b0,tracker_sorted_4[15:8] ,7'd0};
                            new_tracklist_centroid_4[1]     <= {2'b0,tracker_sorted_4[23:16],7'd0} + {2'b0,tracker_sorted_4[7:0]  ,7'd0};
                            new_tracklist_detection_4[0]    <= {1'b0,tracker_sorted_4[31:24],8'd0}; 
                            new_tracklist_detection_4[1]    <= {1'b0,tracker_sorted_4[23:16],8'd0};
                            new_tracklist_detection_4[2]    <= {1'b0,tracker_sorted_4[15:8] ,8'd0};
                            new_tracklist_detection_4[3]    <= {1'b0,tracker_sorted_4[7:0]  ,8'd0};
                        end
                    end
                endcase
                
                 if ((id) < bbox_bmap_cnt-1 && bbox_bmap_o != 5'd0 ) begin// added -1 to fix the logic  
                    id <= id + 1'b1;
                   state <= ST_FIRST_FRAME;
                end
                else begin
                    id    <= 3'b0;
                    //tracker_limit <= 5'b0;
                    state <= exit_state;
                    if(min_dist > MIN_THRESHOLD)  //to decrement the old box count when the min>MIN_THRESHOLD.
                    bbox_bmap_cnt <= bbox_bmap_cnt - 1'b1;
                end
                
            end
            
            ST_MATCH_VERIFY : begin

                //if( bbox_bmap_o != track_vld && bbox_bmap_cnt > 5'd1) 
                 // bbox_bmap_cnt = bbox_bmap_cnt - 1'b1;
                //else
                    //bbox_bmap_cnt <= bbox_bmap_cnt;

                if (j < bbox_bmap_cnt) begin 
                    min_dist_val <= 5'b0;

                    state <= ST_MIN_DIST;
                    if(!new_tracklist_match_flag[0]) begin
			        min_dist_val[0] <= 1'b1;
                        case (j)
                            3'h0 : begin
                                distance_0[0]  <=  $signed(new_tracklist_centroid_0[0]) - $signed({2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0});
                                distance_0[1]  <=  $signed(new_tracklist_centroid_0[1]) - $signed({2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0});                               
                            end
                            
                            3'h1 : begin
                                distance_0[0]  <=  $signed(new_tracklist_centroid_0[0]) - $signed({2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0});
                                distance_0[1]  <=  $signed(new_tracklist_centroid_0[1]) - $signed({2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0});                               
                            end
                            
                            3'h2 : begin
                                distance_0[0]  <=  $signed(new_tracklist_centroid_0[0]) - $signed({2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0});
                                distance_0[1]  <=  $signed(new_tracklist_centroid_0[1]) - $signed({2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0});                               
                            end
                            
                            3'h3 : begin
                                distance_0[0]  <=  $signed(new_tracklist_centroid_0[0]) - $signed({2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0});
                                distance_0[1]  <=  $signed(new_tracklist_centroid_0[1]) - $signed({2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0});                               
                            end
                            
                            3'h4 : begin
                                distance_0[0]  <=  $signed(new_tracklist_centroid_0[0]) - $signed({2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0});
                                distance_0[1]  <=  $signed(new_tracklist_centroid_0[1]) - $signed({2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0});                               
                            end
                        endcase
                    end
                    
                    if(!new_tracklist_match_flag[1]) begin
			        min_dist_val[1] <= 1'b1;
                        case (j)
                            3'h0 : begin
                                distance_1[0]  <=  $signed(new_tracklist_centroid_1[0]) - $signed({2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0});
                                distance_1[1]  <=  $signed(new_tracklist_centroid_1[1]) - $signed({2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0});                               
                            end
                            
                            3'h1 : begin
                                distance_1[0]  <=  $signed(new_tracklist_centroid_1[0]) - $signed({2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0});
                                distance_1[1]  <=  $signed(new_tracklist_centroid_1[1]) - $signed({2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0});                               
                            end
                            
                            3'h2 : begin
                                distance_1[0]  <=  $signed(new_tracklist_centroid_1[0]) - $signed({2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0});
                                distance_1[1]  <=  $signed(new_tracklist_centroid_1[1]) - $signed({2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0});                               
                            end
                            
                            3'h3 : begin
                                distance_1[0]  <=  $signed(new_tracklist_centroid_1[0]) - $signed({2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0});
                                distance_1[1]  <=  $signed(new_tracklist_centroid_1[1]) - $signed({2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0});                               
                            end
                            
                            3'h4 : begin
                                distance_1[0]  <=  $signed(new_tracklist_centroid_1[0]) - $signed({2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0});
                                distance_1[1]  <=  $signed(new_tracklist_centroid_1[1]) - $signed({2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0});                               
                            end
                        endcase
                    end                         
                    
                    if(!new_tracklist_match_flag[2]) begin
			        min_dist_val[2] <= 1'b1;
                        case (j)
                            3'h0 : begin
                                distance_2[0]  <=  $signed(new_tracklist_centroid_2[0]) - $signed({2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0});
                                distance_2[1]  <=  $signed(new_tracklist_centroid_2[1]) - $signed({2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0});                               
                            end
                            
                            3'h1 : begin
                                distance_2[0]  <=  $signed(new_tracklist_centroid_2[0]) - $signed({2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0});
                                distance_2[1]  <=  $signed(new_tracklist_centroid_2[1]) - $signed({2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0});                               
                            end
                            
                            3'h2 : begin
                                distance_2[0]  <=  $signed(new_tracklist_centroid_2[0]) - $signed({2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0});
                                distance_2[1]  <=  $signed(new_tracklist_centroid_2[1]) - $signed({2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0});                               
                            end
                            
                            3'h3 : begin
                                distance_2[0]  <=  $signed(new_tracklist_centroid_2[0]) - $signed({2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0});
                                distance_2[1]  <=  $signed(new_tracklist_centroid_2[1]) - $signed({2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0});                               
                            end
                            
                            3'h4 : begin
                                distance_2[0]  <=  $signed(new_tracklist_centroid_2[0]) - $signed({2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0});
                                distance_2[1]  <=  $signed(new_tracklist_centroid_2[1]) - $signed({2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0});                               
                            end
                        endcase
                    end                             
                    
                    if(!new_tracklist_match_flag[3]) begin
			        min_dist_val[3] <= 1'b1;
                        case (j)
                            3'h0 : begin
                                distance_3[0]  <=  $signed(new_tracklist_centroid_3[0]) - $signed({2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0});
                                distance_3[1]  <=  $signed(new_tracklist_centroid_3[1]) - $signed({2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0});                               
                            end
                            
                            3'h1 : begin
                                distance_3[0]  <=  $signed(new_tracklist_centroid_3[0]) - $signed({2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0});
                                distance_3[1]  <=  $signed(new_tracklist_centroid_3[1]) - $signed({2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0});                               
                            end
                            
                            3'h2 : begin
                                distance_3[0]  <=  $signed(new_tracklist_centroid_3[0]) - $signed({2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0});
                                distance_3[1]  <=  $signed(new_tracklist_centroid_3[1]) - $signed({2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0});                               
                            end
                            
                            3'h3 : begin
                                distance_3[0]  <=  $signed(new_tracklist_centroid_3[0]) - $signed({2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0});
                                distance_3[1]  <=  $signed(new_tracklist_centroid_3[1]) - $signed({2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0});                               
                            end
                            
                            3'h4 : begin
                                distance_3[0]  <=  $signed(new_tracklist_centroid_3[0]) - $signed({2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0});
                                distance_3[1]  <=  $signed(new_tracklist_centroid_3[1]) - $signed({2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0});                               
                            end
                        endcase
                    end                             
                    
                    if(!new_tracklist_match_flag[4]) begin
			        min_dist_val[4] <= 1'b1;
                        case (j)
                            3'h0 : begin
                                distance_4[0]  <=  $signed(new_tracklist_centroid_4[0]) - $signed({2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0});
                                distance_4[1]  <=  $signed(new_tracklist_centroid_4[1]) - $signed({2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0});                               
                            end
                            
                            3'h1 : begin
                                distance_4[0]  <=  $signed(new_tracklist_centroid_4[0]) - $signed({2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0});
                                distance_4[1]  <=  $signed(new_tracklist_centroid_4[1]) - $signed({2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0});                               
                            end
                            
                            3'h2 : begin
                                distance_4[0]  <=  $signed(new_tracklist_centroid_4[0]) - $signed({2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0});
                                distance_4[1]  <=  $signed(new_tracklist_centroid_4[1]) - $signed({2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0});                               
                            end
                            
                            3'h3 : begin
                                distance_4[0]  <=  $signed(new_tracklist_centroid_4[0]) - $signed({2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0});
                                distance_4[1]  <=  $signed(new_tracklist_centroid_4[1]) - $signed({2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0});                               
                            end
                            
                            3'h4 : begin
                                distance_4[0]  <=  $signed(new_tracklist_centroid_4[0]) - $signed({2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0});
                                distance_4[1]  <=  $signed(new_tracklist_centroid_4[1]) - $signed({2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0});                               
                            end
                        endcase
                    end 
                end
                else begin
                    j <= 3'b0;
                    min_dist_set <= 1'b0;
                    state <= ST_UPDATE_DELTAS;
                end
            end
            
            ST_MIN_DIST : begin
                if (min_dist_val != 5'b0)  begin
                    min_dist_en  <= 1'b1;
		            min_dist_val <= 5'b0;
                    state        <= ST_MAX_DIST;
                    exit_state   <= ST_MATCH_VERIFY;
                end
                else begin // Non matching else case
                    state       <= ST_FIRST_FRAME;
                    exit_state  <= ST_MATCH_VERIFY;
                end
            end
       
            ST_MAX_DIST : begin
                min_dist_en <= 1'b0;
				
				if (min_dist_vld != 5'b0) begin
					j <= j + 1'b1;
					
					if (min_dist < MIN_THRESHOLD) begin // min_dist < max_dist(MIN_THRESHOLD)
						
						state <= ST_MATCH_VERIFY;
					        min_dist_set <= 1'b1;
	
						case (min_dist_index)   
							3'd0 : begin
								new_tracklist_match_flag[0] <= 1'b1; 
                                new_tracklist_frame_count_0 <= frame_count;

								if (j == 3'h0) begin 
									new_tracklist_centroid_0[0]     <= {2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0};
									new_tracklist_centroid_0[1]     <= {2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0};
									new_tracklist_detection_0[0]    <= {1'b0,sorted_0[31:24],8'd0}; 
									new_tracklist_detection_0[1]    <= {1'b0,sorted_0[23:16],8'd0};
									new_tracklist_detection_0[2]    <= {1'b0,sorted_0[15:8] ,8'd0};
									new_tracklist_detection_0[3]    <= {1'b0,sorted_0[7:0]  ,8'd0};                             
								end
								else if (j == 3'h1) begin
									new_tracklist_centroid_0[0]     <= {2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0};
									new_tracklist_centroid_0[1]     <= {2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0};
									new_tracklist_detection_0[0]    <= {1'b0,sorted_1[31:24],8'd0}; 
									new_tracklist_detection_0[1]    <= {1'b0,sorted_1[23:16],8'd0};
									new_tracklist_detection_0[2]    <= {1'b0,sorted_1[15:8] ,8'd0};
									new_tracklist_detection_0[3]    <= {1'b0,sorted_1[7:0]  ,8'd0}; 
								end
								else if (j == 3'h2) begin
									new_tracklist_centroid_0[0]     <= {2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0};
									new_tracklist_centroid_0[1]     <= {2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0};   
									new_tracklist_detection_0[0]    <= {1'b0,sorted_2[31:24],8'd0}; 
									new_tracklist_detection_0[1]    <= {1'b0,sorted_2[23:16],8'd0};
									new_tracklist_detection_0[2]    <= {1'b0,sorted_2[15:8] ,8'd0};
									new_tracklist_detection_0[3]    <= {1'b0,sorted_2[7:0]  ,8'd0}; 
								end
								else if (j == 3'h3) begin
									new_tracklist_centroid_0[0]     <= {2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0};
									new_tracklist_centroid_0[1]     <= {2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0};   
									new_tracklist_detection_0[0]    <= {1'b0,sorted_3[31:24],8'd0}; 
									new_tracklist_detection_0[1]    <= {1'b0,sorted_3[23:16],8'd0};
									new_tracklist_detection_0[2]    <= {1'b0,sorted_3[15:8] ,8'd0};
									new_tracklist_detection_0[3]    <= {1'b0,sorted_3[7:0]  ,8'd0}; 
								end
								else if (j == 3'h4) begin
									new_tracklist_centroid_0[0]     <= {2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0};
									new_tracklist_centroid_0[1]     <= {2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0};
									new_tracklist_detection_0[0]    <= {1'b0,sorted_4[31:24],8'd0}; 
									new_tracklist_detection_0[1]    <= {1'b0,sorted_4[23:16],8'd0};
									new_tracklist_detection_0[2]    <= {1'b0,sorted_4[15:8] ,8'd0};
									new_tracklist_detection_0[3]    <= {1'b0,sorted_4[7:0]  ,8'd0}; 
								end
							end
							
							3'd1 : begin
								new_tracklist_match_flag[1] <= 1'b1;
                                new_tracklist_frame_count_1 <= frame_count;
								if (j == 3'h0) begin
									new_tracklist_centroid_1[0]     <= {2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0};
									new_tracklist_centroid_1[1]     <= {2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0};
									new_tracklist_detection_1[0]    <= {1'b0,sorted_0[31:24],8'd0}; 
									new_tracklist_detection_1[1]    <= {1'b0,sorted_0[23:16],8'd0};
									new_tracklist_detection_1[2]    <= {1'b0,sorted_0[15:8] ,8'd0};
									new_tracklist_detection_1[3]    <= {1'b0,sorted_0[7:0]  ,8'd0};                             
								end
								else if (j == 3'h1) begin
									new_tracklist_centroid_1[0]     <= {2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0};
									new_tracklist_centroid_1[1]     <= {2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0};
									new_tracklist_detection_1[0]    <= {1'b0,sorted_1[31:24],8'd0}; 
									new_tracklist_detection_1[1]    <= {1'b0,sorted_1[23:16],8'd0};
									new_tracklist_detection_1[2]    <= {1'b0,sorted_1[15:8] ,8'd0};
									new_tracklist_detection_1[3]    <= {1'b0,sorted_1[7:0]  ,8'd0}; 
								end
								else if (j == 3'h2) begin
									new_tracklist_centroid_1[0]     <= {2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0};
									new_tracklist_centroid_1[1]     <= {2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0};   
									new_tracklist_detection_1[0]    <= {1'b0,sorted_2[31:24],8'd0}; 
									new_tracklist_detection_1[1]    <= {1'b0,sorted_2[23:16],8'd0};
									new_tracklist_detection_1[2]    <= {1'b0,sorted_2[15:8] ,8'd0};
									new_tracklist_detection_1[3]    <= {1'b0,sorted_2[7:0]  ,8'd0}; 
								end
								else if (j == 3'h3) begin
									new_tracklist_centroid_1[0]     <= {2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0};
									new_tracklist_centroid_1[1]     <= {2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0};   
									new_tracklist_detection_1[0]    <= {1'b0,sorted_3[31:24],8'd0}; 
									new_tracklist_detection_1[1]    <= {1'b0,sorted_3[23:16],8'd0};
									new_tracklist_detection_1[2]    <= {1'b0,sorted_3[15:8] ,8'd0};
									new_tracklist_detection_1[3]    <= {1'b0,sorted_3[7:0]  ,8'd0}; 
								end
								else if (j == 3'h4) begin
									new_tracklist_centroid_1[0]     <= {2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0};
									new_tracklist_centroid_1[1]     <= {2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0};
									new_tracklist_detection_1[0]    <= {1'b0,sorted_4[31:24],8'd0}; 
									new_tracklist_detection_1[1]    <= {1'b0,sorted_4[23:16],8'd0};
									new_tracklist_detection_1[2]    <= {1'b0,sorted_4[15:8] ,8'd0};
									new_tracklist_detection_1[3]    <= {1'b0,sorted_4[7:0]  ,8'd0}; 
								end                     
							end
							
							3'd2 : begin
								new_tracklist_match_flag[2] <= 1'b1; 
                                new_tracklist_frame_count_2 <= frame_count;
								if (j == 3'h0) begin
									new_tracklist_centroid_2[0]     <= {2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0};
									new_tracklist_centroid_2[1]     <= {2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0};
									new_tracklist_detection_2[0]    <= {1'b0,sorted_0[31:24],8'd0}; 
									new_tracklist_detection_2[1]    <= {1'b0,sorted_0[23:16],8'd0};
									new_tracklist_detection_2[2]    <= {1'b0,sorted_0[15:8] ,8'd0};
									new_tracklist_detection_2[3]    <= {1'b0,sorted_0[7:0]  ,8'd0};                             
								end
								else if (j == 3'h1) begin
									new_tracklist_centroid_2[0]     <= {2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0};
									new_tracklist_centroid_2[1]     <= {2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0};
									new_tracklist_detection_2[0]    <= {1'b0,sorted_1[31:24],8'd0}; 
									new_tracklist_detection_2[1]    <= {1'b0,sorted_1[23:16],8'd0};
									new_tracklist_detection_2[2]    <= {1'b0,sorted_1[15:8] ,8'd0};
									new_tracklist_detection_2[3]    <= {1'b0,sorted_1[7:0]  ,8'd0}; 
								end
								else if (j == 3'h2) begin
									new_tracklist_centroid_2[0]     <= {2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0};
									new_tracklist_centroid_2[1]     <= {2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0};   
									new_tracklist_detection_2[0]    <= {1'b0,sorted_2[31:24],8'd0}; 
									new_tracklist_detection_2[1]    <= {1'b0,sorted_2[23:16],8'd0};
									new_tracklist_detection_2[2]    <= {1'b0,sorted_2[15:8] ,8'd0};
									new_tracklist_detection_2[3]    <= {1'b0,sorted_2[7:0]  ,8'd0}; 
								end
								else if (j == 3'h3) begin
									new_tracklist_centroid_2[0]     <= {2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0};
									new_tracklist_centroid_2[1]     <= {2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0};   
									new_tracklist_detection_2[0]    <= {1'b0,sorted_3[31:24],8'd0}; 
									new_tracklist_detection_2[1]    <= {1'b0,sorted_3[23:16],8'd0};
									new_tracklist_detection_2[2]    <= {1'b0,sorted_3[15:8] ,8'd0};
									new_tracklist_detection_2[3]    <= {1'b0,sorted_3[7:0]  ,8'd0}; 
								end
								else if (j == 3'h4) begin
									new_tracklist_centroid_2[0]     <= {2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0};
									new_tracklist_centroid_2[1]     <= {2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0};
									new_tracklist_detection_2[0]    <= {1'b0,sorted_4[31:24],8'd0}; 
									new_tracklist_detection_2[1]    <= {1'b0,sorted_4[23:16],8'd0};
									new_tracklist_detection_2[2]    <= {1'b0,sorted_4[15:8] ,8'd0};
									new_tracklist_detection_2[3]    <= {1'b0,sorted_4[7:0]  ,8'd0}; 
								end                 
							end
							
							3'd3 : begin
								new_tracklist_match_flag[3] <= 1'b1;
                                new_tracklist_frame_count_3 <= frame_count;
								if (j == 3'h0) begin
									new_tracklist_centroid_3[0]     <= {2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0};
									new_tracklist_centroid_3[1]     <= {2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0};
									new_tracklist_detection_3[0]    <= {1'b0,sorted_0[31:24],8'd0}; 
									new_tracklist_detection_3[1]    <= {1'b0,sorted_0[23:16],8'd0};
									new_tracklist_detection_3[2]    <= {1'b0,sorted_0[15:8] ,8'd0};
									new_tracklist_detection_3[3]    <= {1'b0,sorted_0[7:0]  ,8'd0};                             
								end
								else if (j == 3'h1) begin
									new_tracklist_centroid_3[0]     <= {2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0};
									new_tracklist_centroid_3[1]     <= {2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0};
									new_tracklist_detection_3[0]    <= {1'b0,sorted_1[31:24],8'd0}; 
									new_tracklist_detection_3[1]    <= {1'b0,sorted_1[23:16],8'd0};
									new_tracklist_detection_3[2]    <= {1'b0,sorted_1[15:8] ,8'd0};
									new_tracklist_detection_3[3]    <= {1'b0,sorted_1[7:0]  ,8'd0}; 
								end
								else if (j == 3'h2) begin
									new_tracklist_centroid_3[0]     <= {2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0};
									new_tracklist_centroid_3[1]     <= {2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0};   
									new_tracklist_detection_3[0]    <= {1'b0,sorted_2[31:24],8'd0}; 
									new_tracklist_detection_3[1]    <= {1'b0,sorted_2[23:16],8'd0};
									new_tracklist_detection_3[2]    <= {1'b0,sorted_2[15:8] ,8'd0};
									new_tracklist_detection_3[3]    <= {1'b0,sorted_2[7:0]  ,8'd0}; 
								end
								else if (j == 3'h3) begin
									new_tracklist_centroid_3[0]     <= {2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0};
									new_tracklist_centroid_3[1]     <= {2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0};   
									new_tracklist_detection_3[0]    <= {1'b0,sorted_3[31:24],8'd0}; 
									new_tracklist_detection_3[1]    <= {1'b0,sorted_3[23:16],8'd0};
									new_tracklist_detection_3[2]    <= {1'b0,sorted_3[15:8] ,8'd0};
									new_tracklist_detection_3[3]    <= {1'b0,sorted_3[7:0]  ,8'd0}; 
								end
								else if (j == 3'h4) begin
									new_tracklist_centroid_3[0]     <= {2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0};
									new_tracklist_centroid_3[1]     <= {2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0};
									new_tracklist_detection_3[0]    <= {1'b0,sorted_4[31:24],8'd0}; 
									new_tracklist_detection_3[1]    <= {1'b0,sorted_4[23:16],8'd0};
									new_tracklist_detection_3[2]    <= {1'b0,sorted_4[15:8] ,8'd0};
									new_tracklist_detection_3[3]    <= {1'b0,sorted_4[7:0]  ,8'd0}; 
								end                 
							end
							
							3'd4 : begin
								new_tracklist_match_flag[4] <= 1'b1;
                                new_tracklist_frame_count_4 <= frame_count;
								if (j == 3'h0) begin
									new_tracklist_centroid_4[0]     <= {2'b0,sorted_0[31:24],7'd0} + {2'b0,sorted_0[15:8] ,7'd0};
									new_tracklist_centroid_4[1]     <= {2'b0,sorted_0[23:16],7'd0} + {2'b0,sorted_0[7:0]  ,7'd0};
									new_tracklist_detection_4[0]    <= {1'b0,sorted_0[31:24],8'd0}; 
									new_tracklist_detection_4[1]    <= {1'b0,sorted_0[23:16],8'd0};
									new_tracklist_detection_4[2]    <= {1'b0,sorted_0[15:8] ,8'd0};
									new_tracklist_detection_4[3]    <= {1'b0,sorted_0[7:0]  ,8'd0};                             
								end
								else if (j == 3'h1) begin
									new_tracklist_centroid_4[0]     <= {2'b0,sorted_1[31:24],7'd0} + {2'b0,sorted_1[15:8] ,7'd0};
									new_tracklist_centroid_4[1]     <= {2'b0,sorted_1[23:16],7'd0} + {2'b0,sorted_1[7:0]  ,7'd0};
									new_tracklist_detection_4[0]    <= {1'b0,sorted_1[31:24],8'd0}; 
									new_tracklist_detection_4[1]    <= {1'b0,sorted_1[23:16],8'd0};
									new_tracklist_detection_4[2]    <= {1'b0,sorted_1[15:8] ,8'd0};
									new_tracklist_detection_4[3]    <= {1'b0,sorted_1[7:0]  ,8'd0}; 
								end
								else if (j == 3'h2) begin
									new_tracklist_centroid_4[0]     <= {2'b0,sorted_2[31:24],7'd0} + {2'b0,sorted_2[15:8] ,7'd0};
									new_tracklist_centroid_4[1]     <= {2'b0,sorted_2[23:16],7'd0} + {2'b0,sorted_2[7:0]  ,7'd0};   
									new_tracklist_detection_4[0]    <= {1'b0,sorted_2[31:24],8'd0}; 
									new_tracklist_detection_4[1]    <= {1'b0,sorted_2[23:16],8'd0};
									new_tracklist_detection_4[2]    <= {1'b0,sorted_2[15:8] ,8'd0};
									new_tracklist_detection_4[3]    <= {1'b0,sorted_2[7:0]  ,8'd0}; 
								end
								else if (j == 3'h3) begin
									new_tracklist_centroid_4[0]     <= {2'b0,sorted_3[31:24],7'd0} + {2'b0,sorted_3[15:8] ,7'd0};
									new_tracklist_centroid_4[1]     <= {2'b0,sorted_3[23:16],7'd0} + {2'b0,sorted_3[7:0]  ,7'd0};   
									new_tracklist_detection_4[0]    <= {1'b0,sorted_3[31:24],8'd0}; 
									new_tracklist_detection_4[1]    <= {1'b0,sorted_3[23:16],8'd0};
									new_tracklist_detection_4[2]    <= {1'b0,sorted_3[15:8] ,8'd0};
									new_tracklist_detection_4[3]    <= {1'b0,sorted_3[7:0]  ,8'd0}; 
								end
								else if (j == 3'h4) begin
									new_tracklist_centroid_4[0]     <= {2'b0,sorted_4[31:24],7'd0} + {2'b0,sorted_4[15:8] ,7'd0};
									new_tracklist_centroid_4[1]     <= {2'b0,sorted_4[23:16],7'd0} + {2'b0,sorted_4[7:0]  ,7'd0};
									new_tracklist_detection_4[0]    <= {1'b0,sorted_4[31:24],8'd0}; 
									new_tracklist_detection_4[1]    <= {1'b0,sorted_4[23:16],8'd0};
									new_tracklist_detection_4[2]    <= {1'b0,sorted_4[15:8] ,8'd0};
									new_tracklist_detection_4[3]    <= {1'b0,sorted_4[7:0]  ,8'd0}; 
								end                     
							end
						endcase
					end
					else begin 
                        id <= j;
                         if (j==0 && bbox_bmap_cnt == 5'h1 ) begin // to update the new box in ST_TRACKER 
                          bbox_bmap_cnt <= bbox_bmap_cnt +1;
                        end
                        //else begin
                         //   tracker_limit <= bbox_bmap_cnt;
                        //end
						  state <= ST_FIRST_FRAME;
						  exit_state <= ST_MATCH_VERIFY;
					end
				end
            end
            
            ST_UPDATE_DELTAS : begin
                state <= ST_MEDIAN;
                count_list_reg <= {plus_id,triangle_id,square_id,octagon_id,circle_id};
                xy_diff_val <= 5'b0;
                
                if (new_tracklist_match_flag[0] != 1'b0) begin
                    if (new_tracklist_id_0 == old_tracklist_id_0) begin
                        xy_diff_val[0]  <= 1'b1;
                        x_diff_0        <= new_tracklist_centroid_0[0] - old_tracklist_centroid_0[0];
                        y_diff_0        <= new_tracklist_centroid_0[1] - old_tracklist_centroid_0[1];               
                    end
                    else if (new_tracklist_id_0 == old_tracklist_id_1) begin
                        xy_diff_val[0]  <= 1'b1;
                        x_diff_0        <= new_tracklist_centroid_0[0] - old_tracklist_centroid_1[0];
                        y_diff_0        <= new_tracklist_centroid_0[1] - old_tracklist_centroid_1[1];               
                    end             
                    else if (new_tracklist_id_0 == old_tracklist_id_2) begin
                        xy_diff_val[0]  <= 1'b1;
                        x_diff_0        <= new_tracklist_centroid_0[0] - old_tracklist_centroid_2[0];
                        y_diff_0        <= new_tracklist_centroid_0[1] - old_tracklist_centroid_2[1];               
                    end
                    else if (new_tracklist_id_0 == old_tracklist_id_3) begin
                        xy_diff_val[0]  <= 1'b1;
                        x_diff_0        <= new_tracklist_centroid_0[0] - old_tracklist_centroid_3[0];
                        y_diff_0        <= new_tracklist_centroid_0[1] - old_tracklist_centroid_3[1];               
                    end             
                    else if (new_tracklist_id_0 == old_tracklist_id_4) begin
                        xy_diff_val[0]  <= 1'b1;
                        x_diff_0        <= new_tracklist_centroid_0[0] - old_tracklist_centroid_4[0];
                        y_diff_0        <= new_tracklist_centroid_0[1] - old_tracklist_centroid_4[1];               
                    end 
                end
                
		if (new_tracklist_match_flag[1] != 1'b0) begin
                    
                    if (new_tracklist_id_1 == old_tracklist_id_0) begin
                        xy_diff_val[1]  <= 1'b1;
                        x_diff_1        <= new_tracklist_centroid_1[0] - old_tracklist_centroid_0[0];
                        y_diff_1        <= new_tracklist_centroid_1[1] - old_tracklist_centroid_0[1];               
                    end
                    else if (new_tracklist_id_1 == old_tracklist_id_1) begin
                        xy_diff_val[1]  <= 1'b1;
                        x_diff_1        <= new_tracklist_centroid_1[0] - old_tracklist_centroid_1[0];
                        y_diff_1        <= new_tracklist_centroid_1[1] - old_tracklist_centroid_1[1];               
                    end             
                    else if (new_tracklist_id_1 == old_tracklist_id_2) begin
                        xy_diff_val[1]  <= 1'b1;
                        x_diff_1        <= new_tracklist_centroid_1[0] - old_tracklist_centroid_2[0];
                        y_diff_1        <= new_tracklist_centroid_1[1] - old_tracklist_centroid_2[1];               
                    end
                    else if (new_tracklist_id_1 == old_tracklist_id_3) begin
                        xy_diff_val[1]  <= 1'b1;
                        x_diff_1        <= new_tracklist_centroid_1[0] - old_tracklist_centroid_3[0];
                        y_diff_1        <= new_tracklist_centroid_1[1] - old_tracklist_centroid_3[1];               
                    end             
                    else if (new_tracklist_id_1 == old_tracklist_id_4) begin
                        xy_diff_val[1]  <= 1'b1;
                        x_diff_1        <= new_tracklist_centroid_1[0] - old_tracklist_centroid_4[0];
                        y_diff_1        <= new_tracklist_centroid_1[1] - old_tracklist_centroid_4[1];               
                    end                 
                 end

                 if (new_tracklist_match_flag[2] != 1'b0) begin
                    if (new_tracklist_id_2 == old_tracklist_id_0) begin
                        xy_diff_val[2]  <= 1'b1;
                        x_diff_2        <= new_tracklist_centroid_2[0] - old_tracklist_centroid_0[0];
                        y_diff_2        <= new_tracklist_centroid_2[1] - old_tracklist_centroid_0[1];               
                    end
                    else if (new_tracklist_id_2 == old_tracklist_id_1) begin
                        xy_diff_val[2]  <= 1'b1;
                        x_diff_2        <= new_tracklist_centroid_2[0] - old_tracklist_centroid_1[0];
                        y_diff_2        <= new_tracklist_centroid_2[1] - old_tracklist_centroid_1[1];               
                    end             
                    else if (new_tracklist_id_2 == old_tracklist_id_2) begin
                        xy_diff_val[2]  <= 1'b1;
                        x_diff_2        <= new_tracklist_centroid_2[0] - old_tracklist_centroid_2[0];
                        y_diff_2        <= new_tracklist_centroid_2[1] - old_tracklist_centroid_2[1];               
                    end
                    else if (new_tracklist_id_2 == old_tracklist_id_3) begin
                        xy_diff_val[2]  <= 1'b1;
                        x_diff_2        <= new_tracklist_centroid_2[0] - old_tracklist_centroid_3[0];
                        y_diff_2        <= new_tracklist_centroid_2[1] - old_tracklist_centroid_3[1];               
                    end             
                    else if (new_tracklist_id_2 == old_tracklist_id_4) begin
                        xy_diff_val[2]  <= 1'b1;
                        x_diff_2        <= new_tracklist_centroid_2[0] - old_tracklist_centroid_4[0];
                        y_diff_2        <= new_tracklist_centroid_2[1] - old_tracklist_centroid_4[1];               
                    end 
                 end
   
                 if (new_tracklist_match_flag[3] != 1'b0) begin
                    if (new_tracklist_id_3 == old_tracklist_id_0) begin
                        xy_diff_val[3]  <= 1'b1;
                        x_diff_3        <= new_tracklist_centroid_3[0] - old_tracklist_centroid_0[0];
                        y_diff_3        <= new_tracklist_centroid_3[1] - old_tracklist_centroid_0[1];               
                    end
                    else if (new_tracklist_id_3 == old_tracklist_id_1) begin
                        xy_diff_val[3]  <= 1'b1;
                        x_diff_3        <= new_tracklist_centroid_3[0] - old_tracklist_centroid_1[0];
                        y_diff_3        <= new_tracklist_centroid_3[1] - old_tracklist_centroid_1[1];               
                    end             
                    else if (new_tracklist_id_3 == old_tracklist_id_2) begin
                        xy_diff_val[3]  <= 1'b1;
                        x_diff_3        <= new_tracklist_centroid_3[0] - old_tracklist_centroid_2[0];
                        y_diff_3        <= new_tracklist_centroid_3[1] - old_tracklist_centroid_2[1];               
                    end
                    else if (new_tracklist_id_3 == old_tracklist_id_3) begin
                        xy_diff_val[3]  <= 1'b1;
                        x_diff_3        <= new_tracklist_centroid_3[0] - old_tracklist_centroid_3[0];
                        y_diff_3        <= new_tracklist_centroid_3[1] - old_tracklist_centroid_3[1];               
                    end             
                    else if (new_tracklist_id_3 == old_tracklist_id_4) begin
                        xy_diff_val[3]  <= 1'b1;
                        x_diff_3        <= new_tracklist_centroid_3[0] - old_tracklist_centroid_4[0];
                        y_diff_3        <= new_tracklist_centroid_3[1] - old_tracklist_centroid_4[1];               
                    end
                 end
   
                 if (new_tracklist_match_flag[4] != 1'b0) begin
                    if (new_tracklist_id_4 == old_tracklist_id_0) begin
                        xy_diff_val[4]  <= 1'b1;
                        x_diff_4        <= new_tracklist_centroid_4[0] - old_tracklist_centroid_0[0];
                        y_diff_4        <= new_tracklist_centroid_4[1] - old_tracklist_centroid_0[1];               
                    end
                    else if (new_tracklist_id_4 == old_tracklist_id_1) begin
                        xy_diff_val[4]  <= 1'b1;
                        x_diff_4        <= new_tracklist_centroid_4[0] - old_tracklist_centroid_1[0];
                        y_diff_4        <= new_tracklist_centroid_4[1] - old_tracklist_centroid_1[1];               
                    end             
                    else if (new_tracklist_id_4 == old_tracklist_id_2) begin
                        xy_diff_val[4]  <= 1'b1;
                        x_diff_4        <= new_tracklist_centroid_4[0] - old_tracklist_centroid_2[0];
                        y_diff_4        <= new_tracklist_centroid_4[1] - old_tracklist_centroid_2[1];               
                    end
                    else if (new_tracklist_id_4 == old_tracklist_id_3) begin
                        xy_diff_val[4]  <= 1'b1;
                        x_diff_4        <= new_tracklist_centroid_4[0] - old_tracklist_centroid_3[0];
                        y_diff_4        <= new_tracklist_centroid_4[1] - old_tracklist_centroid_3[1];               
                    end             
                    else if (new_tracklist_id_4 == old_tracklist_id_4) begin
                        xy_diff_val[4]  <= 1'b1;
                        x_diff_4        <= new_tracklist_centroid_4[0] - old_tracklist_centroid_4[0];
                        y_diff_4        <= new_tracklist_centroid_4[1] - old_tracklist_centroid_4[1];               
                    end                  
                end
            end
            
            ST_MEDIAN : begin
                if (xy_diff_val != 5'b0) begin
                    state       <= ST_AVERAGE;
                    strt_median <= 1'b1;
                    median_valid <=  xy_diff_val[0] + xy_diff_val[1] + xy_diff_val[2] + xy_diff_val[3] + xy_diff_val[4];
                    
                    if (div_val == 20'd25)
                        div_val <= 1'b1;
                    else
                        div_val <= div_val + 1'b1;
                    
                end
                else begin
                    state <= ST_FINAL;
                end
            end
            
            ST_AVERAGE : begin
                strt_median <= 1'b0;
                
                if (median_donex || median_doney) begin
                    state <= ST_DIV_DONE;
                    strt_div <= 1'b1;
                    
                    if (div_val == 5'b1) begin
                        sum_delx <= op_medianx;
                        sum_dely <= op_mediany;
                    end
                    else begin
                        sum_delx <= sum_delx + op_medianx;
                        sum_dely <= sum_dely + op_mediany;                  
                    end
                end
            end
            
            ST_DIV_DONE : begin
                strt_div <= 1'b0;
                if (avg_delx_valid || avg_dely_valid) begin
                    state <= ST_FINAL;
                end
            end
            
            ST_FINAL  : begin
			out_update <= 1'b1;
                	state <= ST_IDLE;
  
				final_bbox_vld_reg	    <=	bbox_bmap_o;
				final_bbox_cls_reg  	<= {r_cls_bmap_new[4],r_cls_bmap_new[3],r_cls_bmap_new[2],r_cls_bmap_new[1],r_cls_bmap_new[0]}; //	cls_bmap_o;
				final_count_list_reg 	<= 	count_list_reg;
				
				final_tracklist_0_reg[31:24] <= ( new_tracklist_detection_0[0] < 0) ? 8'h0 : new_tracklist_detection_0[0][15:8];
				final_tracklist_0_reg[23:16] <= ( new_tracklist_detection_0[1] < 0) ? 8'h0 : new_tracklist_detection_0[1][15:8];
				final_tracklist_0_reg[15:8]  <= ( new_tracklist_detection_0[2] < 0) ? 8'h0 : new_tracklist_detection_0[2][15:8];
				final_tracklist_0_reg[7:0]   <= ( new_tracklist_detection_0[3] < 0) ? 8'h0 : new_tracklist_detection_0[3][15:8];
				
				final_tracklist_1_reg[31:24] <= ( new_tracklist_detection_1[0] < 0) ? 8'h0 : new_tracklist_detection_1[0][15:8];
				final_tracklist_1_reg[23:16] <= ( new_tracklist_detection_1[1] < 0) ? 8'h0 : new_tracklist_detection_1[1][15:8];
				final_tracklist_1_reg[15:8]  <= ( new_tracklist_detection_1[2] < 0) ? 8'h0 : new_tracklist_detection_1[2][15:8];
				final_tracklist_1_reg[7:0]   <= ( new_tracklist_detection_1[3] < 0) ? 8'h0 : new_tracklist_detection_1[3][15:8];				
				
				final_tracklist_2_reg[31:24] <= ( new_tracklist_detection_2[0] < 0) ? 8'h0 : new_tracklist_detection_2[0][15:8];
				final_tracklist_2_reg[23:16] <= ( new_tracklist_detection_2[1] < 0) ? 8'h0 : new_tracklist_detection_2[1][15:8];
				final_tracklist_2_reg[15:8]  <= ( new_tracklist_detection_2[2] < 0) ? 8'h0 : new_tracklist_detection_2[2][15:8];
				final_tracklist_2_reg[7:0]   <= ( new_tracklist_detection_2[3] < 0) ? 8'h0 : new_tracklist_detection_2[3][15:8];				
				
				final_tracklist_3_reg[31:24] <= ( new_tracklist_detection_3[0] < 0) ? 8'h0 : new_tracklist_detection_3[0][15:8];
				final_tracklist_3_reg[23:16] <= ( new_tracklist_detection_3[1] < 0) ? 8'h0 : new_tracklist_detection_3[1][15:8];
				final_tracklist_3_reg[15:8]  <= ( new_tracklist_detection_3[2] < 0) ? 8'h0 : new_tracklist_detection_3[2][15:8];
				final_tracklist_3_reg[7:0]   <= ( new_tracklist_detection_3[3] < 0) ? 8'h0 : new_tracklist_detection_3[3][15:8];				
				
				final_tracklist_4_reg[31:24] <= ( new_tracklist_detection_4[0] < 0) ? 8'h0 : new_tracklist_detection_4[0][15:8];
				final_tracklist_4_reg[23:16] <= ( new_tracklist_detection_4[1] < 0) ? 8'h0 : new_tracklist_detection_4[1][15:8];
				final_tracklist_4_reg[15:8]  <= ( new_tracklist_detection_4[2] < 0) ? 8'h0 : new_tracklist_detection_4[2][15:8];
				final_tracklist_4_reg[7:0]   <= ( new_tracklist_detection_4[3] < 0) ? 8'h0 : new_tracklist_detection_4[3][15:8];				
			    
 
            end
            
            default : ;
            
        endcase
    end
end

always @(posedge clk, negedge resetn) begin
  if (!resetn) begin
    min_dist_val_1d 		<= 5'h0;
    sqr_op_distance_vld_0 	<= 1'b0;
    sqr_op_distance_vld_1 	<= 1'b0;
    sqr_op_distance_vld_2 	<= 1'b0; 
    sqr_op_distance_vld_3 	<= 1'b0; 
    sqr_op_distance_vld_4 	<= 1'b0; 
  end
  else begin
    min_dist_val_1d 		<= min_dist_val;
    sqr_op_distance_vld_0 	<= min_dist_val_1d[0];
    sqr_op_distance_vld_1 	<= min_dist_val_1d[1];
    sqr_op_distance_vld_2 	<= min_dist_val_1d[2]; 
    sqr_op_distance_vld_3 	<= min_dist_val_1d[3]; 
    sqr_op_distance_vld_4 	<= min_dist_val_1d[4]; 

  end
end

always @(posedge clk, negedge resetn) begin
  if (!resetn) begin
     tracker_sorted_0 <= 32'h0;
     tracker_sorted_1 <= 32'h0;
     tracker_sorted_2 <= 32'h0;
     tracker_sorted_3 <= 32'h0;
     tracker_sorted_4 <= 32'h0;
     new_tracker_updated <= 5'h1F;
  end
  else begin
  //     tracker_sorted_0 <= sorted_0;
  //     tracker_sorted_1 <= sorted_1;
  //     tracker_sorted_2 <= sorted_2;
  //     tracker_sorted_3 <= sorted_3;
  //     tracker_sorted_4 <= sorted_4;

    if(state == ST_MAX_DIST && min_dist > MIN_THRESHOLD & !min_dist_set) begin
      case (old_tracklist_match_flag)
        5'h1 : begin
            new_tracker_updated <= 5'h1E;
            tracker_sorted_1 <= sorted_0;
            tracker_sorted_2 <= sorted_1;
            tracker_sorted_3 <= sorted_2;
            tracker_sorted_4 <= sorted_3;
        end

        5'h3 : begin
     	    new_tracker_updated <= 5'h1C;
            tracker_sorted_2 <= sorted_0;
            tracker_sorted_3 <= sorted_1;
            tracker_sorted_4 <= sorted_2;
        end

        5'h7 : begin
            new_tracker_updated <= 5'h18;
            tracker_sorted_3 <= sorted_0;
            tracker_sorted_4 <= sorted_1;
        end

        5'hF : begin
            new_tracker_updated <= 5'h10;
            tracker_sorted_4 <= sorted_0;
        end

        default : begin
            new_tracker_updated <= 5'h1F;
            tracker_sorted_0 <= sorted_0;
            tracker_sorted_1 <= sorted_1;
            tracker_sorted_2 <= sorted_2;
            tracker_sorted_3 <= sorted_3;
            tracker_sorted_4 <= sorted_4;
        end
      endcase
    end
    else if (state == ST_MATCH_TRACKLIST || state == ST_MIN_DIST) begin
       new_tracker_updated <= 5'h1F;
       tracker_sorted_0 <= sorted_0;
       tracker_sorted_1 <= sorted_1;
       tracker_sorted_2 <= sorted_2;
       tracker_sorted_3 <= sorted_3;
       tracker_sorted_4 <= sorted_4;
    end
  end 
end

always @(posedge clk or negedge resetn) begin

if (!resetn) begin
  tempx[0] <= 20'h0;
  tempy[0] <= 20'h0;
  tempx[1] <= 20'h0;
  tempy[1] <= 20'h0;
  tempx[2] <= 20'h0;
  tempy[2] <= 20'h0;
  tempx[3] <= 20'h0;
  tempy[3] <= 20'h0;
  tempx[4] <= 20'h0;
  tempy[4] <= 20'h0;
end
else begin
      // to make non-valid/garbage to zero 
   if(!new_tracklist_frame_count_0)begin
     tempx[0] <= 20'h0;
     tempy[0] <= 20'h0;
   end
   else begin
     tempx[0] <= $signed (avg_delx * (frame_count - new_tracklist_frame_count_0));
     tempy[0] <= $signed (avg_dely * (frame_count - new_tracklist_frame_count_0));
   end

   if(!new_tracklist_frame_count_1)begin
    tempx[1] <= 20'h0;
    tempy[1] <= 20'h0;
   end
   else begin
     tempx[1] <= $signed (avg_delx * (frame_count - new_tracklist_frame_count_1));
     tempy[1] <= $signed (avg_dely * (frame_count - new_tracklist_frame_count_1));
   end

   if(!new_tracklist_frame_count_2)begin
    tempx[2] <= 20'h0;
    tempy[2] <= 20'h0;
   end
   else begin
     tempx[2] <= $signed (avg_delx * (frame_count - new_tracklist_frame_count_2));
     tempy[2] <= $signed (avg_dely * (frame_count - new_tracklist_frame_count_2));
   end

   if(!new_tracklist_frame_count_3)begin
    tempx[3] <= 20'h0;
    tempy[3] <= 20'h0;
   end
   else begin
     tempx[3] <= $signed (avg_delx * (frame_count - new_tracklist_frame_count_3));
     tempy[3] <= $signed (avg_dely * (frame_count - new_tracklist_frame_count_3));
   end

   if(!new_tracklist_frame_count_4)begin
    tempx[4] <= 20'h0;
    tempy[4] <= 20'h0;
   end
   else begin
     tempx[4] <= $signed (avg_delx * (frame_count - new_tracklist_frame_count_4));
     tempy[4] <= $signed (avg_dely * (frame_count - new_tracklist_frame_count_4));
   end
end
end

always @(posedge clk) begin

  if(final_tracklist5) begin
    track_vld <= 5'b11111;
    track_count <= 5'h5;
  end else if(final_tracklist4) begin
    track_vld <= 5'b01111;
    track_count <= 5'h4;
  end else if(final_tracklist3) begin
    track_vld <= 5'b00111;
    track_count <= 5'h3;
  end else if(final_tracklist2) begin
    track_vld <= 5'b00011;
    track_count <= 5'h2;
  end else if(final_tracklist1) begin
    track_vld <= 5'b00001;
    track_count <= 5'h1;
  end
end

// =================================================================================================
     // Sub Modules instantiations
// =================================================================================================
sort  #(
   .IP_WIDTH  (32),
    .NUM_CLASS (5)
) i0_sort (
    .clk            (clk),
    .resetn         (resetn),
    .start_flag     (i_vs & !i_vs_d1),
    .i_bbox_00      (i_bbox_00),
    .i_bbox_01      (i_bbox_01),
    .i_bbox_02      (i_bbox_02),
    .i_bbox_03      (i_bbox_03),
    .i_bbox_04      (i_bbox_04),
    .i_bbox_bmap    (i_bbox_bmap),
    .i_cls_bmap     (i_cls_bmap),
    .sorted_0       (sorted_0),
    .sorted_1       (sorted_1),
    .sorted_2       (sorted_2),
    .sorted_3       (sorted_3),
    .sorted_4       (sorted_4),
    .bbox_bmap_o    (bbox_bmap_o),
    .cls_bmap_o     (cls_bmap_o),
    .sort_done      (sort_done)
);

div #(
    .WIDTH (20)
) i0_div_x (
    .clk        (clk),
    .resetn     (resetn),
    .start      (strt_div),
    .A          (sum_delx),
    .B          (div_val),
    .op_valid   (avg_delx_valid),
    .Res        (avg_delx)
);

div #(
    .WIDTH (20)
) i0_div_y (
    .clk        (clk),
    .resetn     (resetn),
    .start      (strt_div),
    .A          (sum_dely),
    .B          (div_val),
    .op_valid   (avg_dely_valid),
    .Res        (avg_dely)
);


median #(
    .IP_WIDTH   (16),
    .NUM_CLASS  (5)
) i0_median_x (
    .clk         (clk),
    .resetn      (resetn),
    .start_flag  (strt_median),
    .i_dval_00   (x_diff_0),
    .i_dval_01   (x_diff_1),
    .i_dval_02   (x_diff_2),
    .i_dval_03   (x_diff_3),
    .del_val     (median_valid),
    .i_dval_valid (xy_diff_val[3:0]),
    .op_median   (op_medianx),
    .median_done (median_donex)
);

median #(
    .IP_WIDTH   (16),
    .NUM_CLASS  (5)
) i0_median_y (
    .clk         (clk),
    .resetn      (resetn),
    .start_flag  (strt_median),
    .i_dval_00   (y_diff_0),
    .i_dval_01   (y_diff_1),
    .i_dval_02   (y_diff_2),
    .i_dval_03   (y_diff_3),
    .del_val     (median_valid ),
    .i_dval_valid (xy_diff_val[3:0]),
    .op_median   (op_mediany),
    .median_done (median_doney)
);


// Minimum distance calculation module
sqr_op #(
    .INP_WIDTH (17)
) i0_sqr_op (
    .clk        (clk                ),
    .resetn     (resetn             ),
    .val_in1    (distance_0[0][16:0]),
    .val_in2    (distance_0[1][16:0]), 
    .val_op     (sqr_op_distance_0  )
);

sqrt_wrap #(
    .DWIDTH (36)
) i0_sqrt_wrap (
    .clk        (clk                    ),
    .resetn     (resetn                 ),
    .valid_in   (sqr_op_distance_vld_0  ),
    .data_in    ({1'b0,sqr_op_distance_0}),
    .valid_out  (sqrt_distance_vld_0    ),
    .data_out   (sqrt_distance_0        )
);

sqr_op #(
    .INP_WIDTH (17)
) i1_sqr_op (
    .clk        (clk                ),
    .resetn     (resetn             ),
    .val_in1    (distance_1[0][16:0]),
    .val_in2    (distance_1[1][16:0]), 
    .val_op     (sqr_op_distance_1  )
);

sqrt_wrap #(
    .DWIDTH (36)
) i1_sqrt_wrap (
    .clk        (clk                    ),
    .resetn     (resetn                 ),
    .valid_in   (sqr_op_distance_vld_1  ),
    .data_in    ({1'b0,sqr_op_distance_1}),
    .valid_out  (sqrt_distance_vld_1    ),
    .data_out   (sqrt_distance_1        )
);

sqr_op #(
    .INP_WIDTH (17)
) i2_sqr_op (
    .clk        (clk                ),
    .resetn     (resetn             ),
    .val_in1    (distance_2[0][16:0]      ),
    .val_in2    (distance_2[1][16:0]      ), 
    .val_op     (sqr_op_distance_2  )
);

sqrt_wrap #(
    .DWIDTH (36)
) i2_sqrt_wrap (
    .clk        (clk                    ),
    .resetn     (resetn                 ),
    .valid_in   (sqr_op_distance_vld_2  ),
    .data_in    ({1'b0,sqr_op_distance_2}),
    .valid_out  (sqrt_distance_vld_2    ),
    .data_out   (sqrt_distance_2        )
);

sqr_op #(
    .INP_WIDTH (17)
) i3_sqr_op (
    .clk        (clk                ),
    .resetn     (resetn             ),
    .val_in1    (distance_3[0][16:0]      ),
    .val_in2    (distance_3[1][16:0]      ), 
    .val_op     (sqr_op_distance_3  )
);

sqrt_wrap #(
    .DWIDTH (36)
) i3_sqrt_wrap (
    .clk        (clk                    ),
    .resetn     (resetn                 ),
    .valid_in   (sqr_op_distance_vld_3  ),
    .data_in    ({1'b0,sqr_op_distance_3}),
    .valid_out  (sqrt_distance_vld_3    ),
    .data_out   (sqrt_distance_3        )
);

sqr_op #(
    .INP_WIDTH (17)
) i4_sqr_op (
    .clk        (clk                ),
    .resetn     (resetn             ),
    .val_in1    (distance_4[0][16:0]),
    .val_in2    (distance_4[1][16:0]), 
    .val_op     (sqr_op_distance_4  )
);

sqrt_wrap #(
    .DWIDTH (36)
) i4_sqrt_wrap (
    .clk        (clk                    ),
    .resetn     (resetn                 ),
    .valid_in   (sqr_op_distance_vld_4  ),
    .data_in    ({1'b0,sqr_op_distance_4}),
    .valid_out  (sqrt_distance_vld_4    ),
    .data_out   (sqrt_distance_4        )
);

minimum i0_minimum (
    .clk            (clk),
    .resetn         (resetn),
    .valid_in       ({sqrt_distance_vld_4,sqrt_distance_vld_3,sqrt_distance_vld_2,sqrt_distance_vld_1,sqrt_distance_vld_0}), 
   // .track_count    (track_count_prev),
    .distance_0     (sqrt_distance_0),
    .distance_1     (sqrt_distance_1),
    .distance_2     (sqrt_distance_2),
    .distance_3     (sqrt_distance_3),
    .distance_4     (sqrt_distance_4),
    .valid_out      (min_dist_vld),
    .minimum        (min_dist),
    .index          (min_dist_index)
);

endmodule
