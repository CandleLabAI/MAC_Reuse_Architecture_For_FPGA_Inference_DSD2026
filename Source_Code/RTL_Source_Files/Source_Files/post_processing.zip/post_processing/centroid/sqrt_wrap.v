// ====================================================================
// Square root calculation.
// wrapper to get the final square root value of the given number
// DWIDTH= Input DATA WIDTH
// HWIDTH= Half of input data width,also the output data width
// RWIDTH= intermediate recurrent data width=HWIDTH+2.
// single stage pipeline is to be instantiated for HWIDTH times
// ====================================================================
module sqrt_wrap #
      ( 
       parameter DWIDTH = 36
      )
      (
       input                        clk,
       input                        resetn,
       input                        valid_in,
       input [DWIDTH-1:0]           data_in,
                                    
       output                       valid_out,
       output [(DWIDTH/2)-1:0]      data_out
);

// ====================================================================
localparam HWIDTH = DWIDTH>>1;
localparam RWIDTH = HWIDTH+2;

// ====================================================================
   wire [HWIDTH-1:0] valid_array;
   wire [DWIDTH-1:0] a_array [0:HWIDTH-1];
   wire [RWIDTH-1:0] r_array [0:HWIDTH-1];
   wire [HWIDTH-1:0] q_array [0:HWIDTH-1];

   assign valid_out         = valid_array[HWIDTH-1];
   assign data_out          = q_array [HWIDTH-1];

// ====================================================================
   square_root #(.DWIDTH(36))
          sqrt_inst_0 (
            .clk         (clk),
            .resetn      (resetn),
            .valid_in    (valid_in),
            .a_in        (data_in),
            .r_in        (0),
            .q_in        (0),

            .valid_out   (valid_array[0]),
            .a_out       (a_array[0]),
            .r_out       (r_array[0]),
            .q_out       (q_array[0])
   );

// ====================================================================
genvar i;
generate
   for (i=0;i<HWIDTH-1;i=i+1) begin
   square_root #(.DWIDTH(36))
      sqrt_inst_array (
               .clk         (clk),
               .resetn      (resetn),
               .valid_in    (valid_array[i]),
               .a_in        (a_array[i]),
               .r_in        (r_array[i]),
               .q_in        (q_array[i]),

               .valid_out   (valid_array[i+1]),
               .a_out       (a_array[i+1]),
               .r_out       (r_array[i+1]),
               .q_out       (q_array[i+1])
      );
   end
endgenerate
// ====================================================================

endmodule
// ====================================================================


          
