module sqr_op#( parameter INP_WIDTH = 5'd16
)(
  input 			    			clk,
  input 			    			resetn,
  input signed [INP_WIDTH-1:0]      val_in1, 
  input signed [INP_WIDTH-1:0]      val_in2,
  output reg signed [2*INP_WIDTH:0] val_op
);

reg signed [2*INP_WIDTH-1:0] mult1,mult2;

always @(posedge clk or negedge resetn) begin
	if (!resetn) begin
	   mult1 <= 0;
       mult2 <= 0;	   
	end
	else begin
	   mult1 <= val_in1*val_in1;
       mult2 <= val_in2*val_in2;	   
	end
end
always@(posedge clk or negedge resetn)
begin
	if(!resetn) begin
		val_op <= 'sb0;		
	end
	else begin
		val_op <= mult1+mult2;
	end
end
endmodule

