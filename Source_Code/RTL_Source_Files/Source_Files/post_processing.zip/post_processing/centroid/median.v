module median #(
    parameter IP_WIDTH  = 5'd16,
    parameter NUM_CLASS = 5'd5
)
(
    input 							clk,
    input 							resetn,
    input 							start_flag,
    
    input signed  [IP_WIDTH-1:0]    i_dval_00  , 
    input signed  [IP_WIDTH-1:0]    i_dval_01  , 
    input signed  [IP_WIDTH-1:0]    i_dval_02  , 
    input signed  [IP_WIDTH-1:0]    i_dval_03  , 
    input [2:0] 		    		del_val,
    input [3:0] 		   		 	i_dval_valid,
    output reg signed [IP_WIDTH-1:0]op_median,
    output reg 						median_done
);

reg signed [IP_WIDTH-1:0] store[0:3];// Store the input det values, 0:9
reg signed [IP_WIDTH-1:0] sort_temp[0:3];
reg        [2:0]          sort_index;

reg        [2:0]          sort_valid;
reg        [1:0]          n_2;//n by 2 //3:0
reg 			  		  busy;
reg 	   [1:0] 	  	  ps;
integer 		  		  i,i10,j10;
reg 	   [3:0] 	  	  dval_valid;

localparam NON_ZERO_FIRST   = 0;
localparam SORT   	    	= 1;
localparam MEDIAN 	    	= 2;

always@(posedge clk or negedge resetn) begin
    
    if(!resetn) begin        
        store[0]<=16'sd0;
        store[1]<=16'sd0;
        store[2]<=16'sd0;
        store[3]<=16'sd0;
        sort_valid<=3'd0;
        median_done<=0;     
        busy <= 0;
        ps <= NON_ZERO_FIRST; 
        i<=0;
        i10<=0;
        j10<=1;
        n_2<=0;
        //n_2_1<=1;
        op_median<=16'sd0;
        sort_index <= 3'b0;
        sort_temp[0]<=16'sd0;
        sort_temp[1]<=16'sd0;
        sort_temp[2]<=16'sd0;
        sort_temp[3]<=16'sd0;
	end 
    else
    begin
        if(start_flag) begin
            store[0]    <= $signed(i_dval_00); 
            store[1]    <= $signed(i_dval_01);
            store[2]    <= $signed(i_dval_02);
            store[3]    <= $signed(i_dval_03);
            sort_valid  <= del_val;
            dval_valid  <= i_dval_valid;
            sort_index <= 3'b0;			
            busy <= 1;
            ps   <= NON_ZERO_FIRST;
            n_2  <=  del_val>>1;
		end
        else begin
            if(busy) begin
                if(del_val==0) begin
                    op_median <= 0;
                    busy <= 0;
                    median_done<=1;
				end
                else begin
                    case(ps)   
			NON_ZERO_FIRST : begin
				if(i<4) begin
					if(dval_valid[i]) begin
						if(i==0) begin
							sort_temp[sort_index]<=	store[0];
							end
						else if (i==1) begin
							sort_temp[sort_index]<=	store[1];
							end
						else if (i==2) begin
							sort_temp[sort_index]<=	store[2];
							end
						else begin
							sort_temp[sort_index]<=	store[3];
						end
							sort_index<=sort_index+1;
					end
					i	<= i+1;
					ps	<= NON_ZERO_FIRST;
				end
				else begin
					i<=0;
					ps<=SORT;
				end
			end
						
                        SORT: begin
                            if(i10 < sort_valid) begin
                                if(j10 < sort_valid) begin
                                    if(sort_temp[i10]>sort_temp[j10])begin
                                        sort_temp[i10] <= sort_temp[j10];
                                        sort_temp[j10] <= sort_temp[i10];
				    end//End of if
				end
                                i10<=(j10==sort_valid)?(i10+1):i10;
                                j10<=(j10==sort_valid)?(i10+2):(j10+1);
                                
                                ps <= SORT;
			    end//end of if i10
                            else
                            begin
                                ps <= MEDIAN;
                                i10 <= 0;
                                j10 <= 1;
			    end
                            
			end//End of SORT

                        MEDIAN: begin
                            if(sort_valid[0]==1)    //Odd
                            begin
                                op_median <= sort_temp[n_2];
			    end
                            else begin
                                op_median <= (sort_temp[n_2]+sort_temp[n_2-1])>>>1;
			    end
                            ps <= NON_ZERO_FIRST;
                            busy <= 0;
                            median_done<=1;                                           
			    end//End of MEDIAN

			default:ps <= NON_ZERO_FIRST;
		endcase
		end//end of else of del_val=0
	end//End of busy
	else begin
		median_done <= 0;
	end
			
	end//End of else start flag
		
	end//End of else
end//End of always


endmodule



