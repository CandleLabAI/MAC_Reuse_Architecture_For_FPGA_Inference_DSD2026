module sqrt(
  input 			clk,
  input 			resetn,
  input 			start,
  input [35:0]  	num,
  output reg 		op_valid,
  output reg [17:0]	sqrt_op
);

 //intermediate signals.
    reg [35:0] 	a;
    reg [17:0] 	q;
    reg [19:0] 	left;
    reg [19:0] 	right;
    reg [19:0] 	r;
    reg 		busy; 
    integer 	i;
    reg [1:0]	ps;

    localparam ST1 = 2'd0;
    localparam ST2 = 2'd1;
    localparam ST3 = 2'd2;

    always@(posedge clk or negedge resetn)
    begin
	if(!resetn)
		sqrt_op <= 18'd0;//16
	else
		sqrt_op <= q;
    end

    always@(posedge clk or negedge resetn)
    begin
	if(!resetn)
		begin
		    a <= 36'd0;
		    q <= 18'd0;
		    i <= 0;
		    left <= 20'd0;   //input to adder/sub
		    right <= 20'd0;  //input to adder/sub
		    r <= 20'd0;  //remainder	
		    op_valid <= 1'b0;
		    busy <= 1'b0;
		    ps <= ST1;
		end
		else
		begin
			if(start) begin
				a <= num;
				busy <= 1'b1;
				op_valid <= 1'b0;
				ps <= ST1;
				q <= 18'd0;
		    		left <= 20'd0;   //input to adder/sub
		    		right <= 20'd0;  //input to adder/sub	
		    		r <= 20'd0;  //remainder 
			end
			else begin
				if(busy)
				begin
				   if(i<18) begin//16
					case(ps)
						ST1:begin
							right <= {q,r[19],1'b1};
				    			left <= {r[17:0],a[35:34]};
							a <= {a[33:0],2'b00};    //left shift by 2 bits.
							ps <= ST2;
						end//End of ST1
						ST2: begin
							if (r[19] == 1) //add if r is negative
			        	    			r <= left + right;
			            			else    //subtract if r is positive
			        	    			r <= left - right;
							ps <= ST3;
						end//End of ST2
						ST3: begin
							q <= {q[16:0],!r[19]};  
							ps <= ST1;
							i <= i +1;
						end// End of ST3
						default: ps <= ST1;
					endcase	
		                    end//End of if    for
				    else begin
					i <= 0;
					busy <= 0;
					op_valid <= 1'b1;
				    end
				end//End of if - busy
				else
					op_valid <= 1'b0;//To ensure op_vaild is only high for one clock cycle
			end//End of else - start
		end//end of else
    end//End of always


endmodule

