module sort #(
	parameter IP_WIDTH  = 6'd32,
    parameter NUM_CLASS = 5'd5
)(
  input 					clk,
  input 					resetn,
  input 					start_flag,
  input  [IP_WIDTH-1:0]    	i_bbox_00  , // h, w, y, x
  input  [IP_WIDTH-1:0]    	i_bbox_01  ,
  input  [IP_WIDTH-1:0]    	i_bbox_02  ,
  input  [IP_WIDTH-1:0]    	i_bbox_03  ,
  input  [IP_WIDTH-1:0]    	i_bbox_04  ,
  input  [4:0]	 	     	i_bbox_bmap,//TOP_N_DET-1
  input [(5*NUM_CLASS)-1:0] i_cls_bmap,
  output [IP_WIDTH-1:0]		sorted_0,
  output [IP_WIDTH-1:0]		sorted_1,
  output [IP_WIDTH-1:0]		sorted_2,
  output [IP_WIDTH-1:0]		sorted_3,
  output [IP_WIDTH-1:0]		sorted_4,
  output reg [4:0] 			bbox_bmap_o,
  output[(5*NUM_CLASS)-1:0] cls_bmap_o,
  output reg 				sort_done
);

reg  [IP_WIDTH-1:0]		sort_temp[0:4];//Temporary sorted output is stored here
wire [NUM_CLASS-1:0] 	w_cls_bmap [0:4];//Wire to store 5 values of probability values
reg  [NUM_CLASS-1:0] 	cls_bmap_o1[0:4];//Store the probability of sorted array
reg 					busy;
reg 					ps;
integer 				i,i10,j10;
reg [2:0]				sort_index;
reg [7:0]				sort_det_val[0:4];//Sorted y1 values

assign sorted_0 = sort_temp[0];
assign sorted_1 = sort_temp[1];
assign sorted_2 = sort_temp[2];
assign sorted_3 = sort_temp[3];
assign sorted_4 = sort_temp[4];

localparam NON_ZERO_FIRST = 1'b0;
localparam SORT = 1'b1;

always@(posedge clk or negedge resetn) begin
	
	if(!resetn) begin
		sort_done<=0;
		sort_index <= 0;
		sort_temp[0]<=32'd0;
		sort_temp[1]<=32'd0;
		sort_temp[2]<=32'd0;
		sort_temp[3]<=32'd0;
		sort_temp[4]<=32'd0;
		sort_det_val[0] <= 8'd0;
		sort_det_val[1] <= 8'd0;
		sort_det_val[2] <= 8'd0;
		sort_det_val[3] <= 8'd0;
		sort_det_val[4] <= 8'd0;
		bbox_bmap_o<=5'd0;
		cls_bmap_o1[0]<= 3'd0;
		cls_bmap_o1[1]<= 3'd0;
		cls_bmap_o1[2]<= 3'd0;
		cls_bmap_o1[3]<= 3'd0;
		cls_bmap_o1[4]<= 3'd0;
		busy <= 0;
		ps <= NON_ZERO_FIRST; 
		i<=0;
		i10<=0;
		j10<=0;
	end

	else
	begin
		if(start_flag) begin
		bbox_bmap_o<=5'd0;
		cls_bmap_o1[0]<= 3'd0;
		cls_bmap_o1[1]<= 3'd0;
		cls_bmap_o1[2]<= 3'd0;
		cls_bmap_o1[3]<= 3'd0;
		cls_bmap_o1[4]<= 3'd0;
		sort_index <= 0;
		sort_det_val[0]<=32'd0;
		sort_det_val[1]<=32'd0;
		sort_det_val[2]<=32'd0;
		sort_det_val[3]<=32'd0;
		sort_det_val[4]<=32'd0;
		sort_temp[0]<=32'd0;
		sort_temp[1]<=32'd0;
		sort_temp[2]<=32'd0;
		sort_temp[3]<=32'd0;
		sort_temp[4]<=32'd0;
		busy <= 1;
		ps <= NON_ZERO_FIRST; 
		end
		else	begin
		if(busy) begin
		case(ps)	
		NON_ZERO_FIRST: begin
			if(i<5) begin
				if(i_bbox_bmap[i]) begin
					if(i==0) begin
						sort_temp[sort_index]<=	i_bbox_00;
						sort_det_val[sort_index]<=i_bbox_00[31:24];
					end
					else if (i==1) begin
						sort_temp[sort_index]<=	i_bbox_01;
						sort_det_val[sort_index]<=i_bbox_01[31:24];
					end
					else if (i==2) begin
						sort_temp[sort_index]<=	i_bbox_02;
						sort_det_val[sort_index]<=i_bbox_02[31:24];
					end
					else if (i==3) begin
						sort_temp[sort_index]<=	i_bbox_03;
						sort_det_val[sort_index]<=i_bbox_03[31:24];
					end
					else begin
						sort_temp[sort_index]<=	i_bbox_04;
						sort_det_val[sort_index]<=i_bbox_04[31:24];
					end

					//Update bbox_bmap_o
					bbox_bmap_o[sort_index]<=1'b1;
					//Update cls_bmap_o
					cls_bmap_o1[sort_index]<=w_cls_bmap[i];
					sort_index<=sort_index+1;
				end
			i<=i+1;
			ps<=NON_ZERO_FIRST;
			end
			else begin
			i<=0;
			ps<=SORT;
			end
		end//End of NZF
		SORT: begin
			if(i10<4'd5)
			begin
				if(j10<4'd5) begin
			if((sort_det_val[i10]<sort_det_val[j10])&& (sort_det_val[j10]!=0))begin
						sort_det_val[i10] <= sort_det_val[j10];
						sort_det_val[j10] <= sort_det_val[i10];
						sort_temp[i10] <= sort_temp[j10];
						sort_temp[j10] <= sort_temp[i10];
						//No need to shift bbox_bmap_o but update cls_bmap_o
						cls_bmap_o1[i10]<=cls_bmap_o1[j10];
						cls_bmap_o1[j10]<=cls_bmap_o1[i10];					
						end//End of if
					//j10<=j10+1;
				end
				i10<=(j10==4'd5)?(i10+1):i10;
				j10<=(j10==4'd5)?(i10+2):(j10+1);
				
			//i10 <= i10 +1;
			ps <= SORT;
			end//end of if i10
			else
			begin
				ps <= NON_ZERO_FIRST;
				busy <= 0;
				sort_done<=1;
				i10 <= 0;
				j10 <= 1;
			end
		  end//End of SORT
		default:ps <= NON_ZERO_FIRST;
		endcase
		end//End of busy
		else begin
		sort_done <= 0;
		end

		end//End of else start flag
	end//End of else
end//End of always

genvar j;
for (j = 0; j < 5; j = j + 1)
		assign w_cls_bmap[j] = i_cls_bmap[(j+1)*NUM_CLASS-1:j*NUM_CLASS];
assign cls_bmap_o = {cls_bmap_o1[4],cls_bmap_o1[3],cls_bmap_o1[2],cls_bmap_o1[1],cls_bmap_o1[0]};
endmodule



