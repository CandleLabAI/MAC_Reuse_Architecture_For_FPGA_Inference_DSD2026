module s_subt #( parameter INP_WIDTH = 17
)(
  input 							clk,
  input 							resetn,
  input signed      [INP_WIDTH-1:0] val1,
  input signed      [INP_WIDTH-1:0] val2,
  output reg signed [INP_WIDTH-1:0] val_op
);

reg signed [INP_WIDTH-1:0] a;
reg signed [INP_WIDTH-1:0] b;

always @(posedge clk or negedge resetn)
begin
	if(!resetn)
	begin
		a<='sb0;
		b<='sb0;
		val_op <= 'sb0;
	end
	else begin
		a<=$signed(val1);
		b<=$signed(val2);
		val_op <= $signed(val1-val2);
	end
end

endmodule
