module div #( parameter WIDTH = 16
	)(
	input 					 	  clk,
	input 					 	  resetn,
	input 					 	  start,
	input signed [WIDTH-1:0] 	  A,
	input signed [WIDTH-1:0] 	  B,
	output reg 				 	  op_valid,
	output reg signed [WIDTH-1:0] Res
	);

    reg [WIDTH-1:0] a1,b1;
    reg [WIDTH:0] 	p1;   
    reg 			busy;
    integer 		i;
    reg [1:0]		ps;
	
    localparam ST1 = 2'd0;
    localparam ST2 = 2'd1;
    localparam ST3 = 2'd2;

	always@(posedge clk or negedge resetn)
    	begin
	if(!resetn)
		begin
			a1 <= 0;
		        b1 <= 0;
		        p1 <= 0;
		    	i <= 0;
		    	op_valid <= 1'b0;
		    	busy <= 1'b0;
			ps <= ST1;
			Res <= 0;	
		end
		else
		begin
			if(start) begin
				//a1 <= A;
				a1 <= (A<0)?(~A+1'h1):(A);
				b1 <= B;
				p1 <= 0;
				busy <= 1'b1;
				op_valid <= 1'b0;
				ps <= ST1;
			end
			else begin
				if(busy)
				begin
				if(b1 == 0)//To avoid division by zero
				begin
					i <= 0;
					busy <= 0;
					op_valid <= 1'b1;
					a1 <= 0;
				end
				else begin
				if(i<WIDTH) begin
					case(ps)
					ST1:begin
						p1 <= {p1[WIDTH-2:0],a1[WIDTH-1]};
						ps <= ST2;
					end//End of ST1
					ST2: begin
						a1[WIDTH-1:1] <= a1[WIDTH-2:0];
            					p1 <= p1-b1;
						ps <= ST3;
					end//End of ST2
					ST3: begin
						if(p1[WIDTH-1] == 1)    begin
			 		                a1[0] <= 0;
				                	p1 <= p1 + b1;  
				      		end
			            		else
                					a1[0] <= 1;
						ps <= ST1;
						i <= i +1;
					end// End of ST3
					default: ps <= ST1;
					endcase
		            end//End of if    for
				    else begin
					i <= 0;
					busy <= 0;
					op_valid <= 1'b1;
					Res <= (A<0)?(~a1+1'h1):a1;
				    end
				  end//End of else - b1==0
				end//End of if - busy
				else
					op_valid <= 1'b0;//To ensure op_vaild is only high for one clock cycle
			end//End of else - start
		end//end of else
	end
endmodule
