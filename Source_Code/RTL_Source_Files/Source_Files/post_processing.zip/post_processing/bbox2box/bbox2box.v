`timescale 1ns / 100ps

module bbox2box #(parameter	TOP_N_DET	= 10,
				            NUM_CLASS	= 5,
				            X1_MIDDLE	= 60,
				            X2_MIDDLE	= 224,
				            MINX		= 5,
				            MINY		= 10)
(
input	 							    clk        , 
input        						    resetn     ,
input								    i_update   ,
input [TOP_N_DET*NUM_CLASS-1:0] 	    i_cls_bmap,
input	[TOP_N_DET-1:0]	 			    i_bbox_bmap,
input  [31:0]   			            i_bbox_00  , // h, w, y, x
input  [31:0]   			            i_bbox_01  ,
input  [31:0]   			            i_bbox_02  ,
input  [31:0]   			            i_bbox_03  ,
input  [31:0]   			            i_bbox_04  ,
input  [31:0]   			            i_bbox_05  ,
input  [31:0]   			            i_bbox_06  ,
input  [31:0]   			            i_bbox_07  ,
input  [31:0]   			            i_bbox_08  ,
input  [31:0]   			            i_bbox_09  ,
output reg [NUM_CLASS*TOP_N_DET-1:0] 	o_cls_bmap,
output reg[4:0]  			            o_box_vld  ,
output reg[31:0] 			            o_box0     , // y2, y1, x2, x1
output reg[31:0] 			            o_box1     ,
output reg[31:0] 			            o_box2     ,
output reg[31:0] 			            o_box3     ,
output reg[31:0] 			            o_box4     ,
output reg 				                o_update
);

reg	[3:0]	seq_cnt;

reg			bbox_vld;
reg	[7:0]	x;
reg	[7:0]	y;
reg	[7:0]	w;
reg	[7:0]	h;

wire [7:0]	x1;
wire [7:0]	x2;
wire [7:0]	y1;
wire [7:0]	y2;

reg			bbox_vld_u;
reg	[7:0]	x1_u;
reg	[7:0]	y1_u;
reg	[7:0]	x2_u;
reg	[7:0]	y2_u;

reg [4:0] 	cls_bmap;

reg 		flag;
wire [7:0]	xMw;
wire [7:0]	xPw;
wire [7:0]	yMh;
wire [7:0]	yPh;

assign xMw = x - {1'b0, w[7:1]};
assign xPw = x + {1'b0, w[7:1]};

assign yMh = y - {1'b0, h[7:1]};
assign yPh = y + {1'b0, h[7:1]};

assign x1 = (x < {1'b0, w[7:1]}) ? 8'b0   : xMw;
assign x2 = (xPw[7] & xPw[6] & xPw[5]) ? 8'd223 : xPw;

assign y1 = (y < {1'b0, h[7:1]}) ? 8'b0   : yMh;
assign y2 = (yPh[7] & yPh[6] & yPh[5]) ? 8'd223 : yPh;

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	seq_cnt <= 4'b0;
	flag <= 0;
	end
    else if(i_update == 1'b1) begin
	seq_cnt <= 4'd1;
	flag <= 0;
	end
    else if(seq_cnt == 4'd10) begin
	seq_cnt <= 4'd0;
	flag <= 1;
	end
    else if(seq_cnt != 4'd0) begin
	seq_cnt <= seq_cnt + 4'd1;
	flag <= 0;
	end
    else begin
	flag <= 0;
	end
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	o_update <= 1'b0;
    else if(flag == 1'd1)
	o_update <= 1'd1;
    else
	o_update <= 1'b0;
end

always @(posedge clk)
begin
    case(seq_cnt)
	4'd1   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[0], i_cls_bmap[4:0],   i_bbox_00};
	4'd2   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[1], i_cls_bmap[9:5],   i_bbox_01};
	4'd3   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[2], i_cls_bmap[14:10], i_bbox_02};
	4'd4   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[3], i_cls_bmap[19:15], i_bbox_03};
	4'd5   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[4], i_cls_bmap[24:20], i_bbox_04};
	4'd6   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[5], 5'b0,              i_bbox_05};
	4'd7   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[6], 5'b0,              i_bbox_06};
	4'd8   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[7], 5'b0,              i_bbox_07};
	4'd9   : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[8], 5'b0,              i_bbox_08};
	4'd10  : {bbox_vld, cls_bmap, h,w,y,x} <= {i_bbox_bmap[9], 5'b0,              i_bbox_09};
	default: {bbox_vld, cls_bmap, h,w,y,x} <= 33'b0;
    endcase
end

always@(x1,x2,y1,y2) begin
	if(((x2 - x1)/2 + x1 < X1_MIDDLE) || ((x2 - x1)/2 + x1 > X2_MIDDLE) || (x2-x1<MINX || y2-y1<MINY))	begin
			x2_u = 0;
			x1_u = 0;
			y2_u = 0;
			y1_u = 0;
			bbox_vld_u = 0;
	end
	else begin
			x2_u = x2;
			x1_u = x1;
			y2_u = y2;
			y1_u = y1;
			bbox_vld_u = bbox_vld;
		end
end

always @(posedge clk or negedge resetn) begin
   if(resetn == 1'b0) begin
	  o_box_vld  <= 5'b0;
	  o_cls_bmap <= {NUM_CLASS*TOP_N_DET{1'b0}};
	  o_box4     <= 32'h0;
	  o_box3     <= 32'h0;
	  o_box2     <= 32'h0;
	  o_box1     <= 32'h0;
	  o_box0     <= 32'h0;
	end
    else begin
	  if(i_update == 1'b1) begin
	    o_box_vld  <= 5'b0;
	    o_cls_bmap <= {NUM_CLASS*TOP_N_DET{1'b0}};
		o_box4     <= 32'h0;
		o_box3     <= 32'h0;
		o_box2     <= 32'h0;
		o_box1     <= 32'h0;
		o_box0     <= 32'h0;
	  end
      else if(bbox_vld_u) begin
		 
	    if(!o_box_vld[0]) begin
 	      o_box0          <= {y2_u,y1_u,x2_u,x1_u};
		  o_cls_bmap[4:0] <= cls_bmap;
		  o_box_vld[0]    <= 1'b1;
		end
	    else if (!o_box_vld[1]) begin 
		  o_box1          <= {y2_u,y1_u,x2_u,x1_u};
		  o_cls_bmap[9:5] <= cls_bmap;
		  o_box_vld[1]    <= 1'b1;
		end
	    else if (!o_box_vld[2]) begin 
		  o_box2            <= {y2_u,y1_u,x2_u,x1_u};
          o_cls_bmap[14:10] <= cls_bmap;
		  o_box_vld[2]      <= 1'b1;		  
		end
	    else if (!o_box_vld[3]) begin 
		  o_box3            <= {y2_u,y1_u,x2_u,x1_u};
		  o_cls_bmap[19:15] <= cls_bmap;
		  o_box_vld[3]      <= 1'b1;
		end
	    else if (!o_box_vld[4]) begin
		  o_box4            <= {y2_u,y1_u,x2_u,x1_u};
		  o_cls_bmap[24:20] <= cls_bmap;
		  o_box_vld[4]      <= 1'b1;
		end
	  end
	end
end

endmodule
