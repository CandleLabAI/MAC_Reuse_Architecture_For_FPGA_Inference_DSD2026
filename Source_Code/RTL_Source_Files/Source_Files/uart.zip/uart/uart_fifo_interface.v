
module uart_fifo_interface(
    input                sys_clk,
	input			  	 resetn,
	input 				 vsync_uart,
	//input 				 href_uart,
	input	[4:0]	count1,
	input	[4:0]	count2,
	input   [4:0]   count3,
	//input 		[7:0]	 fifo_ip_data,
	//input 				 pixel_valid,
    //input       [15:0]   i_tx_datavalue,
	//input 		[7:0]	 uart_pixel_x_out,
	//input 		[7:0]	 uart_pixel_y_out,	
	//input                i_tx_valid,
    output reg           o_tx_serdata
    );
    
   //wire trigger_readout;
	//reg trigger_readout_test;
	//localparam pixel_x_MAX  = 159;
	//localparam pixel_y_MAX  = 19;
	
    localparam TX_IDLE      = 3'b000;
    localparam TX_START_BIT = 3'b001;
    localparam TX_DATA_BITS = 3'b010;
    localparam TX_STOP_BIT  = 3'b011;

    parameter CLOCKS_PER_BIT=417;

     reg [15:0]          tx_count_clk;
     reg [3:0]           tx_bit_index; //8 bits total
     reg [2:0]           tx_state;
     reg [7:0]           tx_data;
     reg i_tx_dvalid;	 
	 wire [15:0] rd_data_o ;  
	 
	 
	 
	 
	/* reg [15:0]	 uart_pixel_x_out;
	 reg [15:0]	 uart_pixel_y_out;
	 reg de_d;
	 reg vs_l,o_vs_d2;
always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	vs_l     <= 1'b0;
	o_vs_d2  <= 1'b0;
	end else begin
	vs_l     <= vsync_uart;
	o_vs_d2  <= vs_l;
	end
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	de_d <= 1'b0;
    else 
	de_d <= pixel_valid;
end

always @(posedge sys_clk or negedge resetn)
begin
    if(resetn == 1'b0)
	uart_pixel_x_out <= 16'b0;
    else 
	uart_pixel_x_out <= pixel_valid ? (uart_pixel_x_out + 16'd1) : 16'b0;
end

always @(posedge sys_clk or negedge resetn)
begin
    if(resetn == 1'b0)
	uart_pixel_y_out <= 16'b0;
    else if(vsync_uart & ~o_vs_d2)
	uart_pixel_y_out <= 16'b0;
    else if({de_d, pixel_valid} == 2'b10)
	uart_pixel_y_out <= lcnt + 16'd1;
end
*/
//================================================================================
//FIFO Module Block
    //================================================================================
wire full_o, empty_o;
reg rst_i, wr_en_i, rd_en_i,uart_active;
//reg [11:0] wr_data_i;

FIFO_F1 FIFO_Instance(.clk_i(sys_clk), 
        .rst_i(rst_i), 
        .wr_en_i(wr_en_i), 
        .rd_en_i(rd_en_i), 
        .wr_data_i(fifo_write_in), 
        .full_o(full_o), 
        .empty_o(empty_o),          
        .rd_data_o(rd_data_o)) ;

// ======================uart_control logic =====================================
localparam MEM_IDLE = 3'b000;
localparam MEM_WRITE = 3'b001;
localparam READ_OUT = 3'b010;
localparam UART_LOWER_NIBBLE = 3'b011;
localparam WAIT_DELAY1 = 3'b100;
localparam WAIT_DELAY2 = 3'b101;
localparam UART_UPPER_NIBBLE = 3'b110;
localparam WAIT_DELAY3 = 3'b111;

reg [2:0] MEM_STATE;
reg [11:0] write_count_value;		
reg [7:0] fifo_read_out;
reg [15:0] fifo_write_in;
reg [2:0] sub_frame_flag = 3'b000;
reg [2:0] sub_frame;

/*always @ (posedge sys_clk) begin
	if(uart_pixel_y_out >= 0 && uart_pixel_y_out < 20)
		sub_frame = 3'd1;
	else if (uart_pixel_y_out >= 20 && uart_pixel_y_out < 40)
		sub_frame = 3'd2;
	else if (uart_pixel_y_out >= 40 && uart_pixel_y_out < 60)
		sub_frame = 3'd3;
	else if (uart_pixel_y_out >= 60 && uart_pixel_y_out < 80)
		sub_frame = 3'd4;
	else if (uart_pixel_y_out >= 80 && uart_pixel_y_out < 100)
		sub_frame = 3'd5;
	else if (uart_pixel_y_out >= 100 && uart_pixel_y_out < 120)
		sub_frame = 3'd6;
	else 
		sub_frame = 3'd0;
end		
*/

always@(posedge sys_clk)
begin
case(MEM_STATE)
MEM_IDLE: begin
			rst_i = 1;
			write_count_value <= 0;
			rd_en_i <= 0;
			wr_en_i <= 0;
			i_tx_dvalid <= 0;
			//uart_active <= 0;
			if(vsync_uart) begin				
				MEM_STATE <= MEM_WRITE;
				sub_frame_flag = sub_frame_flag + 3'd1;
				end
			else 
				MEM_STATE <= MEM_IDLE;
	       end		   
MEM_WRITE: begin
				rst_i = 0;
				//uart_active <= 0; 
				if(write_count_value < 12'd9) begin//FIFO length
					if(write_count_value==12'd0)
							fifo_write_in <= 16'h40;//Char = @
					else if(write_count_value==12'd1)
							fifo_write_in <= {11'h0,count1};//Object count 1
					else if(write_count_value==12'd2)
							fifo_write_in <= 16'h40;//Char = @
					else if(write_count_value==12'd3)
							fifo_write_in <= 16'h23;//Char = #
					else if(write_count_value==12'd4)
							fifo_write_in <= {11'h0,count2};	//Object count 2
					else if(write_count_value==12'd5)
							fifo_write_in <= 16'h23;//Char = #
					else if(write_count_value==12'd6)
							fifo_write_in <= 16'h26;//Char = &
					else if(write_count_value==12'd7)
							fifo_write_in <= {11'h0,count3};//Object count 3
					else if(write_count_value==12'd8)
							fifo_write_in <= 16'h26;//Char = &
					
					write_count_value <= write_count_value + 1;
					wr_en_i <= 1; 
					MEM_STATE<= MEM_WRITE; 
					
				end
				else begin
					wr_en_i <= 0;
					i_tx_dvalid <= 1;
					MEM_STATE <= READ_OUT;
				end
					
				/*if(sub_frame == sub_frame_flag)
					if(!pixel_valid) 
							if(write_count_value < 12'd3200) begin
								 fifo_write_in <= i_tx_datavalue;
								 write_count_value <= write_count_value + 1;
								 wr_en_i <= 1; 
								 MEM_STATE<= MEM_WRITE; 
								 end
							else begin
								   wr_en_i <= 0;
								   i_tx_dvalid <= 1;
								   MEM_STATE <= READ_OUT;
								end
					else begin
						wr_en_i <= 0;
						MEM_STATE <= MEM_WRITE;
						end
				else MEM_STATE <= MEM_WRITE;*/
			end
READ_OUT: begin
			if(write_count_value == 0) begin
				rd_en_i <= 0;
				i_tx_dvalid <= 0;
				MEM_STATE <= MEM_IDLE;
			end
			else begin
				rd_en_i <= 1;
				i_tx_dvalid <= 1;
				write_count_value = write_count_value - 1;
				MEM_STATE <= UART_LOWER_NIBBLE;
			end
		end
UART_LOWER_NIBBLE: begin
			rd_en_i <= 0;
			i_tx_dvalid <= 1;
			fifo_read_out <= rd_data_o[7:0];
			if(uart_active == 0)	begin
					i_tx_dvalid <= 0;
					MEM_STATE <= WAIT_DELAY1;					
				end
			else 
				MEM_STATE <= UART_LOWER_NIBBLE;				
			end
			
WAIT_DELAY1 : begin
					i_tx_dvalid <= 1;
					MEM_STATE <= WAIT_DELAY2;
					end
WAIT_DELAY2: MEM_STATE <= UART_UPPER_NIBBLE;

UART_UPPER_NIBBLE: begin
			i_tx_dvalid <= 1;
			rd_en_i <= 0;
			fifo_read_out <= rd_data_o[15:8];
			if(uart_active == 0) begin
					i_tx_dvalid <= 0;
					MEM_STATE <= WAIT_DELAY3;					
				end
			else 
				MEM_STATE <= UART_UPPER_NIBBLE;				
			end
			
WAIT_DELAY3 : begin
					i_tx_dvalid <= 1;
					MEM_STATE <= READ_OUT;
					end		

			

		
	
default:   MEM_STATE <= MEM_IDLE;			
endcase
end
	
	//===================================UART _transmitter ============================	
	
    // Transmitter State machine
    always @ (posedge sys_clk) begin
        case (tx_state)
            TX_IDLE: begin
                tx_bit_index    <= 0;
                o_tx_serdata    <= 1;
                tx_count_clk    <= 0;
				uart_active <= 0;
                if (i_tx_dvalid == 1) begin
                    o_tx_serdata    <= 0;
					uart_active <= 1;
                    tx_state        <= TX_START_BIT;
                end else begin
                    tx_state        <= TX_IDLE;
                end
            end 
            TX_START_BIT: begin
				o_tx_serdata    <= 0;
				uart_active <= 1;
                if (tx_count_clk < CLOCKS_PER_BIT-1) begin
                    tx_data         <= fifo_read_out;
                    tx_state        <= TX_START_BIT;
                    tx_count_clk    <= tx_count_clk + 1;
                end else begin
                    o_tx_serdata    <= tx_data[tx_bit_index];
                    tx_bit_index    <= tx_bit_index + 1;
                    tx_state        <= TX_DATA_BITS;
                    tx_count_clk    <= 0;
                end
            end
            TX_DATA_BITS: begin
                if (tx_bit_index <= 7) begin
                    
                    if (tx_count_clk < CLOCKS_PER_BIT-1) begin
                        tx_count_clk    <= tx_count_clk + 1;
                    end else begin
                        o_tx_serdata    <= tx_data[tx_bit_index] ;
                        tx_count_clk    <= 0;
                        tx_bit_index       <= tx_bit_index + 1;
                    end
                    tx_state        <= TX_DATA_BITS;
                end else begin
                    if (tx_count_clk < CLOCKS_PER_BIT-1) begin
                        tx_count_clk    <= tx_count_clk + 1;
                    end else begin
                        o_tx_serdata    <= 1;       // Stop bit is 1
                        tx_count_clk    <= 0;
                        // tx_bit_index    <= tx_bit_index + 1;
                        tx_state        <= TX_STOP_BIT;
                    end
                end
            end
            //--------------------------STOPBIT GENERATWS ONLY ONE
            TX_STOP_BIT: begin
                if (tx_count_clk < (CLOCKS_PER_BIT-1)) begin
                    o_tx_serdata   <= 1;
                    tx_state       <= TX_STOP_BIT;
                    tx_count_clk   <= tx_count_clk + 1;
                end else begin 
					//i_tx_dvalid <= 0;
					uart_active  <= 0;
                    tx_state       <= TX_IDLE;					
                end
            end
  
            default: begin
                tx_state       <= TX_IDLE;
                tx_bit_index    <= 0;
				uart_active <= 0;
                o_tx_serdata    <= 1;
                tx_count_clk    <= 0;
            end
        endcase
    end
endmodule