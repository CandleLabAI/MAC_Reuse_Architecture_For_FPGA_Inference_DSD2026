
module rx_dphy_s (pll_lock_i, sync_clk_i, sync_rst_i, ready_o, clk_byte_o,
    clk_byte_hs_o, clk_lp_ctrl_i, clk_byte_fr_i, reset_n_i, reset_lp_n_i,
    reset_byte_n_i, reset_byte_fr_n_i, clk_p_io, clk_n_io, d_p_io, d_n_io,
    lp_d_rx_p_o, lp_d_rx_n_o, bd_o, cd_clk_o, cd_d0_o, hs_d_en_o, hs_sync_o,
    lp_hs_state_clk_o, lp_hs_state_d_o, term_clk_en_o, term_d_en_o,
    payload_en_o, payload_o, dt_o, vc_o, wc_o, ecc_o, ref_dt_i, tx_rdy_i,
    sp_en_o, lp_en_o, lp_av_en_o)/* synthesis syn_black_box syn_declare_black_box=1 */;
    input  pll_lock_i;
    input  sync_clk_i;
    input  sync_rst_i;
    output  ready_o;
    output  clk_byte_o;
    output  clk_byte_hs_o;
    input  clk_lp_ctrl_i;
    input  clk_byte_fr_i;
    input  reset_n_i;
    input  reset_lp_n_i;
    input  reset_byte_n_i;
    input  reset_byte_fr_n_i;
    inout  clk_p_io;
    inout  clk_n_io;
    inout  [0:0]  d_p_io;
    inout  [0:0]  d_n_io;
    output  [0:0]  lp_d_rx_p_o;
    output  [0:0]  lp_d_rx_n_o;
    output  [7:0]  bd_o;
    output  cd_clk_o;
    output  cd_d0_o;
    output  hs_d_en_o;
    output  hs_sync_o;
    output  [1:0]  lp_hs_state_clk_o;
    output  [1:0]  lp_hs_state_d_o;
    output  term_clk_en_o;
    output  [0:0]  term_d_en_o;
    output  payload_en_o;
    output  [7:0]  payload_o;
    output  [5:0]  dt_o;
    output  [1:0]  vc_o;
    output  [15:0]  wc_o;
    output  [7:0]  ecc_o;
    input  [5:0]  ref_dt_i;
    input  tx_rdy_i;
    output  sp_en_o;
    output  lp_en_o;
    output  lp_av_en_o;
endmodule