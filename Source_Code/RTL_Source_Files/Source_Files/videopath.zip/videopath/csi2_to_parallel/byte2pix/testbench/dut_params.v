localparam FAMILY = "LFCPNX";
localparam RX_TYPE = "CSI-2";
localparam DSI_MODE = "NONBURST_PULSES";
localparam NUM_RX_LANE = 1;
localparam RX_GEAR = 8;
localparam BYTE_CLK_FREQ = 24.000000;
localparam AXI_SLAVE = "OFF";
localparam NUM_TX_CH_INPUT = 1;
localparam NUM_TX_CH = 1;
localparam DT = 6'h2A;
localparam PD_BUS_WIDTH = 8;
localparam CTRL_POL = "POSITIVE";
localparam VSA = 5;
localparam HSA = 8;
localparam PIX_CLK_FREQ = 24.000000;
localparam AXI_MASTER = "OFF";
localparam THRESHOLD = 4;
localparam PIX_FIFO_DEPTH = 16;
localparam PIX_FIFO_ADDR_WIDTH = 4;
localparam WORD_CNT = 640;
localparam DEBUG_EN = 1;
localparam NUM_PIXELS = 1;
localparam FRAMES_CNT = 1;
localparam LINES_CNT = 1;
`define LFCPNX
`define jd5d00
`define LFCPNX-100
