    rom_hm_0360_cam_out u_rom_hm_0360_cam_out(.rd_clk_i(rd_clk_i),
        .rst_i(rst_i),
        .rd_en_i(rd_en_i),
        .rd_clk_en_i(rd_clk_en_i),
        .rd_addr_i(rd_addr_i),
        .rd_data_o(rd_data_o));
