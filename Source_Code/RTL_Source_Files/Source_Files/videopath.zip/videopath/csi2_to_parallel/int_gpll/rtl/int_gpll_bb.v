
module int_gpll (clki_i, rstn_i, clkop_o, lock_o)/* synthesis syn_black_box syn_declare_black_box=1 */;
    input  clki_i;
    input  rstn_i;
    output  clkop_o;
    output  lock_o;
endmodule