
module csi2_to_parallel #(
	parameter RX_DPHY 			= "HARD",
	parameter RX_CLK_MODE 		= "HS_ONLY",
	parameter NUM_RX_LANE 		= 4,
	parameter RX_GEAR 			= 8,
	parameter RX_PD_BUS_WIDTH 	= 10,
	parameter LB_DEPTH 			= 2048,
	parameter TX_PD_BUS_WIDTH 	= 24,
	parameter V_TOTAL_LINE 		= 1080
) (
///// debug ports
	output							hs_sync_o,
	output							sp_en_o,
	output							lp_av_en_o,
	output							payload_en_o,
    output                          ready_o,
	input 							reset_n_i,
	inout 							clk_p_i,
	inout 							clk_n_i,
	inout 							d_p_io,
	inout 							d_n_io,
	input                           sync_clk_i,
    input                           sync_rst_i,
	input							pd_dphy_i,
	input							tx_rdy_i,
    input                           clk_lp_ctrl_i,	
    input                           reset_lp_n_i,	
	input							clk_byte_fr_i,
	input							reset_byte_fr_n_sync_i,
	input							reset_byte_n_sync_i,
	output							clk_byte_o,
	output							clk_byte_hs_o,
	input [5:0]						ref_dt_i,

	input							clk_pixel_i,
	input							reset_pixel_n_sync_i,

	input [5:0]						vfp_i,
	input [5:0]						vs_length_i,
	input [7:0]						hfp_i,
	input [7:0]						hs_length_i,
	input [1:0]						bayer_pattern_i,
	input [5:0]						left_trim_i,
	input [11:0]					h_tx_pel_i,
	input [5:0]						top_trim_i,
	input [11:0]					v_tx_line_i,

	output 							rgb_vs_o,
	output 							rgb_hs_o,
	output 							rgb_de_o,
	output [23:0]					rgb_pd_o
);

wire 							payload_en, sp_en, lp_en, lp_av_en;
wire 							w_payload_en;
reg  							r_payload_en_mask_lp;
wire [NUM_RX_LANE*RX_GEAR-1:0]	payload;
wire [5:0]						dt;
wire [15:0]						wc;

wire 							payload_en_d, sp_en_d, lp_av_en_d;
wire [NUM_RX_LANE*RX_GEAR-1:0]	payload_d;
wire [5:0]						dt_d;
wire [15:0]						wc_d;

wire 							raw_fv, raw_lv;
wire [RX_PD_BUS_WIDTH-1:0]		raw_pd;
wire 							lv_to_vs_cnt;
reg [4:0] 						raw_fv_d;

///// debug
assign sp_en_o 		= sp_en;
assign lp_av_en_o 	= lp_av_en;
assign payload_en_o = w_payload_en;
assign rgb_hs_o		= 1'b0;
assign rgb_de_o 	= raw_lv;
assign rgb_pd_o 	= {16'b0,raw_pd};
assign rgb_vs_o 	= raw_fv; 
assign w_payload_en = (~r_payload_en_mask_lp) & payload_en;

always @(posedge clk_pixel_i or negedge reset_n_i) 
begin
	if (~reset_n_i)
	begin
		raw_fv_d <= 2'd0;
	end
	else
	begin
		raw_fv_d <= {raw_fv_d[3:0],raw_fv};
	end
end

always @(posedge clk_byte_fr_i or negedge reset_byte_fr_n_sync_i) begin
  if (~reset_byte_fr_n_sync_i)
  begin
    r_payload_en_mask_lp <= 1;
  end
  else if (lp_en)
  begin
    r_payload_en_mask_lp <= ~lp_av_en;
  end
end


/////////////////////////////////////////////////////////////////////////////
///// DPHY RX module instantiation                                      /////
/////////////////////////////////////////////////////////////////////////////
		rx_dphy_s rx_dphy (
	        .cd_d0_o				(        ),
	        .cd_clk_o				(        ),
	        .hs_d_en_o				(        ),
	        .term_clk_en_o			(),
	        .term_d_en_o			(),
	        .lp_hs_state_clk_o		(),
	        .lp_hs_state_d_o		(),
		    .clk_p_io				(clk_p_i),
			.clk_n_io				(clk_n_i),
			.d_p_io					(d_p_io),
			.d_n_io					(d_n_io),
			.pll_lock_i				(1'b1), 	// tie to 1 if no pll is used? which PLL?
			.ready_o				(ready_o),			// need to monitor???
			//.pd_dphy_i			(~reset_n_i),
			.sync_clk_i				(sync_clk_i),
			.sync_rst_i				(sync_rst_i),
			.clk_byte_fr_i			(clk_byte_fr_i),
			.reset_byte_fr_n_i		(reset_byte_fr_n_sync_i),
			.reset_byte_n_i			(reset_byte_fr_n_sync_i),
            `ifdef RX_CLK_MODE_HS_LP
			.clk_lp_ctrl_i			(clk_lp_ctrl_i),
			.reset_lp_n_i			(reset_lp_n_i),
            `endif
			.reset_n_i				(reset_n_i),
// Outputs
			.clk_byte_o				(clk_byte_o),
			.clk_byte_hs_o			(clk_byte_hs_o),

			.lp_d_rx_p_o			(),
			.lp_d_rx_n_o			(),
			.ref_dt_i				(ref_dt_i),
			.bd_o					(),
			.hs_sync_o				(hs_sync_o),
			.payload_en_o			(payload_en),
			.payload_o				(payload),
			.sp_en_o				(sp_en),
			.lp_en_o				(lp_en),
			.lp_av_en_o				(lp_av_en),
			.dt_o					(dt),
			.vc_o					(),
			.wc_o					(wc),
			.ecc_o					(),
			.tx_rdy_i				(1'b1)
		);


/////////////////////////////////////////////////////////////////////////////
///// Byte2Pixel module instantiation                                   /////
/////////////////////////////////////////////////////////////////////////////
byte2pix  b2p (
	.clk_byte_i			(clk_byte_fr_i),
    	.write_cycle_o  (),
    	.mem_we_o       (), 
    	.mem_re_o       (), 
    	.read_cycle_o   (), 
    	.fifo_empty_o   (), 
    	.fifo_full_o    (),
	.reset_byte_n_i		(reset_byte_fr_n_sync_i),
	.clk_pixel_i		(clk_pixel_i),
	.reset_pixel_n_i	(reset_pixel_n_sync_i),
	.sp_en_i			(sp_en),
	.lp_av_en_i			(lp_av_en),
	.dt_i				(dt),
	.wc_i				(wc),
	.payload_i			(payload),
	.payload_en_i		(w_payload_en),
	.fv_o				(raw_fv),
	.lv_o				(raw_lv),
	.pd_o				(raw_pd),
	.p_odd_o			()
);

endmodule 
