
module int_osc (hf_out_en_i, 
        hf_clk_out_o) ;
    input hf_out_en_i ; 
    output hf_clk_out_o ; 
    int_osc_ipgen_lscc_osc #(.HF_OSC_EN("ENABLED"),
            .HF_CLK_DIV_DEC(7),
            .HF_CLK_DIV("6"),
            .HF_CFG_EN("ENABLED"),
            .LF_OUTPUT_EN("DISABLED"),
            .SEDCLK_EN(0),
            .HF_SED_SEC_DIV_DEC(2),
            .HF_SED_SEC_DIV("1"),
            .LMMI_CLK_EN("DISABLED"),
            .FAMILY("LFCPNX")) lscc_osc_inst (.hf_out_en_i(hf_out_en_i), 
                .sedc_clk_en_i(1'b1), 
                .sedc_rst_n_i(1'b1), 
                .lmmi_clk_i(1'b0), 
                .lmmi_reset_i(1'b0), 
                .hf_clk_out_o(hf_clk_out_o), 
                .lf_clk_out_o(), 
                .sedc_rst_o(), 
                .cfg_clk_o(), 
                .lmmi_clk_o(), 
                .lmmi_resetn_o()) ; 
endmodule



// =============================================================================
// >>>>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// -----------------------------------------------------------------------------
//   Copyright (c) 2018 by Lattice Semiconductor Corporation
//   ALL RIGHTS RESERVED 
// -----------------------------------------------------------------------------
//
//   Permission:
//
//      Lattice SG Pte. Ltd. grants permission to use this code
//      pursuant to the terms of the Lattice Reference Design License Agreement. 
//
//
//   Disclaimer:
//
//      This VHDL or Verilog source code is intended as a design reference
//      which illustrates how these types of functions can be implemented.
//      It is the user's responsibility to verify their design for
//      consistency and functionality through the use of formal
//      verification methods.  Lattice provides no warranty
//      regarding the use or functionality of this code.
//
// -----------------------------------------------------------------------------
//
//                  Lattice SG Pte. Ltd.
//                  101 Thomson Road, United Square #07-02 
//                  Singapore 307591
//
//
//                  TEL: 1-800-Lattice (USA and Canada)
//                       +65-6631-2000 (Singapore)
//                       +1-503-268-8001 (other locations)
//
//                  web: http://www.latticesemi.com/
//                  email: techsupport@latticesemi.com
//
// -----------------------------------------------------------------------------
//
// =============================================================================
//                         FILE DETAILS         
// Project               : 
// File                  : lscc_osc.v
// Title                 : 
// Dependencies          : OSC module
// Description           : 
// =============================================================================
//                        REVISION HISTORY
// Version               : 1.0.0.
// Author(s)             : 
// Mod. Date             : 
// Changes Made          : Initial release.
// =============================================================================
module int_osc_ipgen_lscc_osc #(parameter LF_OUTPUT_EN = "DISABLED", 
        parameter HF_CLK_DIV_DEC = 2, 
        parameter HF_CLK_DIV = "1", 
        parameter HF_OSC_EN = "ENABLED", 
        parameter HF_CFG_EN = "ENABLED", 
        parameter SEDCLK_EN = 0, 
        parameter HF_SED_SEC_DIV_DEC = 2, 
        parameter HF_SED_SEC_DIV = "1", 
        parameter LMMI_CLK_EN = "DISABLED", 
        parameter FAMILY = "LIFCL") (
    // -----------------------------------------------------------------------------
    // Module Parameters
    // -----------------------------------------------------------------------------
    // -----------------------------------------------------------------------------
    // Input/Output Ports
    // -----------------------------------------------------------------------------
    input hf_out_en_i, 
    input sedc_clk_en_i, 
    input sedc_rst_n_i, 
    input lmmi_clk_i, 
    input lmmi_reset_i, 
    output hf_clk_out_o, 
    output lf_clk_out_o, 
    output cfg_clk_o, 
    output sedc_rst_o, 
    output lmmi_clk_o, 
    output lmmi_resetn_o) ;
    wire sed_sec_out_w ; 
    wire cfg_clk_w ; 
    // ---------------------------------------
    // OSC Module Instantiation
    // --------------------------------------- 
    OSCA #(.HF_CLK_DIV(HF_CLK_DIV),
            .HF_SED_SEC_DIV(HF_SED_SEC_DIV),
            .HF_OSC_EN(HF_OSC_EN),
            .LF_OUTPUT_EN(LF_OUTPUT_EN)) u_OSC (//Inputs                   
            .HFOUTEN(hf_out_en_i), 
                .HFSDSCEN(sedc_clk_en_i), 
                //Outputs                  
            .HFCLKOUT(hf_clk_out_o), 
                .LFCLKOUT(lf_clk_out_o), 
                .HFCLKCFG(cfg_clk_w), 
                .HFSDCOUT(sed_sec_out_w)) ; 
    generate
        if (((SEDCLK_EN != 0) || (LMMI_CLK_EN == "ENABLED"))) 
            begin : u_CFG_CLKRST_CORE
                CONFIG_CLKRST_CORE u_cfg_clkrst_core (//Inputs
                        .JTAG_LRST_N(1'b1), 
                            .LMMI_CLK(lmmi_clk_i), 
                            .LMMI_LRST_N(lmmi_reset_i), 
                            .MBISTCLK(1'b0), 
                            .OSCCLK(cfg_clk_w), 
                            .SEDC_CLK(sed_sec_out_w), 
                            .SEDC_LRST_N(sedc_rst_n_i), 
                            .WDT_LRST_N(1'b1), 
                            //Outputs
                        .HSE_CLK(), 
                            .LMMI_CLK_O(lmmi_clk_o), 
                            .LMMI_RST(lmmi_resetn_o), 
                            .SEDC_RST(sedc_rst_o), 
                            .CFG_CLK(cfg_clk_o), 
                            .SMCLK_RST(), 
                            .WDT_CLK(), 
                            .WDT_RST()) ; 
            end
    endgenerate
endmodule


