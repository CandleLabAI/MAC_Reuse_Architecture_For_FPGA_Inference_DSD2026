
module int_osc (hf_out_en_i, hf_clk_out_o)/* synthesis syn_black_box syn_declare_black_box=1 */;
    input  hf_out_en_i;
    output  hf_clk_out_o;
endmodule