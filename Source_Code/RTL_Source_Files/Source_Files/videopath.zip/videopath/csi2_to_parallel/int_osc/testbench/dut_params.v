localparam HF_OSC_EN = "ENABLED";
localparam HF_CLK_DIV_DEC = 7;
localparam HF_CLK_DIV = "6";
localparam HF_CFG_EN = "ENABLED";
localparam LF_OUTPUT_EN = "DISABLED";
localparam SEDCLK_EN = 0;
localparam HF_SED_SEC_DIV_DEC = 2;
localparam HF_SED_SEC_DIV = "1";
localparam LMMI_CLK_EN = "DISABLED";
localparam FAMILY = "LFCPNX";
`define LFCPNX
`define jd5d00
`define LFCPNX-100
