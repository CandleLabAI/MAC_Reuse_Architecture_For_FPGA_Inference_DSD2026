

// 224x224 version

module crop_downscale_front_224x224 # (parameter idw     = 3,
                                       BYTE_MODE         = "UNSIGNED",
                                       HYPERRAM_BASEADDR = 32'h400000, 
                                       PIC_HEIGHT        = 224,
                                       PIC_WIDTH         = 224,
                                       INF_MULT_FAC      = 15907,
                                       EN_INF_TIME       = 1'b0,
									   WIDTH	         = 16
                                       )
( 
input		   	   pclk       , // pixel clock
input              clk        , // data out clock
input		       resetn     ,
input              i_rd_rdy   , // clk, read frame data ready (idle wait state)
output reg         o_rd_done  ,
input		       i_hs       , // pclk
input		       i_vs       , // pclk
input		       i_de       , // pclk
input	[7:0]	   i_r        , // pclk
input	[7:0]	   i_g        , // pclk
input	[7:0]	   i_b        , // pclk
output reg	       o_hs_d2    , // pclk
output reg	       o_vs_d2    , // pclk
output reg	       o_de_d2    , // pclk
output reg[7:0]    o_r_d2     , // pclk
output reg[7:0]    o_g_d2     , // pclk
output reg[7:0]    o_b_d2     , // pclk
output reg         o_mask     , // pclk

output wire [31:0] ind_inf_time_hex,
output wire [31:0] avg_inf_time_hex,
output wire [15:0] inf_time_ms,
output wire [15:0] inf_time_ind_ms,
output wire [WIDTH-1:0] fps_val,

// AXI4 Master port
// Write Address Channel
input             ACLK     ,
input             ARESETn  ,
output    [idw:0] AWID     ,
output reg [31:0] AWADDR   ,
output      [3:0] AWREGION ,
output reg  [7:0] AWLEN    ,
output      [2:0] AWSIZE   ,
output      [1:0] AWBURST  ,
output            AWLOCK   ,
output      [3:0] AWCACHE  ,
output      [2:0] AWPROT   ,
output      [3:0] AWQOS    ,
output  reg       AWVALID  ,
input             AWREADY  ,
// Write Channel
output    [idw:0] WID      ,
output reg [63:0] WDATA    ,
output      [7:0] WSTRB    ,
output  reg       WLAST    ,
output  reg       WVALID   ,
input             WREADY   ,
// Write Response Channel
input     [idw:0] BID      ,
input       [1:0] BRESP    ,
input             BVALID   ,
output            BREADY 
);

// parameters {{{

parameter [15:0] sb_l = 16'd96;
parameter [15:0] sb_r = 16'd544; //(96+448)
parameter [15:0] vb_u = 16'd16; 
parameter [15:0] vb_b = 16'd464; //(16+448)


parameter [15:0] sz_u = 16'd464;
parameter [15:0] sz_b = 16'd16; 


parameter [15:0] block_size = 16'd2;
parameter [15:0] out_width  = 16'd224; // 224
// parameters }}}

// counters & masks {{{
reg	[15:0]	pcnt; // pixel counter
reg	[15:0]	lcnt; // line counter
reg	[7:0]	r_l;
reg	[7:0]	g_l;
reg	[7:0]	b_l;
reg		    hs_l;
reg		    vs_l;
reg		    de_l;
reg 		vs_d3;
reg		    vs_l_clk;
reg	[7:0]	bpcnt; // block pixel counter
reg	[7:0]	blcnt; // block line counter
wire [7:0]	bpcnt_p1;
wire [7:0]	blcnt_p1;
wire		bp_last;
wire		bl_last;
reg	[7:0]	rbcnt; // read block counter (block index)
wire [7:0]	wbcnt; // write block counter (block index)
reg	[15:0]	wr_pix_cnt;
reg		    de_d;
reg		    hmask;
reg		    vmask;
reg		    hmask_d;
reg		    safe_zone;  // safe to start
reg		    lsafe_zone; // safe to line write

reg	[1:0]   reading_clk;
reg		    rd_rdy_clk;

wire [8:0]	c_addr ;
wire		c_we   ;

wire [9:0]	b_wdata;
wire [9:0]	b_rdata;
reg	 [9:0]	b_accu;
wire [9:0]	ro_data;
reg	 [8:0]	ro_addr ;

// line buffer signals for readout
reg			rd_rdy_pclk;
reg			rd_rdy_pclk_d;

reg	[1:0]	do_d;
reg			reading;

reg			lsafe_zone_d;
reg	[3:0]	lsafe_zone_clk;

reg	[1:0]	color_sel;   // 2'b11 for idle wait
reg	[7:0]	sel_channel;

wire[7:0]	off_b;

reg	[31:0]	word_lat;
reg		    word_val;
reg	[7:0]	byte_cnt;
reg	[7:0]	line_cnt;
reg			do_trans_pclk;
reg			do_trans_clk;
reg	[1:0]	do_trans_aclk;
reg	[2:0]	trans_done_pclk;
reg			trans_done_aclk;
reg	[2:0]	trans_done_clk;
// internal output signal
reg			r_we;
// AXI BUS
wire [31:0]	fifo_in   ;
wire		fifo_wr   ;
wire	    fifo_rd   ;
reg			fifo_vld  ;
wire [63:0]	fifo_out  ;
wire		fifo_full ;
wire		fifo_afull;
wire		fifo_empty;
wire [8:0]	fifo_rdcnt;
reg	[15:0]	wcnt;

reg			cmd_accepted;
reg	[2:0]	cmd_seq;	
			        
reg	[2:0]	cmd_seq_d;
reg	[7:0]	line_cnt_aclk;

reg	[15:0]	addr_lsb;
reg			running;
wire [15:0]	next_addr;

assign bpcnt_p1 = bpcnt + 8'd1;
assign blcnt_p1 = blcnt + 8'd1;

assign bp_last = (bpcnt_p1 == block_size);
assign bl_last = (blcnt_p1 == block_size);
assign c_addr  = c_we ? {1'b0, wbcnt} : {1'b0, rbcnt};
assign c_we    = (wbcnt != 8'hff) && (bpcnt == 8'd0);
assign b_wdata = b_accu;
assign wbcnt = rbcnt - 8'd1;
assign fifo_in = word_lat;
assign fifo_wr = word_val;
// AXI BUS
// Write bus constant
assign AWID     = 0;
assign WID      = 0;
assign AWREGION = 4'b0;
assign AWPROT   = 3'b0;
assign AWQOS    = 4'b0;
assign AWSIZE   = 3'b011; // 64 bits
assign AWLOCK   = 1'b0;
assign AWBURST  = 2'b01;  // increment
assign AWCACHE  = 4'b0;
assign WSTRB    = 8'hff;
assign BREADY   = 1'b1;   // ignore B channel

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	de_d <= 1'b0;
    else 
	de_d <= i_de;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	pcnt <= 16'b0;
    else 
	pcnt <= i_de ? (pcnt + 16'd1) : 16'b0;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	lcnt <= 16'b0;
    else if(i_vs & ~o_vs_d2)
	lcnt <= 16'b0;
    else if({de_d, i_de} == 2'b10)
	lcnt <= lcnt + 16'd1;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	hmask      <= 1'b0;
	vmask      <= 1'b0;
	safe_zone  <= 1'b0;
	hmask_d    <= 1'b0;
	lsafe_zone <= 1'b0;
	o_mask     <= 1'b0;
    end else begin
	hmask      <= (pcnt >= sb_l) && (pcnt < sb_r) && i_de;
	vmask      <= (lcnt >= vb_u) && (lcnt < vb_b);
	safe_zone  <= (lcnt >= sz_u) || (lcnt < sz_b); // (note sz_u > sz_b)
	hmask_d    <= hmask;
	lsafe_zone <= bl_last & (pcnt > sb_r);
	o_mask     <= hmask & vmask;
    end
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	bpcnt <= 8'd0;
    else if((!hmask) || (!vmask))
	bpcnt <= 8'd0;
    else 
	bpcnt <= bp_last ? 8'd0 : bpcnt_p1;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	rbcnt <= 8'b0;
    else if((!hmask) || (!vmask))
	rbcnt <= 8'b0;
    else if(bpcnt == 8'd0)
	rbcnt <= rbcnt + 8'd1;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	blcnt <= 8'd0;
    else if(!vmask)
	blcnt <= 8'd0;
    else if({de_d, i_de} == 2'b10)
	blcnt <= (blcnt_p1 == block_size) ? 8'd0 : blcnt_p1;
end

// Line buffer

tdpram512x10 u_tdpram(
    .wr_data_a_i (b_wdata   ),
    .wr_data_b_i (10'b0     ),
    .addr_a_i    (c_addr    ),
    .addr_b_i    (ro_addr   ),
    .clk_a_i     (pclk      ),
    .clk_b_i     (clk       ),
    .clk_en_a_i  (1'b1      ),
    .clk_en_b_i  (1'b1      ),
    .wr_en_a_i   (c_we      ),
    .wr_en_b_i   (1'b0      ),
    .rst_a_i     (!resetn   ),
    .rst_b_i     (!resetn   ),
    .rd_data_a_o (b_rdata   ),
    .rd_data_b_o (ro_data   )
);

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	b_accu <= 10'b0;
    end else if(hmask && (bpcnt == 8'd0)) begin // first horizontal pixel
	b_accu <= ((blcnt == 8'd0) ? 10'b0 : b_rdata) + {2'b0, b_l};
    end else begin
	b_accu <= b_accu + {2'b0, b_l};
    end
end


always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	rd_rdy_pclk      <= 1'b0;
	rd_rdy_pclk_d    <= 1'b0;
	lsafe_zone_d     <= 1'b0;
	trans_done_pclk  <= 3'd0;
    end else begin
	rd_rdy_pclk_d    <= i_rd_rdy;
	rd_rdy_pclk      <= rd_rdy_pclk_d;
	lsafe_zone_d     <= lsafe_zone;
	trans_done_pclk  <= {trans_done_pclk[1:0],trans_done_clk[2]};
    end
end

always @(posedge clk or negedge resetn)
begin
  if(resetn == 1'b0) begin
	trans_done_clk  <= 3'd0;
        lsafe_zone_clk  <= 4'd0;
  end
  else begin
	trans_done_clk  <= {trans_done_clk[1:0],trans_done_aclk};
        lsafe_zone_clk  <= {lsafe_zone_clk[2:0],lsafe_zone};
  end
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	line_cnt <= 8'b0;
    else if(reading == 1'b0)
	line_cnt <= 8'b0;
    else if({lsafe_zone_d, lsafe_zone} == 2'b01)
	line_cnt <= line_cnt + 8'd1;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	do_d <= 2'b0;
    else 
	do_d <= {do_d[0], (rd_rdy_pclk & safe_zone)};
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	reading <= 1'b0;
    else if(do_d == 2'b01)
	reading <= 1'b1;
    else if((line_cnt == PIC_HEIGHT[7:0]) && trans_done_pclk[2] )
	reading <= 1'b0;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	ro_addr <= 9'b0;
    else if(color_sel == 2'b01)
	ro_addr <= 9'b0;
    else
	ro_addr <= ro_addr + 9'd1;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	color_sel <= 2'b01;
    else if(reading_clk[1] == 1'b0)
	color_sel <= 2'b01;
    else if(lsafe_zone_clk[3:2] == 2'b01)
	color_sel <= 2'b00;
    else if((color_sel != 2'b01) && (ro_addr == (out_width[8:0] + 9'd2)))
	color_sel <= color_sel + 2'd1;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	do_trans_clk <= 1'b0;
    else if(reading_clk[1] == 1'b0)
	do_trans_clk <= 1'b0;
    else if((color_sel == 2'b00) && (ro_addr == (out_width[8:0] + 9'd2)))
	do_trans_clk <= 1'b1;
    else if(trans_done_clk[2])
	do_trans_clk <= 1'b0;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	r_we <= 1'b0;
    else if(ro_addr == 9'h0001) // read latency + output latch - signal delay = 1
	r_we <= 1'b1;
    else if(ro_addr == (out_width[8:0] + 9'd1))
	r_we <= 1'b0;
end

always @(*)
begin
    if(color_sel == 2'b00)
    sel_channel = ro_data[9:2];
end

assign off_b = sel_channel - ((BYTE_MODE == "SIGNED") ? 8'd128 : 8'd0);

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	byte_cnt <= 8'b0;
    else if(do_trans_clk)
	byte_cnt <= 8'b0;
    else if(r_we)
	byte_cnt <= byte_cnt + 8'd1;
end

always @(posedge clk)
begin
    if(r_we)
	word_lat <= {off_b, word_lat[31:8]};
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	word_val <= 1'b0;
    else 
	word_val <= r_we && ((byte_cnt[1:0]) == 2'b11);
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	vs_l_clk <= 1'b0;
    else
	vs_l_clk <= vs_l & ~vs_d3;
end

always @(posedge clk)
begin
    reading_clk <= {reading_clk[0], reading};
    rd_rdy_clk  <= i_rd_rdy;
end

always @(posedge clk or negedge resetn)
begin
    if(resetn == 1'b0)
	o_rd_done <= 1'b0;
    else if(reading_clk == 2'b10)
	o_rd_done <= 1'b1;
    else if((!rd_rdy_clk) || vs_l_clk)
	o_rd_done <= 1'b0;
end

// Write BUS FIFO 

fifo_32in_64out_level u_fifo_32in_64out_level (
    .rst_i         (!resetn   ),
    .rp_rst_i      (!resetn   ),
    .wr_clk_i      (clk      ),
    .rd_clk_i      (ACLK      ),
    .wr_data_i     (fifo_in   ),
    .wr_en_i       (fifo_wr   ),
    .rd_en_i       (fifo_rd   ),
    .rd_data_o     (fifo_out  ),
    .full_o        (fifo_full ),
    .empty_o       (fifo_empty),
    .rd_data_cnt_o (fifo_rdcnt)
);



//wire  [16:0]  rgb_offset;

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)
	do_trans_aclk <= 2'b0;
    else
	do_trans_aclk <= {do_trans_aclk[0], do_trans_clk};
end



always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0) 
	cmd_seq <= 3'b010;
    else if(running == 1'b0)
	cmd_seq <= 3'b010;
    else if(do_trans_aclk == 2'b01)
	cmd_seq <= 3'b000;
    else if(WLAST & WVALID & WREADY)
	cmd_seq <= cmd_seq + /*(split_flag ? 3'd1 : */3'd2/*)*/;
end


always @(posedge ACLK)
begin
    cmd_seq_d     <= cmd_seq;
    running       <= reading;
    line_cnt_aclk <= line_cnt;
end

assign next_addr = cmd_seq[0] ? {addr_lsb[15:12] + 4'd1, 12'b0} : addr_lsb;

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	AWADDR <= 32'b0;
    else    
	AWADDR <= HYPERRAM_BASEADDR + next_addr;    
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	addr_lsb <= 16'b0;
    else if(running == 1'b0)
	addr_lsb <= 16'b0;
    else if((cmd_seq[2:1] == 2'b01) && (cmd_seq_d[2:1] == 2'b00))
	addr_lsb <= addr_lsb + PIC_WIDTH[15:0];
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	trans_done_aclk <= 1'b0;
    else if(do_trans_aclk[0] == 0)
	trans_done_aclk <= 1'b0;
    else if((cmd_seq[2:1] == 2'b01) && (cmd_seq_d[2:1] == 2'b00))
	trans_done_aclk <= 1'b1;
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	AWVALID <= 1'b0;
    else if ((cmd_seq_d != cmd_seq) && (cmd_seq[2:1] != 2'b01))
	AWVALID <= 1'b1;
    else if(AWREADY) 
	AWVALID <= 1'b0;
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	AWLEN <= 8'd0;
    else if ((cmd_seq_d != cmd_seq) && (cmd_seq[2:1] != 2'b01))
	AWLEN <= /*split_flag ? (cmd_seq[0] ? remainder[7:0] : page_boundary[7:0]) :*/ ((PIC_WIDTH[7:0]/8) - 8'd1); // 28 beat per color component
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	wcnt <= 16'b0;
    else if(AWVALID && AWREADY)
	wcnt <= {8'b0, AWLEN};
    else if((wcnt > 0) & WVALID & WREADY)
	wcnt <= wcnt - 16'd1;
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	cmd_accepted <= 1'b0;
    else if(AWVALID & AWREADY)
	cmd_accepted <= 1'b1;
    else if(((wcnt == 16'd1) & WVALID & WREADY) || ((wcnt == 16'd0) & WVALID & (WREADY == 1'b0)))
	cmd_accepted <= 1'b0;
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	fifo_vld <= 1'b0;
    else if(fifo_rd)
	fifo_vld <= !fifo_empty;
end

assign fifo_rd = (((!fifo_empty) & (!fifo_vld)) || 
                  (fifo_vld && (!WVALID))      || 
		  (WVALID & WREADY))             & cmd_accepted;

always @(posedge ACLK)
begin
    if(fifo_rd)
	WDATA <= fifo_out;
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	WLAST <= 1'b0;
    else if((wcnt == 16'd1) & WVALID & WREADY)
	WLAST <= 1'b1;
    else if((wcnt == 16'd0) & WVALID & (WREADY == 1'b0))
	WLAST <= 1'b1;
    else
	WLAST <= 1'b0;
end

always @(posedge ACLK or negedge ARESETn)
begin
    if(ARESETn == 1'b0)         
	WVALID <= 1'b0;
    else if(fifo_rd) 
	WVALID <= fifo_vld;
    else if(WREADY)
	WVALID <= 1'b0;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	hs_l     <= 1'b0;
	vs_l     <= 1'b0;
	de_l     <= 1'b0;
	o_hs_d2  <= 1'b0;
	o_vs_d2  <= 1'b0;
	o_de_d2  <= 1'b0;
    end else begin
	hs_l     <= i_hs;
	vs_l     <= i_vs;
	de_l     <= i_de;
	o_hs_d2  <= hs_l;
	o_vs_d2  <= vs_l;
	o_de_d2  <= de_l;
	vs_d3	 <= o_vs_d2;
    end
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	r_l     <= 8'b0;
	g_l     <= 8'b0;
	b_l     <= 8'b0;
	o_r_d2  <= 8'b0;
	o_g_d2  <= 8'b0;
	o_b_d2  <= 8'b0;
    end else begin
	r_l     <= i_r;
	g_l     <= i_g;
	b_l     <= i_b;
	o_r_d2  <= (hmask && vmask) ? r_l : {2'b0, r_l[7:2]};
	o_g_d2  <= (hmask && vmask) ? g_l : {2'b0, g_l[7:2]};
	o_b_d2  <= (hmask && vmask) ? b_l : {2'b0, b_l[7:2]};
    end
end

    ///////////////////// Inference Time //////////////////// 

    generate
    if(EN_INF_TIME == 1'b1)
    begin

    reg         rdy;
    reg         rdy_l2h_r;
    reg         rdy_l2h_rr;
    wire        rdy_l2h;
    wire        rdy_h2l;
    reg  [26:0] count;
    reg  [26:0] cnn_count;
    wire [26:0] count_c;	
    wire [26:0] cnn_count_c;
    reg  [30:0] cnn_adder  ;
    wire [30:0] cnn_adder_c;
    wire [3:0]  frame_counter_c;
    reg  [3:0]  frame_counter;
    wire        count_done;
    wire [26:0] inf_time_c;
    reg  [26:0] inf_time; 
    wire [42:0] inf_time_mult;
    reg  [42:0] inf_time_mult_r;
	wire [42:0] inf_time_ind;
	reg  [42:0] inf_time_ind_r;
	reg	 [15:0] inf_ind_ms_r;
	
	reg [WIDTH-1:0] Res ;
	//wire [WIDTH-1:0] fps_val ;
    reg [WIDTH-1:0] a1,b1;
    reg [WIDTH:0] p1;   
    integer i;
	

    // Averaging Logic for 16 CNN Frames
    always @ (posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        rdy             <= 1'b1; 
        rdy_l2h_r       <= 1'b0;
        rdy_l2h_rr      <= 1'b0;
        frame_counter   <= 4'd0;
        count           <= 27'd0;
        cnn_count       <= 27'd0;     
        cnn_adder       <= 31'd0;     
        inf_time        <= 27'd0;
        inf_time_mult_r <= 43'd0;
		inf_time_ind_r  <= 43'd0;
		inf_ind_ms_r	<= 16'd0;
		end
      else begin
        rdy             <= i_rd_rdy;
        count           <= count_c;
        rdy_l2h_r       <= rdy_l2h ;
        rdy_l2h_rr      <= rdy_l2h_r;
        frame_counter   <= frame_counter_c;
		cnn_count       <= cnn_count_c;
		cnn_adder       <= cnn_adder_c;
        inf_time        <= inf_time_c;
        inf_time_mult_r <= inf_time_mult;
		inf_time_ind_r  <= inf_time_ind;
		inf_ind_ms_r	<= inf_time_ind_ms;
        end
    end

    assign rdy_l2h           =  i_rd_rdy & ~rdy;
    assign rdy_h2l           = ~i_rd_rdy & rdy;

    // Counter to calculate individual frame inference time
    assign count_c           = (o_rd_done & rdy_h2l) ? 27'd1 : (i_rd_rdy) ? count : (count + 27'd1);

    // Store individual cnn frame counter
    assign cnn_count_c       =  rdy_l2h ? count : cnn_count;
    
    // keep adding indiviual cnn frame counter for 16 frames. Then clear to 0
    assign cnn_adder_c       = (count_done)? 31'd0 : (rdy_l2h_r) ? (cnn_adder + {4'd0,cnn_count}) : cnn_adder;

    // Frame counter to calculate CNN frames upto 16 (0 - 15)
    assign frame_counter_c   = (rdy_l2h_rr)? (frame_counter + 4'd1) : frame_counter;

    // Counter addition done when 1ll 16 cnn frame counter values are added and averaged
    assign count_done        = (frame_counter == 4'd15) & (rdy_l2h_rr);

    // Average Inference Time calculated by dividing by 16
    assign inf_time_c        = (count_done)? cnn_adder[30:4] : inf_time;

    // 32 Bit average Inference time in Hex
    assign ind_inf_time_hex  = {5'd0,cnn_count};

    // 32 Bit average Inference time in Hex
    assign avg_inf_time_hex  = {5'd0,inf_time};

    // Inference Time in Mili Second
    assign inf_time_mult     = (inf_time[26:0] * INF_MULT_FAC[15:0]);
    assign inf_time_ms       = {4'd0,inf_time_mult_r[42:31]}; 

//Change
	assign inf_time_ind		= (cnn_count[26:0] * INF_MULT_FAC[15:0]);
	assign inf_time_ind_ms	= {4'd0,inf_time_ind_r[42:31]}; //Individual inf time
	
	//Individual fps = 1000/inf_time_ind_ms;	[1/Individual inf time]
	
	//Division algorithm
	//reg [WIDTH-1:0] A;
//reg [WIDTH-1:0] B;


    always@ (inf_ind_ms_r)//A or B
    begin
        //initialize the variables.
        a1 = 16'd1000;
        b1 = inf_ind_ms_r;
        p1= 0;
        for(i=0;i < WIDTH;i=i+1)    begin //start the for loop
            p1 = {p1[WIDTH-2:0],a1[WIDTH-1]};
            a1[WIDTH-1:1] = a1[WIDTH-2:0];
            p1 = p1-b1;
            if(p1[WIDTH-1] == 1)    begin
                a1[0] = 0;
                p1 = p1 + b1;   end
            else
                a1[0] = 1;
        end
        Res = a1;   
    end 
	
	assign fps_val = Res;

    end
    else
    begin
    
    assign ind_inf_time_hex = 32'd0;
    assign avg_inf_time_hex = 32'd0;
    assign inf_time_ms      = 16'd0;
	assign inf_time_ind_ms  = 16'd0;
	assign fps_val = 16'd0;

    end
    endgenerate


endmodule

// vim:foldmethod=marker:
//
