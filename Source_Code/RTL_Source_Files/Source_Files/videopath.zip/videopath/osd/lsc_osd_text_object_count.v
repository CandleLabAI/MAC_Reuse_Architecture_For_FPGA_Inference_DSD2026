
`timescale 1 ns / 100 ps

module lsc_osd_text	#(parameter	EN_INF_TIME = 1'b0)
(
	input			clk,
	input			pclk,
	input			resetn,
	input			i_de,
	input			i_vsync,
	input	[12:0]	i_addr,		// clk
	input			i_wr,		// clk
	input	[7:0]   i_data,		// ascii data
	input	[11:0]	i_num_obj_0,
	input	[11:0]	i_num_obj_1,
	input	[11:0]	i_num_obj_2,
	input	[11:0]	i_num_obj_3,
	input	[11:0]	i_num_obj_4,
	input   [31:0]	i_inf_time_hex,
    input   [31:0]	i_avg_inf_time_hex,
	input   [15:0]	i_inf_time_ms,
	input	[15:0]  i_inf_time_ind_ms,
	input	[15:0]  i_fps_val,
	output reg     	o_on 
);

	parameter		[7:0]	WIDTH = 8'd40;

	reg	 [12:0]	text_addr;
	wire [7:0]	text_data;
         
	wire [9:0]	font_addr;
	reg	 [12:0]	line_offset;
         
	wire [7:0]	font_bitmap;
	reg	 [7:0]	font_bitmap_l;
	reg  [7:0]   font_bitmap_temp;
         
	reg	 [3:0]	pcnt;
	reg	 [3:0]	lcnt;
         
	reg	 [1:0]	de_d;

	wire [3:0]  w_face_ch0;//Count0
    wire [3:0]  w_face_ch1;
	wire [3:0]  w_face_ch2;
    wire [3:0]  w_face_1_ch0;//Count1
    wire [3:0]  w_face_1_ch1;
	wire [3:0]  w_face_1_ch2;
    wire [3:0]  w_face_2_ch0;//Count2
    wire [3:0]  w_face_2_ch1;
	wire [3:0]  w_face_2_ch2;
    wire [3:0]  w_face_3_ch0;//Count3
    wire [3:0]  w_face_3_ch1;
	wire [3:0]  w_face_3_ch2;
    wire [3:0]  w_face_4_ch0;//Count4
    wire [3:0]  w_face_4_ch1;
	wire [3:0]  w_face_4_ch2;
  
	reg  [6:0]   r_face_ch0;//Count0
    reg  [6:0]   r_face_ch1;
	reg  [6:0]   r_face_ch2;
    reg  [6:0]   r_face_1_ch0;//Count1
    reg  [6:0]   r_face_1_ch1;
	reg  [6:0]   r_face_1_ch2;		
    reg  [6:0]   r_face_2_ch0;//Count2
    reg  [6:0]   r_face_2_ch1;
	reg  [6:0]   r_face_2_ch2;
    reg  [6:0]   r_face_3_ch0;//Count3
    reg  [6:0]   r_face_3_ch1;
	reg  [6:0]   r_face_3_ch2;		
    reg  [6:0]   r_face_4_ch0;//Count4
    reg  [6:0]   r_face_4_ch1;
	reg  [6:0]   r_face_4_ch2;
 
    wire         w_face_ch0_pos;//Count0
    wire         w_face_ch1_pos;
	wire         w_face_ch2_pos;
    wire         w_face_1_ch0_pos;//Count1
    wire         w_face_1_ch1_pos;
	wire         w_face_1_ch2_pos;
    wire         w_face_2_ch0_pos;//Count2
    wire         w_face_2_ch1_pos;
	wire         w_face_2_ch2_pos;
    wire         w_face_3_ch0_pos;//Count3
    wire         w_face_3_ch1_pos;
	wire         w_face_3_ch2_pos;
    wire         w_face_4_ch0_pos;//Count4
    wire         w_face_4_ch1_pos;
	wire         w_face_4_ch2_pos;
 
    reg          r_face_ch0_pos;//Count0
    reg          r_face_ch1_pos;
	reg          r_face_ch2_pos;
    reg          r_face_1_ch0_pos;//Count1
    reg          r_face_1_ch1_pos;
	reg          r_face_1_ch2_pos;
    reg          r_face_2_ch0_pos;//Count2
    reg          r_face_2_ch1_pos;
	reg          r_face_2_ch2_pos;
	reg          r_face_3_ch0_pos;//Count3
    reg          r_face_3_ch1_pos;
	reg          r_face_3_ch2_pos;
    reg          r_face_4_ch0_pos;//Count4
    reg          r_face_4_ch1_pos;
	reg          r_face_4_ch2_pos;	
		
	reg 		 vsync_d1;
	reg 		 vsync_d2;

	wire  [6:0]	 font_char;
	wire  [3:0]  w_fps_ch2;
    wire  [3:0]  w_fps_ch1;
    wire  [3:0]  w_fps_ch0;
    reg   [6:0]  r_fps_ch2;
    reg   [6:0]  r_fps_ch1;
    reg   [6:0]  r_fps_ch0;
    wire         w_fps_ch2_pos;
    wire         w_fps_ch1_pos;
    wire         w_fps_ch0_pos;
    reg          r_fps_ch2_pos;
    reg          r_fps_ch1_pos;
    reg          r_fps_ch0_pos;
	
	assign w_face_ch0	= i_num_obj_0[3:0];
	assign w_face_ch1	= i_num_obj_0[7:4];
	assign w_face_ch2	= i_num_obj_0[11:8];
	
	assign w_face_1_ch0	= i_num_obj_1[3:0];
	assign w_face_1_ch1	= i_num_obj_1[7:4];
	assign w_face_1_ch2	= i_num_obj_1[11:8];
	
	assign w_face_2_ch0	= i_num_obj_2[3:0];
	assign w_face_2_ch1	= i_num_obj_2[7:4];
	assign w_face_2_ch2	= i_num_obj_2[11:8];
	
	assign w_face_3_ch0	= i_num_obj_3[3:0];
	assign w_face_3_ch1	= i_num_obj_3[7:4];
	assign w_face_3_ch2	= i_num_obj_3[11:8];
	
	assign w_face_4_ch0	= i_num_obj_4[3:0];
	assign w_face_4_ch1	= i_num_obj_4[7:4];
	assign w_face_4_ch2	= i_num_obj_4[11:8];
	
	assign font_addr = {font_char, lcnt[3:1]};
	
	assign w_face_ch2_pos	= (text_addr == 13'd1053);
	assign w_face_ch1_pos	= (text_addr == 13'd1054);
	assign w_face_ch0_pos	= (text_addr == 13'd1055);
	assign w_face_1_ch2_pos = (text_addr == 13'd1013);
    assign w_face_1_ch1_pos = (text_addr == 13'd1014);
	assign w_face_1_ch0_pos = (text_addr == 13'd1015);
    assign w_face_2_ch2_pos = (text_addr == 13'd973);
    assign w_face_2_ch1_pos = (text_addr == 13'd974);
	assign w_face_2_ch0_pos = (text_addr == 13'd975);
	assign w_face_3_ch2_pos = (text_addr == 13'd933);
    assign w_face_3_ch1_pos = (text_addr == 13'd934);
	assign w_face_3_ch0_pos = (text_addr == 13'd935);
    assign w_face_4_ch2_pos = (text_addr == 13'd893);
    assign w_face_4_ch1_pos = (text_addr == 13'd894);
	assign w_face_4_ch0_pos = (text_addr == 13'd895);

	always @(posedge pclk or negedge resetn)
	begin
		if (!resetn) begin
			r_face_ch0		<= 7'd0;
			r_face_ch1		<= 7'd0;
			r_face_ch2		<= 7'd0;
			r_face_1_ch0	<= 7'd0;
			r_face_1_ch1	<= 7'd0;
			r_face_1_ch2	<= 7'd0;
			r_face_2_ch0	<= 7'd0;
			r_face_2_ch1	<= 7'd0;
			r_face_2_ch2	<= 7'd0;
			r_face_3_ch0	<= 7'd0;
			r_face_3_ch1	<= 7'd0;
			r_face_3_ch2	<= 7'd0;
			r_face_4_ch0	<= 7'd0;
			r_face_4_ch1	<= 7'd0;
			r_face_4_ch2	<= 7'd0;
			vsync_d1		<= 1'b0;
			vsync_d2		<= 1'b0;
		end
		else begin
			r_face_ch0		<= (w_face_ch0 == 4'd0)? 7'h30 : w_face_ch0 + 7'h30;
			r_face_ch1		<= w_face_ch1 + 7'h30;
			r_face_ch2		<= w_face_ch2 + 7'h30;
			r_face_1_ch0    <= (w_face_1_ch0 == 4'd0)? 7'h30 : w_face_1_ch0 + 7'h30;
			r_face_1_ch1    <= w_face_1_ch1 + 7'h30;
			r_face_1_ch2    <= w_face_1_ch2 + 7'h30;    
			r_face_2_ch0    <= (w_face_2_ch0 == 4'd0)? 7'h30 : w_face_2_ch0 + 7'h30;
			r_face_2_ch1    <= w_face_2_ch1 + 7'h30;
			r_face_2_ch2    <= w_face_2_ch2 + 7'h30;
			r_face_3_ch0    <= (w_face_3_ch0 == 4'd0)? 7'h30 : w_face_3_ch0 + 7'h30;
			r_face_3_ch1    <= w_face_3_ch1 + 7'h30;
			r_face_3_ch2    <= w_face_3_ch2 + 7'h30;    
			r_face_4_ch0    <= (w_face_4_ch0 == 4'd0)? 7'h30 : w_face_4_ch0 + 7'h30;
			r_face_4_ch1    <= w_face_4_ch1 + 7'h30;
			r_face_4_ch2    <= w_face_4_ch2 + 7'h30;			
			vsync_d1		<= i_vsync;
			vsync_d2		<= vsync_d1;
		end
	end

	always @(posedge pclk)
	begin
		de_d <= {de_d[0], i_de};
	end

	always @(posedge pclk)
	begin
		if(i_vsync & ~vsync_d2)
			lcnt <= 4'd0;
		else if(de_d == 2'b10)
			lcnt <= lcnt + 4'd1;
	end

	always @(posedge pclk)
	begin
		if(i_de == 1'b0)
			pcnt <= 4'd0;
		else 
			pcnt <= pcnt + 4'd1;
	end

	always @(posedge pclk)
	begin
		if(i_vsync & ~vsync_d2)
			line_offset <= 13'b0;
		else if((de_d == 2'b10) && (lcnt == 4'hf))
			line_offset <= line_offset + {5'b0, WIDTH};
	end

	always @(posedge pclk)
	begin
		if(i_vsync & ~vsync_d2)
			text_addr <= 13'b0;
		else if(i_de == 1'b0)
			text_addr <= line_offset;
		else if(pcnt == 4'hd)
			text_addr <= text_addr + 13'd1;
	end

	always @(posedge pclk or negedge resetn)
	begin
		if (!resetn) begin
			r_face_ch0_pos		<= 1'b0;
			r_face_ch1_pos		<= 1'b0;
			r_face_ch2_pos		<= 1'b0;
			r_face_1_ch0_pos	<= 1'b0;
			r_face_1_ch1_pos	<= 1'b0;
			r_face_1_ch2_pos	<= 1'b0;
			r_face_2_ch0_pos	<= 1'b0;
			r_face_2_ch1_pos	<= 1'b0;
			r_face_2_ch2_pos	<= 1'b0;
			r_face_3_ch0_pos	<= 1'b0;
			r_face_3_ch1_pos	<= 1'b0;
			r_face_3_ch2_pos	<= 1'b0;
			r_face_4_ch0_pos	<= 1'b0;
			r_face_4_ch1_pos	<= 1'b0;
			r_face_4_ch2_pos	<= 1'b0;

		end
		else begin
			r_face_ch0_pos		<= w_face_ch0_pos;
			r_face_ch1_pos		<= w_face_ch1_pos;
			r_face_ch2_pos		<= w_face_ch2_pos;
			r_face_1_ch0_pos	<= w_face_1_ch0_pos;
			r_face_1_ch1_pos	<= w_face_1_ch1_pos;
			r_face_1_ch2_pos	<= w_face_1_ch2_pos;
			r_face_2_ch0_pos	<= w_face_2_ch0_pos;
			r_face_2_ch1_pos	<= w_face_2_ch1_pos;
			r_face_2_ch2_pos	<= w_face_2_ch2_pos;
			r_face_3_ch0_pos	<= w_face_3_ch0_pos;
			r_face_3_ch1_pos	<= w_face_3_ch1_pos;
			r_face_3_ch2_pos	<= w_face_3_ch2_pos;
			r_face_4_ch0_pos	<= w_face_4_ch0_pos;
			r_face_4_ch1_pos	<= w_face_4_ch1_pos;
			r_face_4_ch2_pos	<= w_face_4_ch2_pos;
		end
	end
	
	always @(posedge pclk)
	begin
		font_bitmap_temp <= {font_bitmap[7:4],font_bitmap[3:0]};
	end
	
	always @(posedge pclk)
	begin
		if(pcnt[3:0] == 4'b0)
			font_bitmap_l <= font_bitmap_temp;
		else if(pcnt[0] == 1'b1)
			font_bitmap_l <= {1'b0, font_bitmap_l[7:1]};
	end

	always @(posedge pclk)
	begin
		o_on <= font_bitmap_l[0];
	end

generate

	if(EN_INF_TIME == 1'b1)	begin

		//MSB Hundreth Position
		assign w_fps_ch2    = (i_fps_val >= 7'd100)? 4'h1  :	 4'h0;

		//Middle Tenth Position
		assign w_fps_ch1	= (i_fps_val >= 7'd100)? 4'h0  : (i_fps_val >= 7'd90)? 4'h9  :
							  (i_fps_val >= 7'd80) ? 4'h8  : (i_fps_val >= 7'd70)? 4'h7  : (i_fps_val >= 7'd60)? 4'h6 :
							  (i_fps_val >= 7'd50) ? 4'h5  : (i_fps_val >= 7'd40)? 4'h4  : (i_fps_val >= 7'd30)? 4'h3 :
							  (i_fps_val >= 7'd20) ? 4'h2  : (i_fps_val >= 7'd10)? 4'h1  : 4'h0;
		//LSB Ones Position	 				  
		assign w_fps_ch0	= (i_fps_val >= 7'd100)? i_fps_val - 7'd100 :(i_fps_val >= 7'd90)? i_fps_val - 7'd90 :
							  (i_fps_val >= 7'd80) ? i_fps_val - 7'd80  :(i_fps_val >= 7'd70)? i_fps_val - 7'd70 :(i_fps_val >= 7'd60)? i_fps_val - 7'd60 :
							  (i_fps_val >= 7'd50) ? i_fps_val - 7'd50  :(i_fps_val >= 7'd40)? i_fps_val - 7'd40 :(i_fps_val >= 7'd30)? i_fps_val - 7'd30 :
							  (i_fps_val >= 7'd20) ? i_fps_val - 7'd20  :(i_fps_val >= 7'd10)? i_fps_val - 7'd10 : i_fps_val;


		always @(posedge pclk or negedge resetn)
		begin
			if (!resetn) begin
				r_fps_ch2		<= 7'h0;
				r_fps_ch1		<= 7'h0;
				r_fps_ch0		<= 7'h0;		
			end
			else begin
				r_fps_ch2		<= w_fps_ch2 + 7'h30;//(w_fps_ch2 == 4'h0)? 7'h0 :
				r_fps_ch1		<= w_fps_ch1 + 7'h30;
				r_fps_ch0		<= w_fps_ch0 + 7'h30;
			end
		end

		always @(posedge pclk or negedge resetn)
		begin
			if (!resetn) begin		
				r_fps_ch2_pos	<= 1'b0;
				r_fps_ch1_pos	<= 1'b0;
				r_fps_ch0_pos	<= 1'b0;
			end
			else begin        
				r_fps_ch2_pos	<= w_fps_ch2_pos;
				r_fps_ch1_pos	<= w_fps_ch1_pos;
				r_fps_ch0_pos	<= w_fps_ch0_pos;
			end
		end

		//FPS
		assign w_fps_ch2_pos			= (text_addr == 13'd1087);
		assign w_fps_ch1_pos			= (text_addr == 13'd1088);
		assign w_fps_ch0_pos			= (text_addr == 13'd1089);

		
		
		assign font_char	=   (r_face_ch0_pos )  ? r_face_ch0   : 
								(r_face_ch1_pos )  ? r_face_ch1   : 
								(r_face_ch2_pos )  ? r_face_ch2   :
								(r_face_1_ch0_pos )? r_face_1_ch0 : 
								(r_face_1_ch1_pos )? r_face_1_ch1 :
								(r_face_1_ch2_pos )? r_face_1_ch2 :
								(r_face_2_ch0_pos )? r_face_2_ch0 :
								(r_face_2_ch1_pos )? r_face_2_ch1 :
								(r_face_2_ch2_pos )? r_face_2_ch2 :	
								(r_face_3_ch0_pos )? r_face_3_ch0 :
								(r_face_3_ch1_pos )? r_face_3_ch1 :
								(r_face_3_ch2_pos )? r_face_3_ch2 :
								(r_face_4_ch0_pos )? r_face_4_ch0 :
								(r_face_4_ch1_pos )? r_face_4_ch1 :
								(r_face_4_ch2_pos )? r_face_4_ch2 :									
							    (r_fps_ch2_pos)    ? r_fps_ch2    :
							    (r_fps_ch1_pos)    ? r_fps_ch1    :
							    (r_fps_ch0_pos)    ? r_fps_ch0    : text_data[6:0];

        
		end

	else  begin  //(if EN_INF_TIME = 1'b0)		

		assign font_char	=   (r_face_ch0_pos )  ? r_face_ch0   : 
								(r_face_ch1_pos )  ? r_face_ch1   : 
								(r_face_ch2_pos )  ? r_face_ch2   :
								(r_face_1_ch0_pos )? r_face_1_ch0 : 
								(r_face_1_ch1_pos )? r_face_1_ch1 :
								(r_face_1_ch2_pos )? r_face_1_ch2 :
								(r_face_2_ch0_pos )? r_face_2_ch0 :
								(r_face_2_ch1_pos )? r_face_2_ch1 :
								(r_face_2_ch2_pos )? r_face_2_ch2 :
								(r_face_3_ch0_pos )? r_face_3_ch0 :
								(r_face_3_ch1_pos )? r_face_3_ch1 :
								(r_face_3_ch2_pos )? r_face_3_ch2 :
								(r_face_4_ch0_pos )? r_face_4_ch0 :
								(r_face_4_ch1_pos )? r_face_4_ch1 :
								(r_face_4_ch2_pos )? r_face_4_ch2 :									
							    (r_fps_ch2_pos)    ? r_fps_ch2    :
							    (r_fps_ch1_pos)    ? r_fps_ch1    :
							    (r_fps_ch0_pos)    ? r_fps_ch0    : text_data[6:0];
	end
endgenerate

	// Font ROM
	rom_8x8font u_rom_8x8font(
		.rd_clk_i   (pclk       ),
		.rd_clk_en_i(1'b1       ),
		.rd_en_i    (1'b1       ),
		.rd_addr_i  (font_addr  ),
		.rst_i      (!resetn    ),
		.rd_data_o  (font_bitmap)
	);

	// Text memory
	dpram8192x8_object_count u_dpram8192x8 (
		.wr_addr_i  (i_addr    ),
		.rd_addr_i  (text_addr ),
		.wr_data_i  (i_data    ),
		.wr_en_i    (i_wr      ),
		.rd_en_i    (1'b1      ),
		.rd_clk_i   (pclk      ),
		.rd_clk_en_i(1'b1      ),
		.rst_i      (!resetn   ),
		.wr_clk_i   (clk      ),
		.wr_clk_en_i(1'b1      ),
		.rd_data_o  (text_data )
	);

endmodule

