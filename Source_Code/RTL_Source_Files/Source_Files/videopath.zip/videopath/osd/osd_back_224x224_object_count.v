`define CT_ALGO
//`define UART_ENABLER
// 224x224 version

module osd_back_224x224_object_count #(parameter EN_INF_TIME  = 1'b0,
						                         TOP_N_DET	= 30,
						                         NUM_CLASS	= 5,
						                         ID_WIDTH = 4'd10 )
(
input								pclk,		// pixel clock
input								clk,		// data out clock
input								resetn,
input	[NUM_CLASS*TOP_N_DET-1:0]	i_cls_bmap,	// class bitmap
input	[TOP_N_DET-1:0]				i_box_vld,	// valid bitmap output
input	[31:0]						i_box_00,	// bounding box coordinate 00
input	[31:0]						i_box_01,	// bounding box coordinate 01
input	[31:0]						i_box_02,	// bounding box coordinate 02
input	[31:0]						i_box_03,	// bounding box coordinate 03
input	[31:0]						i_box_04,	// bounding box coordinate 04
input	[31:0]						i_box_05,	// bounding box coordinate 05
input	[31:0]						i_box_06,	// bounding box coordinate 06
input	[31:0]						i_box_07,	// bounding box coordinate 07
input	[31:0]						i_box_08,	// bounding box coordinate 08
input	[31:0]						i_box_09,	// bounding box coordinate 09
input   [(ID_WIDTH*NUM_CLASS)-1:0]  count_list,
input   [15:0]  					bcd_frame_count,
input   [11:0]  					bcd_class_obj_0,
input   [11:0]  					bcd_x1_0,
input   [11:0]  					bcd_y1_0,
input   [11:0]  					bcd_class_obj_1,
input   [11:0]  					bcd_x1_1,
input   [11:0]  					bcd_y1_1,
input   [31:0] 						ind_inf_time_hex,
input   [31:0] 						avg_inf_time_hex,
input   [15:0] 						inf_time_ms, 
input 	[15:0] 						inf_time_ind_ms,
input	[15:0] 						fps_val,
output reg							o_objdet ,	// object detected
input								i_hs,		// pclk
input								i_vs,		// pclk
input								i_de,		// pclk
input								i_hs_d2,	// pclk
input								i_vs_d2,	// pclk
input								i_de_d2,	// pclk
input	[7:0]						i_r_d2,		// pclk
input	[7:0]						i_g_d2,		// pclk
input	[7:0]						i_b_d2,		// pclk
output      						o_tx_serdata,
output reg							o_hs,		// pclk
output reg							o_vs,		// pclk
output reg							o_de,		// pclk
output reg[7:0]						o_r,		// pclk
output reg[7:0]						o_g,		// pclk
output reg[7:0]						o_b 		// pclk
);

parameter  CLOCKS_PER_BIT = 208;

reg				de_d;
reg 			vs_d1;
reg 			vs_d2;

reg	[15:0]		pcnt; // pixel counter
reg	[15:0]		lcnt; // line counter
reg		        red_on;
reg		        blue_on;
reg		        light_green_on;
reg 	        dark_green_on;
reg 	        pink_on;
wire [4:0]	    num_obj_0;
wire [4:0]	    num_obj_1;
wire [4:0]	    num_obj_2;
wire [4:0]	    num_obj_3;
wire [4:0]	    num_obj_4;

reg [11:0] 		bcd_obj_0;
reg [11:0] 		bcd_obj_1;
reg [11:0] 		bcd_obj_2;
reg [11:0] 		bcd_obj_3;
reg [11:0] 		bcd_obj_4;
wire			text_on;

wire [4:0]      w_num_obj0; 
wire [4:0]      w_num_obj1; 
wire [4:0]      w_num_obj2;
wire [12:0]		text_addr;
wire			text_wr;
wire [7:0]		text_data;

reg 			uart_enabler ;
reg [3:0] 		uart_enabler_reg ;
reg [1:0] 		tx_status_reg ;
reg [6:0] 		uart_119;
reg [3:0] 		read_finish_reg;
reg 			re_en;

wire 			o_tx_status;	
reg 			uart_finish ;
reg 			countflag = 0;
wire  			rx_valid;
wire [7:0]  	rec_data;
wire 			i_rxd;
wire 			i_tx_dvalid;          
reg [7:0] 		i_tx_dvalid_reg; 
reg [3:0] 		read_out_temp;
reg  [7:0] 		read_hex_out;
wire[NUM_CLASS-1:0]	box_obj;

assign i_rxd = o_tx_serdata;

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
    begin
	de_d  <= 1'b0;
	vs_d1 <= 1'b0;
	vs_d2 <= 1'b0;
    end
    else 
    begin
	de_d  <= i_de;
	vs_d1 <= i_vs;
	vs_d2 <= vs_d1; 
    end
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	pcnt <= 16'b0;
    else 
	pcnt <= i_de ? (pcnt + 16'd1) : 16'b0;
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0)
	lcnt <= 16'b0;
    else if(i_vs & ~vs_d2)
	lcnt <= 16'b0;
    else if({de_d, i_de} == 2'b10)
	lcnt <= lcnt + 16'd1;
end

// OSD Text {{{
always @(posedge pclk or negedge resetn)
begin
    if (!resetn)
	o_objdet <= 1'b0;
    else
	o_objdet <= (i_box_vld != 9'h0);
end

//Object count ot bcd
always@(posedge clk or negedge resetn)
begin
	if(!resetn) begin
		bcd_obj_0 <= 12'd0;
		bcd_obj_1 <= 12'd0;
		bcd_obj_2 <= 12'd0;
		bcd_obj_3 <= 12'd0;
		bcd_obj_4 <= 12'd0;
	end
	else begin
		bcd_obj_0 <= bcd(count_list[7:0]);
		bcd_obj_1 <= bcd(count_list[17:10]);
		bcd_obj_2 <= bcd(count_list[27:20]);
		bcd_obj_3 <= bcd(count_list[37:30]);
		bcd_obj_4 <= bcd(count_list[47:40]);
	end
	
end

// output stage {{{
always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	o_hs	<= 1'b0;
	o_vs	<= 1'b0;
	o_de	<= 1'b0;
    end
    else begin
	o_hs	<= i_hs_d2;
	o_vs	<= i_vs_d2;
	o_de	<= i_de_d2;
    end
end

always @(posedge pclk or negedge resetn)
begin
    if (!resetn) begin
	 light_green_on		<= 1'b0;
	 red_on		        <= 1'b0;
	 blue_on	        <= 1'b0;
	 dark_green_on	    <= 1'b0;
	 pink_on            <= 1'b0;
    end
    else begin
	 light_green_on		<= |box_obj[4];//Plus
	 red_on			    <= |box_obj[3];//Traiangle
	 blue_on		    <= |box_obj[2];//square
	 dark_green_on		<= |box_obj[1];//octagen
	 pink_on		    <= |box_obj[0];//Circle
	end
end

always @(posedge pclk or negedge resetn)
begin
    if(resetn == 1'b0) begin
	o_r           <= 8'b0;
	o_g           <= 8'b0;
	o_b           <= 8'b0;
    end else begin
	{o_r,o_g,o_b} <= (text_on )        ? {8'h6a, 8'hde, 8'hca} :
			         (dark_green_on)   ? {8'h00, 8'h00, 8'h00} :
			         (pink_on)         ? {8'hff, 8'hff, 8'hff} :
			         (blue_on)         ? {8'h00, 8'hff, 8'h00} :
			         (red_on  )        ? {8'hff, 8'h00, 8'h00} :
			         (light_green_on)  ? {8'h00, 8'h00, 8'hff} : {8'h7f, 8'h7f, i_b_d2};
    end
end

`ifdef UART_ENABLER

//UART FIFO
//----------------------- UART PART ------------------------------------

always @(posedge pclk or negedge resetn)
begin
	if (!resetn)
		countflag <=0;
	else 
	begin 
        if (read_finish_reg[2] && !read_finish_reg[3]) countflag <= 0;
        else if (i_vs) countflag <= 1;
        else countflag <= countflag;
	end
end

// CDC for UART finished indication 
always@(posedge pclk or negedge resetn)
begin
	if(resetn == 1'b0)
		read_finish_reg <= 4'd0;
	else		
		read_finish_reg <={read_finish_reg[2:0],uart_finish};
end


// CDC for the UART  enable signal

always@(posedge pclk or negedge resetn)
begin
	if (resetn == 1'b0) begin
		uart_enabler_reg <= 4'd0;
		tx_status_reg 	 <= 2'b00;
	end else begin
	  uart_enabler_reg <= {uart_enabler_reg[2:0],countflag};
	  tx_status_reg <= {tx_status_reg[0],o_tx_status};
	end
end

// Enable UART 119 times  
always@(posedge pclk or negedge resetn)
begin
	if (resetn == 1'b0) begin
		re_en <= 1'b0;
		uart_finish <= 1'b0;
		uart_119<= 7'd0;
	end else begin
		if(uart_enabler_reg[3:2] == 2'b01) begin                                  
		   re_en <= 1; uart_119<= 0; uart_finish <= 0;	 
	end else if(uart_119== 7'd123 && tx_status_reg == 2'b10 )  begin 										         
		   re_en <= 0;  uart_finish <= 1; //uart_119<= 0;
	end else if (tx_status_reg == 2'b10 && uart_119!=7'd123 ) begin  
		   re_en <= 1; uart_119<= uart_119+ 7'd1;  
	end else begin
		   re_en <= 0; 
		end	
	end
end      

always@(posedge pclk or negedge resetn)	
begin
   if(resetn == 1'b0)
	   i_tx_dvalid_reg <= 7'd0;
   else	   
	   i_tx_dvalid_reg <= {i_tx_dvalid_reg[6:0],re_en};
end

assign i_tx_dvalid = i_tx_dvalid_reg[7];  // To compensate the latency created from reading from the memory


// =======UART_transmission RTL =================
 //    uart reception written into memory
always@(posedge pclk or negedge resetn)
begin
	if(resetn == 1'b0)
		read_out_temp <= 4'd0;
	else begin
		if(i_tx_dvalid_reg[2] && uart_119==7'd1)
		  read_out_temp <= 4'd0;
		else if(i_tx_dvalid_reg[2] && uart_119==7'd2)
		  read_out_temp <= bcd_obj_0[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd3)
		  read_out_temp <= bcd_obj_0[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd4)
		  read_out_temp <= bcd_obj_0[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd7)
		  read_out_temp <= 4'd0;
		else if(i_tx_dvalid_reg[2] && uart_119==7'd8)
		  read_out_temp <= bcd_obj_1[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd9)
		  read_out_temp <= bcd_obj_1[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd10)
		  read_out_temp <= bcd_obj_1[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd13)
		  read_out_temp <= 4'd0;
		else if(i_tx_dvalid_reg[2] && uart_119==7'd14)
		  read_out_temp <= bcd_obj_2[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd15)
		  read_out_temp <= bcd_obj_2[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd16)
		  read_out_temp <= bcd_obj_2[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd19)
		  read_out_temp <= 4'd0;
		else if(i_tx_dvalid_reg[2] && uart_119==7'd20)
		  read_out_temp <= bcd_obj_3[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd21)
		  read_out_temp <= bcd_obj_3[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd22)
		  read_out_temp <= bcd_obj_3[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd25)
		    read_out_temp <= 4'd0;
		else if(i_tx_dvalid_reg[2] && uart_119==7'd26)
		  read_out_temp <= bcd_obj_4[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd27)
		  read_out_temp <= bcd_obj_4[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119==7'd28)
		  read_out_temp <= bcd_obj_4[3:0];
        // Box 0 
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd31)//X1_0
		  read_out_temp <= bcd_x1_0[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd32)
		  read_out_temp <= bcd_x1_0[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd33)
		  read_out_temp <= bcd_x1_0[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd34)//Y1_0
		  read_out_temp <= bcd_y1_0[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd35)
		  read_out_temp <= bcd_y1_0[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd36)
		  read_out_temp <= bcd_y1_0[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd37)//X2_0
		  read_out_temp <= bcd_x2_0[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd38)
		  read_out_temp <= bcd_x2_0[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd39)
		  read_out_temp <= bcd_x2_0[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd40)//Y2_0
		  read_out_temp <= bcd_y2_0[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd41)
		  read_out_temp <= bcd_y2_0[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd42)
		  read_out_temp <= bcd_y2_0[3:0];  
		// Box 1
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd45)//X1_1
		  read_out_temp <= bcd_x1_1[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd46)
		  read_out_temp <= bcd_x1_1[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd47)
		  read_out_temp <= bcd_x1_1[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd48)//Y1_1
		  read_out_temp <= bcd_y1_1[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd49)
		  read_out_temp <= bcd_y1_1[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd50)
		  read_out_temp <= bcd_y1_1[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd51)//X2_1
		  read_out_temp <= bcd_x2_1[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd52)
		  read_out_temp <= bcd_x2_1[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd53)
		  read_out_temp <= bcd_x2_1[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd54)//Y2_1
		  read_out_temp <= bcd_y2_1[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd55)
		  read_out_temp <= bcd_y2_1[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd56)
		  read_out_temp <= bcd_y2_1[3:0];
		//Box 2
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd59)//X1_2
		  read_out_temp <= bcd_x1_2[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd60)
		  read_out_temp <= bcd_x1_2[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd61)
		  read_out_temp <= bcd_x1_2[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd62)//Y1_2
		  read_out_temp <= bcd_y1_2[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd63)
		  read_out_temp <= bcd_y1_2[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd64)
		  read_out_temp <= bcd_y1_2[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd65)//X2_2
		  read_out_temp <= bcd_x2_2[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd66)
		  read_out_temp <= bcd_x2_2[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd67)
		  read_out_temp <= bcd_x2_2[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd68)//Y2_2
		  read_out_temp <= bcd_y2_2[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd69)
		  read_out_temp <= bcd_y2_2[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd70)
		  read_out_temp <= bcd_y2_2[3:0];
		// Box 3
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd73)//X1_3
		  read_out_temp <= bcd_x1_3[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd74)
		  read_out_temp <= bcd_x1_3[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd75)
		  read_out_temp <= bcd_x1_3[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd76)//Y1_3
		  read_out_temp <= bcd_y1_3[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd77)
		  read_out_temp <= bcd_y1_3[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd78)
		  read_out_temp <= bcd_y1_3[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd79)//X2_3
		  read_out_temp <= bcd_x2_3[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd80)
		  read_out_temp <= bcd_x2_3[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd81)
		  read_out_temp <= bcd_x2_3[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd82)//Y2_3
		  read_out_temp <= bcd_y2_3[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd83)
		  read_out_temp <= bcd_y2_3[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd84)
		  read_out_temp <= bcd_y2_3[3:0];
		// Box 4
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd87)//X1_4
		  read_out_temp <= bcd_x1_4[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd88)
		  read_out_temp <= bcd_x1_4[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd89)
		  read_out_temp <= bcd_x1_4[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd90)//Y1_4
		  read_out_temp <= bcd_y1_4[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd91)
		  read_out_temp <= bcd_y1_4[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd92)
		  read_out_temp <= bcd_y1_4[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd93)//X2_4
		  read_out_temp <= bcd_x2_4[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd94)
		  read_out_temp <= bcd_x2_4[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd95)
		  read_out_temp <= bcd_x2_4[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd96)//Y2_4
		  read_out_temp <= bcd_y2_4[11:8];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd97)
		  read_out_temp <= bcd_y2_4[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd98)
		  read_out_temp <= bcd_y2_4[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd101) //Class_0
		  read_out_temp <= bcd_class_obj_0[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd102)
		  read_out_temp <= bcd_class_obj_0[3:0]; 
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd105) //Class_1
		  read_out_temp <= bcd_class_obj_1[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd106)
		  read_out_temp <= bcd_class_obj_1[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd109) //Class_2
		  read_out_temp <= bcd_class_obj_2[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd110)
		  read_out_temp <= bcd_class_obj_2[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd113) //Class_3
		  read_out_temp <= bcd_class_obj_3[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd114)
		  read_out_temp <= bcd_class_obj_3[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd117) //Class_4
		  read_out_temp <= bcd_class_obj_4[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd118)
		  read_out_temp <= bcd_class_obj_4[3:0];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd121)//Box_Valid
		  read_out_temp <= bcd_i_box_vld[7:4];
		else if(i_tx_dvalid_reg[2] && uart_119 ==7'd122)//Box_Valid
		  read_out_temp <= bcd_i_box_vld[3:0];
		  
	end
end	

// BCD to ASCII conversion 
always@(posedge pclk or negedge resetn)
begin
	if(resetn == 1'b0)
		read_hex_out <= 8'h23;
	else begin
	
	if( uart_119== 7'd0 || uart_119== 7'd5 )             
           read_hex_out <= 8'h23; //#
	  else if( uart_119== 7'd6 || uart_119== 7'd11 )             
           read_hex_out <= 8'h24; //$
	  else if( uart_119== 7'd12 || uart_119== 7'd17 )
	   read_hex_out <= 8'h40; //@
	  else if( uart_119== 7'd18 || uart_119== 7'd23 )
	   read_hex_out <= 8'h25; //%
	  else if( uart_119== 7'd24 || uart_119== 7'd29 )
	   read_hex_out <= 8'h26; //&
	  else if( uart_119== 7'd30 || uart_119== 7'd43 )
	   read_hex_out <= 8'h41; //A Box0
	  else if( uart_119== 7'd44 || uart_119== 7'd57 )
	   read_hex_out <= 8'h42; //B Box1
	  else if( uart_119== 7'd58 || uart_119== 7'd71 )
	   read_hex_out <= 8'h43; //C Box2
	  else if( uart_119== 7'd72 || uart_119== 7'd85 )
	   read_hex_out <= 8'h44; //D Box3
	  else if( uart_119== 7'd86 || uart_119== 7'd99 )
	   read_hex_out <= 8'h45; //E Box4
	  else if( uart_119== 7'd100 || uart_119== 7'd103)
	   read_hex_out <= 8'h46; //F Class_0
	  else if( uart_119== 7'd104 || uart_119== 7'd107)
	   read_hex_out <= 8'h47; //G Class_1
	  else if( uart_119== 7'd108 || uart_119== 7'd111)
	   read_hex_out <= 8'h48; //H Class_2
	  else if( uart_119== 7'd112 || uart_119== 7'd115)
	   read_hex_out <= 8'h49; //I Class_3
	  else if( uart_119== 7'd116 || uart_119== 7'd119)
	   read_hex_out <= 8'h4A; //J Class_4
	  else if( uart_119== 7'd120 || uart_119== 7'd123)
	   read_hex_out <= 8'h4B; //K Class_4
      else if(i_tx_dvalid_reg[5]) begin
		  case(read_out_temp)
		  4'h0 :  read_hex_out <= 8'h30;
		  4'h1 :  read_hex_out <= 8'h31;
		  4'h2 :  read_hex_out <= 8'h32;
		  4'h3 :  read_hex_out <= 8'h33;
		  4'h4 :  read_hex_out <= 8'h34;
		  4'h5 :  read_hex_out <= 8'h35;
		  4'h6 :  read_hex_out <= 8'h36;
		  4'h7 :  read_hex_out <= 8'h37;
		  4'h8 :  read_hex_out <= 8'h38;
		  4'h9 :  read_hex_out <= 8'h39;		  
		  
		  default: read_hex_out <= 8'h23;
	      endcase
	    end
	end
end

 uart_rx_tx # ( CLOCKS_PER_BIT) uart_rx_tx(
					pclk,
                    i_tx_dvalid,
					read_hex_out,
					o_tx_status,
					o_tx_serdata,
				    i_rxd,
                    rx_valid,
                    rec_data);

`endif

draw_box_simple #(
	.TOP_N_DET		(	TOP_N_DET		),
	.NUM_CLASS		(	NUM_CLASS		)
) u_draw_box_l 		(
    .pclk		    (	pclk			),
    .resetn		    (	resetn			),
    .i_vs		    (	i_vs			),
    .pcnt		    (	pcnt[11:0]		),
    .lcnt		    (	lcnt[11:0]		),
    .i_sb_l		    (	16'd96			),
    .i_sb_r		    (	16'd544			),
    .i_vb_u		    (	16'd16			),
    .i_vb_b		    (	16'd464			),
    .i_cls_bmap		(	i_cls_bmap		),
    .i_box_vld		(	i_box_vld		),
    .i_box_00		(	i_box_00		),
    .i_box_01		(	i_box_01		),
    .i_box_02		(	i_box_02		),
    .i_box_03		(	i_box_03		),
    .i_box_04		(	i_box_04		),
    .i_box_05		(	i_box_05		),
    .i_box_06		(	i_box_06		),
    .i_box_07		(	i_box_07		),
    .i_box_08		(	i_box_08		),
    .i_box_09		(	i_box_09		),
    .o_box_obj		(	box_obj			),
    .o_num_obj_0	(	num_obj_0		),
    .o_num_obj_1	(	num_obj_1		),
    .o_num_obj_2	(	num_obj_2		),
	.o_num_obj_3	(	num_obj_3		),
    .o_num_obj_4	(	num_obj_4		)
);


// OSD Text }}}
lsc_osd_text #(.EN_INF_TIME (EN_INF_TIME))
u_lsc_osd_text(
    .clk				(	clk		    ),
    .pclk				(	pclk		),
    .resetn				(	resetn		),
    .i_de				(	i_de		),
    .i_vsync			(	i_vs		),
    .i_addr				(	text_addr	),
    .i_wr				(	text_wr		),
    .i_data				(	text_data	),
	`ifdef CT_ALGO
	.i_num_obj_0 		(	bcd_obj_4	),
	.i_num_obj_1 		(	bcd_obj_2	),
	.i_num_obj_2		(	bcd_obj_0	),
	.i_num_obj_3 		(	bcd_obj_3	),
	.i_num_obj_4		(	bcd_obj_1	),
    `else
	.i_num_obj_0 		(	{7'd0,num_obj_4}	),
    .i_num_obj_1 		(	{7'd0,num_obj_2}	),
    .i_num_obj_2 		(	{7'd0,num_obj_0}	),
	.i_num_obj_3 		(	{7'd0,num_obj_3}	),
	.i_num_obj_4 		(	{7'd0,num_obj_1}	),
	`endif
	.i_inf_time_hex     (	ind_inf_time_hex   	),
    .i_avg_inf_time_hex (	avg_inf_time_hex   	),
	.i_inf_time_ms      (	inf_time_ms        	),
	.i_inf_time_ind_ms 	(	inf_time_ind_ms		),
	.i_fps_val 			(	fps_val				),
    .o_on				(	text_on				)
);

// output stage }}}
function [11:0]bcd;

input [7:0] decimal;
reg [3:0] h;
reg [3:0] t;
reg [3:0] o;
    
integer i;    
   
   begin
   h = 4'd0;
   t = 4'd0;
   o = 4'd0;
   
   for(i=7;i>=0;i=i-1)
   begin  
   
   if(h>=5)
    h = h+3;
    if(t>=5)
    t = t +3;
    if(o>=5)
    o = o+3;
    
    h = h<< 1;
    h[0] = t[3];
    t = t << 1;
    t[0] = o[3];
    o = o << 1;
    o[0] = decimal[i];
   end
  
    bcd = {h,t,o};
end
endfunction

endmodule

// vim:foldmethod=marker:
//
