
`timescale 1ns/10ps

module draw_box_simple #(parameter	TOP_N_DET	= 30,
					NUM_CLASS	= 3)
(
input		                        pclk,		// pixel clock
input		                        resetn,
input		                        i_vs,		// vertical sync
input	[11:0]	                    pcnt,		// pixel count
input	[11:0]	                    lcnt,		// line count
input	[15:0]	                    i_sb_l,
input	[15:0]	                    i_sb_r,
input	[15:0]	                    i_vb_u,
input	[15:0]	                    i_vb_b,
input	[NUM_CLASS*TOP_N_DET-1:0]	i_cls_bmap,	// class bitmap
input	[9:0]	                    i_box_vld,	// valid bitmap output
input	[31:0]	                    i_box_00,	// bounding box coordinate 00
input	[31:0]	                    i_box_01,	// bounding box coordinate 01
input	[31:0]	                    i_box_02,	// bounding box coordinate 02
input	[31:0]	                    i_box_03,	// bounding box coordinate 03
input	[31:0]	                    i_box_04,	// bounding box coordinate 04
input	[31:0]	                    i_box_05,	// bounding box coordinate 05
input	[31:0]	                    i_box_06,	// bounding box coordinate 06
input	[31:0]	                    i_box_07,	// bounding box coordinate 07
input	[31:0]	                    i_box_08,	// bounding box coordinate 08
input	[31:0]	                    i_box_09,	// bounding box coordinate 09
output reg [NUM_CLASS-1:0] 			o_box_obj,	// pixel timing for box of object			
output reg  [4:0]	                o_num_obj_0,	// number of objects
output reg	[4:0]	                o_num_obj_1,	// number of objects
output reg	[4:0]	                o_num_obj_2	,	// number of objects	
output reg	[4:0]	                o_num_obj_3,	// number of objects
output reg	[4:0]	                o_num_obj_4		// number of objects

);

// internal signals
reg 							vs_d1;
reg 							vs_d2;

reg	 [NUM_CLASS*TOP_N_DET-1:0]	r_cls_bmap;		// class bitmap
wire [NUM_CLASS-1:0]			w_cls_bmap[0:TOP_N_DET-1];	// class bitmap

reg	[10:0]	                    kptr00_x1;
reg	[10:0]	                    kptr00_y1;
reg	[10:0]	                    kptr00_x2;
reg	[10:0]	                    kptr00_y2;
reg	[10:0]	                    kptr01_x1;
reg	[10:0]	                    kptr01_y1;
reg	[10:0]	                    kptr01_x2;
reg	[10:0]	                    kptr01_y2;
reg	[10:0]	                    kptr02_x1;
reg	[10:0]	                    kptr02_y1;
reg	[10:0]	                    kptr02_x2;
reg	[10:0]	                    kptr02_y2;
reg	[10:0]	                    kptr03_x1;
reg	[10:0]	                    kptr03_y1;
reg	[10:0]	                    kptr03_x2;
reg	[10:0]	                    kptr03_y2;
reg	[10:0]	                    kptr04_x1;
reg	[10:0]	                    kptr04_y1;
reg	[10:0]	                    kptr04_x2;
reg	[10:0]	                    kptr04_y2;
reg	[10:0]	                    kptr05_x1;
reg	[10:0]	                    kptr05_y1;
reg	[10:0]	                    kptr05_x2;
reg	[10:0]	                    kptr05_y2;
reg	[10:0]	                    kptr06_x1;
reg	[10:0]	                    kptr06_y1;
reg	[10:0]	                    kptr06_x2;
reg	[10:0]	                    kptr06_y2;
reg	[10:0]	                    kptr07_x1;
reg	[10:0]	                    kptr07_y1;
reg	[10:0]	                    kptr07_x2;
reg	[10:0]	                    kptr07_y2;
reg	[10:0]	                    kptr08_x1;
reg	[10:0]	                    kptr08_y1;
reg	[10:0]	                    kptr08_x2;
reg	[10:0]	                    kptr08_y2;
reg	[10:0]	                    kptr09_x1;
reg	[10:0]	                    kptr09_y1;
reg	[10:0]	                    kptr09_x2;
reg	[10:0]	                    kptr09_y2;
                                
reg	[9:0]	                    box_outer;
reg	[9:0]	                    box_inner;
                                
reg	[9:0]	                    r_box_on_chk;
reg								r_box_obj;

reg	[4:0]	                    w_obj_cnt_0;
reg	[4:0]	                    w_obj_cnt_1;
reg	[4:0]	                    w_obj_cnt_2;
reg	[4:0]	                    w_obj_cnt_3;
reg	[4:0]	                    w_obj_cnt_4;

reg	[TOP_N_DET-1:0]				r_bbox_bmap;	// valid bitmap output
integer 						j1;
integer							i;


always @(posedge pclk or negedge resetn)
	begin
		if (!resetn) begin
			r_bbox_bmap	<= 'h0;
			r_cls_bmap	<= {NUM_CLASS*TOP_N_DET{1'b0}};
		end
		else if (i_vs) begin
			r_bbox_bmap	<= i_box_vld;
			r_cls_bmap	<= i_cls_bmap;
		end
	end

genvar j;

for (j = 0; j < TOP_N_DET; j = j + 1)
		assign w_cls_bmap[j] = r_cls_bmap[(j+1)*NUM_CLASS-1:j*NUM_CLASS];

// *******************************
// box coordinate translation
// *******************************

always @(posedge pclk or negedge resetn)
begin
    if (!resetn) begin
	kptr00_x1	<= 11'b0;
	kptr00_y1	<= 11'b0;
	kptr00_x2	<= 11'b0;
	kptr00_y2	<= 11'b0;
	kptr01_x1	<= 11'b0;
	kptr01_y1	<= 11'b0;
	kptr01_x2	<= 11'b0;
	kptr01_y2	<= 11'b0;
	kptr02_x1	<= 11'b0;
	kptr02_y1	<= 11'b0;
	kptr02_x2	<= 11'b0;
	kptr02_y2	<= 11'b0;
	kptr03_x1	<= 11'b0;
	kptr03_y1	<= 11'b0;
	kptr03_x2	<= 11'b0;
	kptr03_y2	<= 11'b0;
	kptr04_x1	<= 11'b0;
	kptr04_y1	<= 11'b0;
	kptr04_x2	<= 11'b0;
	kptr04_y2	<= 11'b0;
	kptr05_x1	<= 11'b0;
	kptr05_y1	<= 11'b0;
	kptr05_x2	<= 11'b0;
	kptr05_y2	<= 11'b0;
	kptr06_x1	<= 11'b0;
	kptr06_y1	<= 11'b0;
	kptr06_x2	<= 11'b0;
	kptr06_y2	<= 11'b0;
	kptr07_x1	<= 11'b0;
	kptr07_y1	<= 11'b0;
	kptr07_x2	<= 11'b0;
	kptr07_y2	<= 11'b0;
	kptr08_x1	<= 11'b0;
	kptr08_y1	<= 11'b0;
	kptr08_x2	<= 11'b0;
	kptr08_y2	<= 11'b0;
	kptr09_x1	<= 11'b0;
	kptr09_y1	<= 11'b0;
	kptr09_x2	<= 11'b0;
	kptr09_y2	<= 11'b0;
	vs_d1		<= 1'b0;
	vs_d2		<= 1'b0;
    end
    //else if (i_vs & ~vs_d2) begin	// avoid tearing 
    else if (i_vs ) begin	// avoid tearing 
	vs_d1		<= i_vs ;
	vs_d2		<= vs_d1;
	kptr00_x1	<= ({2'b0, i_box_00[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr00_y1	<= ({2'b0, i_box_00[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr00_x2	<= ({2'b0, i_box_00[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr00_y2	<= ({2'b0, i_box_00[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr01_x1	<= ({2'b0, i_box_01[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr01_y1	<= ({2'b0, i_box_01[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr01_x2	<= ({2'b0, i_box_01[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr01_y2	<= ({2'b0, i_box_01[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr02_x1	<= ({2'b0, i_box_02[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr02_y1	<= ({2'b0, i_box_02[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr02_x2	<= ({2'b0, i_box_02[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr02_y2	<= ({2'b0, i_box_02[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr03_x1	<= ({2'b0, i_box_03[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr03_y1	<= ({2'b0, i_box_03[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr03_x2	<= ({2'b0, i_box_03[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr03_y2	<= ({2'b0, i_box_03[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr04_x1	<= ({2'b0, i_box_04[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr04_y1	<= ({2'b0, i_box_04[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr04_x2	<= ({2'b0, i_box_04[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr04_y2	<= ({2'b0, i_box_04[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr05_x1	<= ({2'b0, i_box_05[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr05_y1	<= ({2'b0, i_box_05[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr05_x2	<= ({2'b0, i_box_05[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr05_y2	<= ({2'b0, i_box_05[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr06_x1	<= ({2'b0, i_box_06[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr06_y1	<= ({2'b0, i_box_06[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr06_x2	<= ({2'b0, i_box_06[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr06_y2	<= ({2'b0, i_box_06[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr07_x1	<= ({2'b0, i_box_07[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr07_y1	<= ({2'b0, i_box_07[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr07_x2	<= ({2'b0, i_box_07[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr07_y2	<= ({2'b0, i_box_07[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr08_x1	<= ({2'b0, i_box_08[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr08_y1	<= ({2'b0, i_box_08[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr08_x2	<= ({2'b0, i_box_08[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr08_y2	<= ({2'b0, i_box_08[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr09_x1	<= ({2'b0, i_box_09[ 7: 0], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr09_y1	<= ({2'b0, i_box_09[23:16], 1'h0}  + {1'b0, i_vb_u[10:0]});
	kptr09_x2	<= ({2'b0, i_box_09[15: 8], 1'h0}  + {1'b0, i_sb_l[10:0]});
	kptr09_y2	<= ({2'b0, i_box_09[31:24], 1'h0}  + {1'b0, i_vb_u[10:0]});
    end
end

always @(posedge pclk or negedge resetn)
begin
    if (!resetn) begin
	box_outer	<= 10'h0;
	box_inner	<= 10'h0;
    end
    else begin
	box_outer[0]	<= (pcnt >= ({1'h0, kptr00_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr00_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr00_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr00_y2} + 12'h1));
	box_inner[0]	<= (pcnt >  ({1'h0, kptr00_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr00_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr00_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr00_y2} - 12'h1));
	box_outer[1]	<= (pcnt >= ({1'h0, kptr01_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr01_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr01_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr01_y2} + 12'h1));
	box_inner[1]	<= (pcnt >  ({1'h0, kptr01_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr01_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr01_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr01_y2} - 12'h1));
	box_outer[2]	<= (pcnt >= ({1'h0, kptr02_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr02_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr02_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr02_y2} + 12'h1));
	box_inner[2]	<= (pcnt >  ({1'h0, kptr02_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr02_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr02_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr02_y2} - 12'h1));
	box_outer[3]	<= (pcnt >= ({1'h0, kptr03_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr03_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr03_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr03_y2} + 12'h1));
	box_inner[3]	<= (pcnt >  ({1'h0, kptr03_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr03_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr03_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr03_y2} - 12'h1));
	box_outer[4]	<= (pcnt >= ({1'h0, kptr04_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr04_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr04_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr04_y2} + 12'h1));
	box_inner[4]	<= (pcnt >  ({1'h0, kptr04_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr04_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr04_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr04_y2} - 12'h1));
	box_outer[5]	<= (pcnt >= ({1'h0, kptr05_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr05_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr05_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr05_y2} + 12'h1));
	box_inner[5]	<= (pcnt >  ({1'h0, kptr05_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr05_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr05_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr05_y2} - 12'h1));
	box_outer[6]	<= (pcnt >= ({1'h0, kptr06_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr06_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr06_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr06_y2} + 12'h1));
	box_inner[6]	<= (pcnt >  ({1'h0, kptr06_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr06_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr06_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr06_y2} - 12'h1));
	box_outer[7]	<= (pcnt >= ({1'h0, kptr07_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr07_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr07_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr07_y2} + 12'h1));
	box_inner[7]	<= (pcnt >  ({1'h0, kptr07_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr07_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr07_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr07_y2} - 12'h1));
	box_outer[8]	<= (pcnt >= ({1'h0, kptr08_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr08_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr08_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr08_y2} + 12'h1));
	box_inner[8]	<= (pcnt >  ({1'h0, kptr08_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr08_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr08_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr08_y2} - 12'h1));
	box_outer[9]	<= (pcnt >= ({1'h0, kptr09_x1} - 12'h1)) && (pcnt <= ({1'h0, kptr09_x2} + 12'h1)) &&
			   (lcnt >= ({1'h0, kptr09_y1} - 12'h1)) && (lcnt <= ({1'h0, kptr09_y2} + 12'h1));
	box_inner[9]	<= (pcnt >  ({1'h0, kptr09_x1} + 12'h1)) && (pcnt <  ({1'h0, kptr09_x2} - 12'h1)) &&
			   (lcnt >  ({1'h0, kptr09_y1} + 12'h1)) && (lcnt <  ({1'h0, kptr09_y2} - 12'h1));
    end
end


//wire [24:0] w_cls_bmap_temp;

always @(posedge pclk or negedge resetn)
begin
    if (!resetn) begin
	r_box_on_chk <= 10'h0;
//	o_box_obj    <= 1'b0;
	o_box_obj    <= {NUM_CLASS{1'b0}};
    end
    else begin
	r_box_on_chk <= box_outer & ~box_inner & i_box_vld;
//	o_box_obj    <= |r_box_on_chk;
	if (r_box_on_chk[0])		o_box_obj	<= w_cls_bmap[0]; //w_cls_bmap_temp[4:0];
	else if (r_box_on_chk[1])	o_box_obj	<= w_cls_bmap[1]; //w_cls_bmap_temp[9:5];
	else if (r_box_on_chk[2])	o_box_obj	<= w_cls_bmap[2]; //w_cls_bmap_temp[14:10];
	else if (r_box_on_chk[3])	o_box_obj	<= w_cls_bmap[3]; //w_cls_bmap_temp[19:15];
	else if (r_box_on_chk[4])	o_box_obj	<= w_cls_bmap[4]; //w_cls_bmap_temp[24:20];
	else if (r_box_on_chk[5])	o_box_obj	<= w_cls_bmap[5];
	else if (r_box_on_chk[6])	o_box_obj	<= w_cls_bmap[6];
	else if (r_box_on_chk[7])	o_box_obj	<= w_cls_bmap[7];
	else if (r_box_on_chk[8])	o_box_obj	<= w_cls_bmap[8];
	else if (r_box_on_chk[9])	o_box_obj	<= w_cls_bmap[9];
	else		 	o_box_obj	<= {NUM_CLASS{1'b0}};
    end
end

//assign w_cls_bmap_temp =(i_box_vld[4]) ? {r_cls_bmap[4:0] ,r_cls_bmap[9:5] , r_cls_bmap[14:10], r_cls_bmap[19:15], r_cls_bmap[24:20]} :
                        //(i_box_vld[3]) ? {5'h0            ,r_cls_bmap[4:0] , r_cls_bmap[9:5]  , r_cls_bmap[14:10], r_cls_bmap[19:15]} :
                        //(i_box_vld[2]) ? {5'h0            ,5'h0            , r_cls_bmap[4:0]  , r_cls_bmap[9:5]  , r_cls_bmap[14:10]} :
                        //(i_box_vld[1]) ? {5'h0            ,5'h0            , 5'h0             , r_cls_bmap[4:0]  , r_cls_bmap[9:5]  } :
                        //(i_box_vld[0]) ? {5'h0            ,5'h0            , 5'h0             , 5'h0             , r_cls_bmap[4:0]  } : 25'h0;

//Object counting

	always @(*)
	begin
		w_obj_cnt_0	= 'h0;
		w_obj_cnt_1	= 'h0;
		w_obj_cnt_2	= 'h0;
		w_obj_cnt_3	= 'h0;
		w_obj_cnt_4	= 'h0;

		for (i = 0; i < TOP_N_DET; i = i + 1) begin
			if(i_box_vld[i]) begin
			// if (r_bbox_bmap[i]) begin
				w_obj_cnt_0	= w_obj_cnt_0 + r_cls_bmap[i*NUM_CLASS];
				if(NUM_CLASS>1) begin
					w_obj_cnt_1	= w_obj_cnt_1 + r_cls_bmap[(i*NUM_CLASS)+1];
					w_obj_cnt_2	= w_obj_cnt_2 + r_cls_bmap[(i*NUM_CLASS)+2];
					w_obj_cnt_3	= w_obj_cnt_3 + r_cls_bmap[(i*NUM_CLASS)+3];
					w_obj_cnt_4	= w_obj_cnt_4 + r_cls_bmap[(i*NUM_CLASS)+4]	;				
				end
			end
		end
	end

	always @(posedge pclk or negedge resetn)
	begin
		if (!resetn)
			begin
			o_num_obj_0	<= 5'h0;
			o_num_obj_1	<= 5'h0;
			o_num_obj_2	<= 5'h0;
			o_num_obj_3	<= 5'h0;
			o_num_obj_4	<= 5'h0;
			end
		else
			begin
			o_num_obj_0	<= w_obj_cnt_0;
			o_num_obj_1	<= w_obj_cnt_1;
			o_num_obj_2	<= w_obj_cnt_2;
			o_num_obj_3	<= w_obj_cnt_3;
			o_num_obj_4	<= w_obj_cnt_4;
			end
	end

endmodule
