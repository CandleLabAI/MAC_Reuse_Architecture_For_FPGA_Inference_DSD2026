localparam WADDR_DEPTH = 512;
localparam WDATA_WIDTH = 32;
localparam RADDR_DEPTH = 256;
localparam RDATA_WIDTH = 64;
localparam FIFO_CONTROLLER = "FABRIC";
localparam FORCE_FAST_CONTROLLER = 0;
localparam IMPLEMENTATION = "EBR";
localparam WADDR_WIDTH = 9;
localparam RADDR_WIDTH = 8;
localparam REGMODE = "noreg";
localparam RESETMODE = "sync";
localparam ENABLE_ALMOST_FULL_FLAG = "FALSE";
localparam ALMOST_FULL_ASSERTION = "static-dual";
localparam ALMOST_FULL_ASSERT_LVL = 511;
localparam ALMOST_FULL_DEASSERT_LVL = 510;
localparam ENABLE_ALMOST_EMPTY_FLAG = "FALSE";
localparam ALMOST_EMPTY_ASSERTION = "static-dual";
localparam ALMOST_EMPTY_ASSERT_LVL = 1;
localparam ALMOST_EMPTY_DEASSERT_LVL = 2;
localparam ENABLE_DATA_COUNT_WR = "FALSE";
localparam ENABLE_DATA_COUNT_RD = "TRUE";
localparam FAMILY = "LFCPNX";
`define LFCPNX
`define jd5d00
`define LFCPNX-100
