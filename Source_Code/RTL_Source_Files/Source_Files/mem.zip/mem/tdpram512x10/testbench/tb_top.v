
`ifndef TB_TOP
`define TB_TOP

//==========================================================================
// Module : tb_top
//==========================================================================

`timescale 1ns/1ns

module tb_top();

`include "dut_params.v"

localparam T_BYTE_WIDTH_A = (BYTE_WIDTH_A == 0) ? 1 : BYTE_WIDTH_A;
localparam T_BYTE_WIDTH_B = (BYTE_WIDTH_B == 0) ? 1 : BYTE_WIDTH_B;

reg [ADDR_WIDTH_A-1:0] addr_a_i;
reg [ADDR_WIDTH_B-1:0] addr_b_i;
reg [DATA_WIDTH_A-1:0] wr_data_a_i;
reg [DATA_WIDTH_B-1:0] wr_data_b_i;
reg clk_a_i;
reg clk_b_i;
reg clk_en_a_i;
reg clk_en_b_i;
reg wr_en_a_i;
reg wr_en_b_i;
reg rst_a_i;
reg rst_b_i;
reg [T_BYTE_WIDTH_A-1:0] ben_a_r;
reg [T_BYTE_WIDTH_B-1:0] ben_b_r;

wire [DATA_WIDTH_A-1:0] rd_data_a_o;
wire [DATA_WIDTH_B-1:0]	rd_data_b_o;

wire [T_BYTE_WIDTH_A-1:0] ben_a_i = ben_a_r;
wire [T_BYTE_WIDTH_B-1:0] ben_b_i = ben_b_r;



// ----------------------------
// GSR instance
// ----------------------------
`ifndef iCE40UP
    GSR GSR_INST ( .GSR_N(1'b1), .CLK(1'b0));
`endif

`include "dut_inst.v"

reg [511:0]                 data_in = {512{1'b0}};

genvar din0;
generate
    for(din0 = 0; din0 < 16; din0 = din0 + 1) begin
        always @ (posedge clk_a_i) begin
            data_in[din0*32+31:din0*32] <= $urandom_range({32{1'b0}}, {32{1'b1}});
        end
    end
endgenerate

initial begin
    clk_a_i = 1'b0;
    forever #10 clk_a_i <= ~clk_a_i;
end

initial begin
    clk_b_i = 1'b0;
    forever #10 clk_b_i <= ~clk_b_i;
end

initial begin
    rst_a_i = 1'b1;
    rst_b_i = 1'b1;
    #35;
    rst_a_i = 1'b0;
    rst_b_i = 1'b0;
end

initial begin
    wr_en_a_i <= 1'b0;
    wr_en_b_i <= 1'b0;
    clk_en_a_i <= 1'b0;
    clk_en_b_i <= 1'b0;
    ben_a_r <= {T_BYTE_WIDTH_A{1'b0}};
    ben_b_r <= {T_BYTE_WIDTH_B{1'b0}};
    wr_data_a_i <= {DATA_WIDTH_A{1'b0}};
    wr_data_b_i <= {DATA_WIDTH_B{1'b0}};
    addr_a_i <= {ADDR_WIDTH_A{1'b0}};
    addr_b_i <= {ADDR_WIDTH_B{1'b0}};
end

localparam INIT_EN               = (INIT_MODE == "none") ? 0 : 1;
localparam MAX_DEPTH             = (ADDR_DEPTH_A > ADDR_DEPTH_B) ? ADDR_DEPTH_A : ADDR_DEPTH_B;
localparam USE_DEPTH_A           = ADDR_DEPTH_A;
localparam USE_DEPTH_B           = ADDR_DEPTH_B;
localparam [2:0] SM_IDLE         = 3'b000;
localparam [2:0] SM_INIT_MODE    = 3'b001;
localparam [2:0] SM_WRITE_MODE_A = 3'b010;
localparam [2:0] SM_FIRST_READ   = 3'b011;
localparam [2:0] SM_WRITE_MODE_B = 3'b100;
localparam [2:0] SM_SECOND_READ  = 3'b101;

reg [2:0] current_state;

reg [31:0] counter_a = {32{1'b0}};
reg [31:0] counter_b = {32{1'b0}};

reg allow_check_a = 1'b0;
reg allow_check_b = 1'b0;
reg mem_init_check = 1'b1;
reg mem_pass1_check = 1'b1;
reg mem_pass2_check = 1'b1;

integer i0, i1;
initial begin
    current_state <= (INIT_EN == 1) ?  SM_INIT_MODE : SM_WRITE_MODE_A;
    @(negedge rst_a_i);
    @(posedge clk_a_i);
    if(current_state == SM_INIT_MODE) begin : init_mode
        addr_a_i <= {ADDR_WIDTH_A{1'b0}};
        clk_en_a_i <= 1'b1;
        counter_a <= {32{1'b0}};
        
        addr_b_i <= {ADDR_WIDTH_B{1'b0}};
        clk_en_b_i <= 1'b1;
        counter_b <= {32{1'b0}};
        allow_check_a <= (REGMODE_A == "noreg") ? 1'b1 : 1'b0;
        allow_check_b <= (REGMODE_B == "noreg") ? 1'b1 : 1'b0;
        for(i1 = 0; i1 < MAX_DEPTH; i1 = i1 + 1) begin
            @(posedge clk_a_i);
            allow_check_a <= 1'b1;
            allow_check_b <= 1'b1;
            if(counter_a < USE_DEPTH_A) begin
                addr_a_i <= addr_a_i + 1'b1;
                counter_a <= counter_a + 1'b1;
            end
            else begin
                addr_a_i <= {ADDR_WIDTH_A{1'b0}};
                clk_en_a_i <= 1'b0;
            end
            if(counter_b < USE_DEPTH_B) begin
                addr_b_i <= addr_b_i + 1'b1;
                counter_b <= counter_b + 1'b1;
            end
            else begin
                addr_b_i <= {ADDR_WIDTH_B{1'b0}};
                clk_en_b_i <= 1'b0;
            end
        end
        @(posedge clk_a_i);
        if(REGMODE_A == "reg" || REGMODE_B == "reg") @(posedge clk_a_i);
        if(mem_init_check == 1'b1) begin
            $display("------------------------------------------------------");
            $display("------------ MEMORY INITIALIZATION PASSED ------------");
            $display("------------------------------------------------------");
        end
        else begin
            $display("------------------------------------------------------");
            $display("!!!!!!!!!!!! MEMORY INITIALIZATION FAILED !!!!!!!!!!!!");
            $display("------------------------------------------------------");
        end
        allow_check_a <= 1'b0;
        allow_check_b <= 1'b0;
    end

    current_state <= SM_WRITE_MODE_A;

    addr_a_i <= {ADDR_WIDTH_A{1'b0}};
    wr_en_a_i <= 1'b1;
    clk_en_a_i <= 1'b1;
    ben_a_r <= {T_BYTE_WIDTH_A{1'b1}};
    wr_data_a_i <= data_in[DATA_WIDTH_A-1:0];

    addr_b_i <= {ADDR_WIDTH_B{1'b0}};
    wr_en_b_i <= 1'b0;
    clk_en_b_i <= 1'b0;
    ben_b_r <= {T_BYTE_WIDTH_B{1'b0}};
    wr_data_b_i <= {DATA_WIDTH_B{1'b0}};

    for(i1 = 0; i1 < USE_DEPTH_A; i1 = i1 + 1) begin
        @(posedge clk_a_i);
        addr_a_i <= addr_a_i + 1'b1;
        wr_data_a_i <= data_in[DATA_WIDTH_A-1:0];
        if(BYTE_ENABLE_A == 1) begin
            ben_a_r <= (ben_a_r == {T_BYTE_WIDTH_A{1'b1}}) ?  {{(T_BYTE_WIDTH_A-1){1'b0}}, 1'b1} :
                         (ben_a_r == {T_BYTE_WIDTH_A{1'b0}}) ?  {T_BYTE_WIDTH_A{1'b1}} : (ben_a_r << 1);
        end
    end

    addr_a_i <= {ADDR_WIDTH_A{1'b0}};
    wr_en_a_i <= 1'b0;
    clk_en_a_i <= 1'b0;
    ben_a_r <= {T_BYTE_WIDTH_A{1'b0}};
    wr_data_a_i <= data_in[DATA_WIDTH_A-1:0];

    @(posedge clk_a_i);

    current_state <= SM_FIRST_READ;

    addr_a_i <= {ADDR_WIDTH_A{1'b0}};
    clk_en_a_i <= 1'b1;
    counter_a <= {32{1'b0}};

    addr_b_i <= {ADDR_WIDTH_B{1'b0}};
    clk_en_b_i <= 1'b1;
    counter_b <= {32{1'b0}};
    @(posedge clk_a_i);
    allow_check_a <= (REGMODE_A == "noreg") ? 1'b1 : 1'b0;
    allow_check_b <= (REGMODE_B == "noreg") ? 1'b1 : 1'b0;
    for(i1 = 0; i1 < MAX_DEPTH; i1 = i1 + 1) begin
        @(posedge clk_a_i);
        allow_check_a <= 1'b1;
        allow_check_b <= 1'b1;
        if(counter_a < USE_DEPTH_A) begin
            addr_a_i <= addr_a_i + 1'b1;
            counter_a <= counter_a + 1'b1;
        end
        else begin
            addr_a_i <= {ADDR_WIDTH_A{1'b0}};
            clk_en_a_i <= 1'b0;
        end
        if(counter_b < USE_DEPTH_B) begin
            addr_b_i <= addr_b_i + 1'b1;
            counter_b <= counter_b + 1'b1;
        end
        else begin
            addr_b_i <= {ADDR_WIDTH_B{1'b0}};
            clk_en_b_i <= 1'b0;
        end
    end
    @(posedge clk_a_i);
    if(REGMODE_A == "reg" || REGMODE_B == "reg") @(posedge clk_a_i);
	@(posedge clk_a_i);

    if(mem_pass1_check == 1'b1) begin
        $display("-----------------------------------------------");
        $display("------------ MEMORY WRITE A PASSED ------------");
        $display("-----------------------------------------------");
    end
    else begin
        $display("-----------------------------------------------");
        $display("!!!!!!!!!!!! MEMORY WRITE A FAILED !!!!!!!!!!!!");
        $display("-----------------------------------------------");
    end
    allow_check_a <= 1'b0;
    allow_check_b <= 1'b0;

    current_state <= SM_WRITE_MODE_B;

    addr_a_i <= {ADDR_WIDTH_A{1'b0}};
    wr_en_a_i <= 1'b0;
    clk_en_a_i <= 1'b0;
    ben_a_r <= {T_BYTE_WIDTH_A{1'b0}};
    wr_data_a_i <= {DATA_WIDTH_A{1'b0}};

    addr_b_i <= {ADDR_WIDTH_B{1'b0}};
    wr_en_b_i <= 1'b1;
    clk_en_b_i <= 1'b1;
    ben_b_r <= {T_BYTE_WIDTH_B{1'b1}};
    wr_data_b_i <= data_in[DATA_WIDTH_B-1:0];

    for(i1 = 0; i1 < USE_DEPTH_B; i1 = i1 + 1) begin
        @(posedge clk_b_i);
        addr_b_i <= addr_b_i + 1'b1;
        wr_data_b_i <= data_in[DATA_WIDTH_B-1:0];
        if(BYTE_ENABLE_B == 1) begin
            ben_b_r <= (ben_b_r == {T_BYTE_WIDTH_B{1'b1}}) ?  {{(T_BYTE_WIDTH_B-1){1'b0}}, 1'b1} :
                         (ben_b_r == {T_BYTE_WIDTH_B{1'b0}}) ?  {T_BYTE_WIDTH_B{1'b1}} : (ben_b_r << 1);   
        end
    end

    addr_b_i <= {ADDR_WIDTH_B{1'b0}};
    wr_en_b_i <= 1'b0;
    clk_en_b_i <= 1'b0;
    ben_b_r <= {T_BYTE_WIDTH_B{1'b0}};
    wr_data_b_i <= {DATA_WIDTH_B{1'b0}};

    @(posedge clk_a_i);

    current_state <= SM_SECOND_READ;

    addr_a_i <= {ADDR_WIDTH_A{1'b0}};
    clk_en_a_i <= 1'b1;
    counter_a <= {32{1'b0}};

    addr_b_i <= {ADDR_WIDTH_B{1'b0}};
    clk_en_b_i <= 1'b1;
    counter_b <= {32{1'b0}};

    @(posedge clk_a_i);
    allow_check_a <= (REGMODE_A == "noreg") ? 1'b1 : 1'b0;
    allow_check_b <= (REGMODE_B == "noreg") ? 1'b1 : 1'b0;
    for(i1 = 0; i1 < MAX_DEPTH; i1 = i1 + 1) begin
        @(posedge clk_a_i);
        allow_check_a <= 1'b1;
        allow_check_b <= 1'b1;
        if(counter_a < USE_DEPTH_A) begin
            addr_a_i <= addr_a_i + 1'b1;
            counter_a <= counter_a + 1'b1;
        end
        else begin
            addr_a_i <= {ADDR_WIDTH_A{1'b0}};
            clk_en_a_i <= 1'b0;
        end
        if(counter_b < USE_DEPTH_B) begin
            addr_b_i <= addr_b_i + 1'b1;
            counter_b <= counter_b + 1'b1;
        end
        else begin
            addr_b_i <= {ADDR_WIDTH_B{1'b0}};
            clk_en_b_i <= 1'b0;
        end
    end
    @(posedge clk_a_i);
    if(REGMODE_A == "reg" || REGMODE_B == "reg") @(posedge clk_a_i);
    if(mem_pass2_check == 1'b1) begin
        $display("-----------------------------------------------");
        $display("------------ MEMORY WRITE B PASSED ------------");
        $display("-----------------------------------------------");
    end
    else begin
        $display("-----------------------------------------------");
        $display("!!!!!!!!!!!! MEMORY WRITE B FAILED !!!!!!!!!!!!");
        $display("-----------------------------------------------");
    end
    $display("###############################################");
    $display("## TEST SUMMARY:                                       ");
    if(INIT_EN == 1) begin
        if(mem_init_check == 1'b1) begin
            $display("## MEMORY INITIALIZATION: PASSED");
        end
        else begin
            $display("## MEMORY INITIALIZATION: FAILED");
        end
    end
    else begin
        $display("## MEMORY INITIALIZATION: Not Applicable");
    end
    if(mem_pass1_check == 1'b1) begin
        $display("## WRITE at Port (A) + Dual Port Read: PASSED");
    end
    else begin
        $display("## WRITE at Port (A) + Dual Port Read: FAILED");
    end
    if(mem_pass2_check == 1'b1) begin
        $display("## WRITE at Port (B) + Dual Port Read: PASSED");
    end
    else begin
        $display("## WRITE at Port (B) + Dual Port Read: FAILED");
    end
    $display("###############################################");

    if(mem_pass1_check & mem_pass2_check) begin
        $display("-----------------------------------------------------");
        $display("----------------- SIMULATION PASSED -----------------");
        $display("-----------------------------------------------------");
    end
    else begin
        $display("-----------------------------------------------------");
        $display("!!!!!!!!!!!!!!!!! SIMULATION FAILED !!!!!!!!!!!!!!!!!");
        $display("-----------------------------------------------------");
    end

    allow_check_a <= 1'b0;
    allow_check_b <= 1'b0;
    $finish;
end

reg [DATA_WIDTH_A-1:0] mem [(2**ADDR_WIDTH_A)-1:0];
integer mem_i0, mem_i1;
initial begin 
    if(INIT_MODE == "mem_file") begin
        if(INIT_FILE_FORMAT == "hex") begin
            $readmemh(INIT_FILE, mem, 0, ADDR_DEPTH_A-1);
        end
        else begin
            $readmemb(INIT_FILE, mem, 0, ADDR_DEPTH_A-1);
        end
        for(mem_i0 = 0; mem_i0 < (2**ADDR_WIDTH_A); mem_i0 = mem_i0 + 1) begin
            if(mem[i0] == {DATA_WIDTH_A{1'bx}} && FAMILY != "common") begin
                mem[i0] = {DATA_WIDTH_A{1'b0}};
            end
        end
    end
    else if(FAMILY != "common") begin
        for(mem_i0 = 0; mem_i0 < (2**ADDR_WIDTH_A); mem_i0 = mem_i0 + 1) begin
            mem[mem_i0] = (INIT_MODE == "all_one") ? {DATA_WIDTH_A{1'b1}} : {DATA_WIDTH_A{1'b0}};
        end
    end
end

reg [DATA_WIDTH_A-1:0] data_out_a = {DATA_WIDTH_A{1'b0}};
reg [DATA_WIDTH_B-1:0] data_out_b = {DATA_WIDTH_B{1'b0}};

    /*
     *    INITIALIZATION CHECK
     */
    always @ (posedge clk_a_i) begin
        if(current_state == SM_INIT_MODE && clk_en_a_i == 1'b1 && allow_check_a == 1'b1) begin
            if(data_out_a == rd_data_a_o) begin
                $display("DATA_MATCH (port A): Expected DATA = %h, Read DATA = %h", data_out_a, rd_data_a_o);
            end
            else begin
                mem_init_check <= 1'b0;
                $display("DATA_MISMATCH (port A): Expected DATA = %h, Read DATA = %h", data_out_a, rd_data_a_o);
            end
        end
    end

    always @ (posedge clk_b_i) begin
        if(current_state == SM_INIT_MODE && clk_en_b_i == 1'b1 && allow_check_b == 1'b1) begin
            if(data_out_b == rd_data_b_o) begin
                $display("DATA_MATCH (port B): Expected DATA = %h, Read DATA = %h", data_out_b, rd_data_b_o);
            end
            else begin
                mem_init_check <= 1'b0;
                $display("DATA_MISMATCH (port B): Expected DATA = %h, Read DATA = %h", data_out_b, rd_data_b_o);
            end
        end
    end

    /*
     *    FIRST READ (A-WRITE) CHECK
     */
    always @ (posedge clk_a_i) begin
        if(current_state == SM_FIRST_READ && clk_en_a_i == 1'b1 && allow_check_a == 1'b1) begin
            if(data_out_a == rd_data_a_o) begin
                $display("DATA_MATCH (port A): Expected DATA = %h, Read DATA = %h", data_out_a, rd_data_a_o);
            end
            else begin
                mem_pass1_check <= 1'b0;
                $display("DATA_MISMATCH (port A): Expected DATA = %h, Read DATA = %h", data_out_a, rd_data_a_o);
            end
        end
    end

    always @ (posedge clk_b_i) begin
        if(current_state == SM_FIRST_READ && clk_en_b_i == 1'b1 && allow_check_b == 1'b1) begin
            if(data_out_b == rd_data_b_o) begin
                $display("DATA_MATCH (port B): Expected DATA = %h, Read DATA = %h", data_out_b, rd_data_b_o);
            end
            else begin
                mem_pass1_check <= 1'b0;
                $display("DATA_MISMATCH (port B): Expected DATA = %h, Read DATA = %h", data_out_b, rd_data_b_o);
            end
        end
    end

    /*
     *    SECOND READ (B-WRITE) CHECK
     */
    always @ (posedge clk_a_i) begin
        if(current_state == SM_SECOND_READ && clk_en_a_i == 1'b1 && allow_check_a == 1'b1) begin
            if(data_out_a == rd_data_a_o) begin
                $display("DATA_MATCH (port A): Expected DATA = %h, Read DATA = %h", data_out_a, rd_data_a_o);
            end
            else begin
                mem_pass2_check <= 1'b0;
                $display("DATA_MISMATCH (port A): Expected DATA = %h, Read DATA = %h", data_out_a, rd_data_a_o);
            end
        end
    end

    always @ (posedge clk_b_i) begin
        if(current_state == SM_SECOND_READ && clk_en_b_i == 1'b1 && allow_check_b == 1'b1) begin
            if(data_out_b == rd_data_b_o) begin
                $display("DATA_MATCH (port B): Expected DATA = %h, Read DATA = %h", data_out_b, rd_data_b_o);
            end
            else begin
                mem_pass2_check <= 1'b0;
                $display("DATA_MISMATCH (port B): Expected DATA = %h, Read DATA = %h", data_out_b, rd_data_b_o);
            end
        end
    end

genvar ben0, split0;
if(DATA_WIDTH_A == DATA_WIDTH_B) begin : A_EQ_B
    /*
     *    WRITING AT PORT A
     */
    if(BYTE_ENABLE_A == 0) begin
        always @ (posedge clk_a_i) begin
            if(wr_en_a_i == 1'b1 && clk_en_a_i == 1'b1) begin
                mem[addr_a_i] <= wr_data_a_i;
            end
        end
    end
    else begin
        localparam BYTE_SIZE_A = (DATA_WIDTH_A % 9 == 0) ? 9 : 8;
        localparam EQUIV_LEN_A = (DATA_WIDTH_A/BYTE_SIZE_A);
        wire [BYTE_SIZE_A-1:0] act_wr_data_a [EQUIV_LEN_A-1:0];
        wire [DATA_WIDTH_A-1:0] pref_data = mem[addr_a_i];
        for(ben0 = 0; ben0 < EQUIV_LEN_A; ben0 = ben0 + 1) begin
            assign act_wr_data_a [ben0] = (ben_a_r[ben0] == 1'b1) ? (wr_data_a_i[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A]) : 
                                                                (pref_data[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A]);
        end
        wire [DATA_WIDTH_A-1:0] wr_data_a_t_w;
        for(ben0 = 0; ben0 < EQUIV_LEN_A; ben0 = ben0 + 1) begin
            assign wr_data_a_t_w[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A] = act_wr_data_a[ben0];
        end
        always @ (posedge clk_a_i) begin
            if(wr_en_a_i == 1'b1 && clk_en_a_i == 1'b1) begin
                mem[addr_a_i] <= wr_data_a_t_w;
            end
        end
    end

    /*
     *    WRITING AT PORT B
     */
    if(BYTE_ENABLE_B == 0) begin
        always @ (posedge clk_b_i) begin
            if(wr_en_b_i == 1'b1 && clk_en_b_i == 1'b1) begin
                mem[addr_b_i] <= wr_data_b_i;
            end
        end
    end
    else begin
        localparam BYTE_SIZE_B = (DATA_WIDTH_B % 9 == 0) ? 9 : 8;
        localparam EQUIV_LEN_B = (DATA_WIDTH_B/BYTE_SIZE_B);
        wire [BYTE_SIZE_B-1:0] act_wr_data_b [EQUIV_LEN_B-1:0];
        wire [DATA_WIDTH_B-1:0] pref_data = mem[addr_b_i];
        for(ben0 = 0; ben0 < EQUIV_LEN_B; ben0 = ben0 + 1) begin
            assign act_wr_data_b [ben0] = (ben_b_r[ben0] == 1'b1) ? (wr_data_b_i[ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:ben0*BYTE_SIZE_B]) : 
                                                                (pref_data[ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:ben0*BYTE_SIZE_B]);
        end
        wire [DATA_WIDTH_B-1:0] wr_data_b_t_w;
        for(ben0 = 0; ben0 < EQUIV_LEN_B; ben0 = ben0 + 1) begin
            assign wr_data_b_t_w[ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:ben0*BYTE_SIZE_B] = act_wr_data_b[ben0];
        end
        always @ (posedge clk_b_i) begin
            if(wr_en_b_i == 1'b1 && clk_en_b_i == 1'b1) begin
                mem[addr_b_i] <= wr_data_b_t_w;
            end
        end
    end

    /*
     *    READING AT PORT A
     */
    wire [DATA_WIDTH_A-1:0] out_mem_raw_a = (addr_a_i >= ADDR_DEPTH_A) ? ((INIT_MODE == "all_one") ? {DATA_WIDTH_A{1'b1}} : {DATA_WIDTH_A{1'b0}}) : mem[addr_a_i];
    reg [DATA_WIDTH_A-1:0] data_out_buff_a = {DATA_WIDTH_A{1'b0}};
    always @ (posedge clk_a_i) begin
        if(wr_en_a_i == 1'b0 && clk_en_a_i == 1'b1) begin
            data_out_buff_a <= out_mem_raw_a;
        end
    end
    if(REGMODE_A == "noreg") begin
        always @ (*) begin
            data_out_a = data_out_buff_a;
        end        
    end
    else begin
        always @ (posedge clk_a_i) begin
            data_out_a <= data_out_buff_a;
        end
    end

    /*
     *    READING AT PORT B
     */
    wire [DATA_WIDTH_B-1:0] out_mem_raw_b = (addr_b_i >= ADDR_DEPTH_B) ? ((INIT_MODE == "all_one") ? {DATA_WIDTH_B{1'b1}} : {DATA_WIDTH_B{1'b0}}) : mem[addr_b_i];
    reg [DATA_WIDTH_B-1:0] data_out_buff_b = {DATA_WIDTH_B{1'b0}};
    always @ (posedge clk_b_i) begin
        if(wr_en_b_i == 1'b0 && clk_en_b_i == 1'b1) begin
            data_out_buff_b <= out_mem_raw_b;
        end
    end
    if(REGMODE_B == "noreg") begin
        always @ (*) begin
            data_out_b = data_out_buff_b;
        end        
    end
    else begin
        always @ (posedge clk_b_i) begin
            data_out_b <= data_out_buff_b;
        end
    end
end
else if(DATA_WIDTH_A > DATA_WIDTH_B) begin : A_GR_B
    /*
     *    WRITING AT PORT A
     */
    if(BYTE_ENABLE_A == 0) begin
        always @ (posedge clk_a_i) begin
            if(wr_en_a_i == 1'b1 && clk_en_a_i == 1'b1) begin
                mem[addr_a_i] <= wr_data_a_i;
            end
        end
    end
    else begin
        localparam BYTE_SIZE_A = (DATA_WIDTH_A % 9 == 0) ? 9 : 8;
        localparam EQUIV_LEN_A = (DATA_WIDTH_A/BYTE_SIZE_A);
        wire [BYTE_SIZE_A-1:0] act_wr_data_a [EQUIV_LEN_A-1:0];
        wire [DATA_WIDTH_A-1:0] pref_data = mem[addr_a_i];
        for(ben0 = 0; ben0 < EQUIV_LEN_A; ben0 = ben0 + 1) begin
            assign act_wr_data_a [ben0] = (ben_a_r[ben0] == 1'b1) ? (wr_data_a_i[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A]) : 
                                                                (pref_data[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A]);
        end
        wire [DATA_WIDTH_A-1:0] wr_data_a_t_w;
        for(ben0 = 0; ben0 < EQUIV_LEN_A; ben0 = ben0 + 1) begin
            assign wr_data_a_t_w[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A] = act_wr_data_a[ben0];
        end
        always @ (posedge clk_a_i) begin
            if(wr_en_a_i == 1'b1 && clk_en_a_i == 1'b1) begin
                mem[addr_a_i] <= wr_data_a_t_w;
            end
        end
    end
    /*
     *    WRITING AT PORT B
     */
    wire [ADDR_WIDTH_A-1:0] addr_a_eq_wr_w = addr_b_i[ADDR_WIDTH_B-1:ADDR_WIDTH_B-(ADDR_WIDTH_A)];
    wire [ADDR_WIDTH_B-(ADDR_WIDTH_A+1):0] addr_excess_wr_bits = addr_b_i[ADDR_WIDTH_B-(ADDR_WIDTH_A+1):0];
    wire [DATA_WIDTH_A-1:0] data_a_eq_wr_w = mem[addr_a_eq_wr_w];
    reg [DATA_WIDTH_A-1:0] written_data_w = {DATA_WIDTH_A{1'b0}};
    if(BYTE_ENABLE_B == 0) begin
        for(split0 = 0; split0 < 2**(ADDR_WIDTH_B-ADDR_WIDTH_A); split0 = split0 + 1) begin
            always @ (*) begin
                if(addr_excess_wr_bits == split0) begin
                    written_data_w[(split0+1)*DATA_WIDTH_B-1:split0*DATA_WIDTH_B] = wr_data_b_i;
                end
                else begin
                    written_data_w[(split0+1)*DATA_WIDTH_B-1:split0*DATA_WIDTH_B] = data_a_eq_wr_w[(split0+1)*DATA_WIDTH_B-1:split0*DATA_WIDTH_B];
                end
            end
        end
        always @ (posedge clk_b_i) begin
            if(wr_en_b_i == 1'b1 && clk_en_b_i == 1'b1) begin
                mem[addr_a_eq_wr_w] <= written_data_w;
            end
        end
    end
    else begin
        localparam BYTE_SIZE_B = (DATA_WIDTH_B % 9 == 0) ? 9 : 8;
        localparam EQUIV_LEN_B = (DATA_WIDTH_B/BYTE_SIZE_B);
        for(split0 = 0; split0 < 2**(ADDR_WIDTH_B-ADDR_WIDTH_A); split0 = split0 + 1) begin
            for(ben0 = 0; ben0 < EQUIV_LEN_B; ben0 = ben0 + 1) begin
                always @ (*) begin
                    if(addr_excess_wr_bits == split0 && ben_b_r[ben0] == 1'b1) begin
                        written_data_w[split0*DATA_WIDTH_B+ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:split0*DATA_WIDTH_B+ben0*BYTE_SIZE_B] = wr_data_b_i[ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:ben0*BYTE_SIZE_B];
                    end
                    else begin
                        written_data_w[split0*DATA_WIDTH_B+ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:split0*DATA_WIDTH_B+ben0*BYTE_SIZE_B] = data_a_eq_wr_w[split0*DATA_WIDTH_B+ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:split0*DATA_WIDTH_B+ben0*BYTE_SIZE_B];
                    end
                end
            end
        end
        always @ (posedge clk_b_i) begin
            if(wr_en_b_i == 1'b1 && clk_en_b_i == 1'b1) begin
                mem[addr_a_eq_wr_w] <= written_data_w;
            end
        end
    end
    /*
     *    READING AT PORT A
     */
    wire [DATA_WIDTH_A-1:0] out_mem_raw_a = (addr_a_i >= ADDR_DEPTH_A) ? ((INIT_MODE == "all_one") ? {DATA_WIDTH_A{1'b1}} : {DATA_WIDTH_A{1'b0}}) : mem[addr_a_i];
    reg [DATA_WIDTH_A-1:0] data_out_buff_a = {DATA_WIDTH_A{1'b0}};
    always @ (posedge clk_a_i) begin
        if(wr_en_a_i == 1'b0 && clk_en_a_i == 1'b1) begin
            data_out_buff_a <= out_mem_raw_a;
        end
    end
    if(REGMODE_A == "noreg") begin
        always @ (*) begin
            data_out_a = data_out_buff_a;
        end        
    end
    else begin
        always @ (posedge clk_a_i) begin
            data_out_a <= data_out_buff_a;
        end
    end
    /*
     *    READING AT PORT B
     */
    wire [ADDR_WIDTH_A-1:0] addr_a_eq_w = addr_b_i[ADDR_WIDTH_B-1:ADDR_WIDTH_B-(ADDR_WIDTH_A)];
    wire [ADDR_WIDTH_B-(ADDR_WIDTH_A+1):0] addr_excess_bits = addr_b_i[ADDR_WIDTH_B-(ADDR_WIDTH_A+1):0];
    wire [DATA_WIDTH_A-1:0] data_a_eq_w = (addr_a_eq_w >= ADDR_DEPTH_A) ? ((INIT_MODE == "all_one") ? {DATA_WIDTH_A{1'b1}} : {DATA_WIDTH_A{1'b0}}) : mem[addr_a_eq_w];
    wire [DATA_WIDTH_B-1:0] out_mem_raw_b = data_a_eq_w >> (DATA_WIDTH_B*addr_excess_bits);
    reg [DATA_WIDTH_B-1:0] data_out_buff_b = {DATA_WIDTH_B{1'b0}};
    always @ (posedge clk_b_i) begin
        if(wr_en_b_i == 1'b0 && clk_en_b_i == 1'b1) begin
            data_out_buff_b <= out_mem_raw_b;
        end
    end
    if(REGMODE_B == "noreg") begin
        always @ (*) begin
            data_out_b = data_out_buff_b;
        end        
    end
    else begin
        always @ (posedge clk_b_i) begin
            data_out_b <= data_out_buff_b;
        end
    end

end
else begin : A_LT_B

    /*
     *    WRITING AT PORT A
     */
    if(BYTE_ENABLE_A == 0) begin
        always @ (posedge clk_a_i) begin
            if(wr_en_a_i == 1'b1 && clk_en_a_i == 1'b1) begin
                mem[addr_a_i] <= wr_data_a_i;
            end
        end
    end
    else begin
        localparam BYTE_SIZE_A = (DATA_WIDTH_A % 9 == 0) ? 9 : 8;
        localparam EQUIV_LEN_A = (DATA_WIDTH_A/BYTE_SIZE_A);
        wire [BYTE_SIZE_A-1:0] act_wr_data_a [EQUIV_LEN_A-1:0];
        wire [DATA_WIDTH_A-1:0] pref_data = mem[addr_a_i];
        for(ben0 = 0; ben0 < EQUIV_LEN_A; ben0 = ben0 + 1) begin
            assign act_wr_data_a [ben0] = (ben_a_r[ben0] == 1'b1) ? (wr_data_a_i[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A]) : 
                                                                (pref_data[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A]);
        end
        wire [DATA_WIDTH_A-1:0] wr_data_a_t_w;
        for(ben0 = 0; ben0 < EQUIV_LEN_A; ben0 = ben0 + 1) begin
            assign wr_data_a_t_w[ben0*BYTE_SIZE_A+BYTE_SIZE_A-1:ben0*BYTE_SIZE_A] = act_wr_data_a[ben0];
        end
        always @ (posedge clk_a_i) begin
            if(wr_en_a_i == 1'b1 && clk_en_a_i == 1'b1) begin
                mem[addr_a_i] <= wr_data_a_t_w;
            end
        end
    end

    /*
     *    WRITING AT PORT B
     */
    if(BYTE_ENABLE_B == 0) begin
        localparam W_FACTOR = DATA_WIDTH_B/DATA_WIDTH_A;
        wire [ADDR_WIDTH_A-1:0] addr_a_eq_wr_w;
        assign addr_a_eq_wr_w[ADDR_WIDTH_A-1:ADDR_WIDTH_A-ADDR_WIDTH_B] = addr_b_i;
        assign addr_a_eq_wr_w[ADDR_WIDTH_A-ADDR_WIDTH_B-1:0] = {(ADDR_WIDTH_A-ADDR_WIDTH_B){1'b0}};
        for(split0 = 0; split0 < W_FACTOR; split0 = split0 + 1) begin
            always @ (posedge clk_b_i) begin
                if(wr_en_b_i == 1'b1 && clk_en_b_i == 1'b1) begin
                    mem[addr_a_eq_wr_w + split0] <= wr_data_b_i[DATA_WIDTH_A*split0+DATA_WIDTH_A-1:DATA_WIDTH_A*split0];
                end
            end
        end
    end
    else begin
        localparam W_FACTOR = DATA_WIDTH_B/DATA_WIDTH_A;
        localparam BYTE_SIZE_B = (DATA_WIDTH_B % 9 == 0) ? 9 : 8;
        localparam EQUIV_LEN_B = (DATA_WIDTH_B/BYTE_SIZE_B);
        wire [ADDR_WIDTH_A-1:0] addr_a_eq_wr_w;
        assign addr_a_eq_wr_w[ADDR_WIDTH_A-1:ADDR_WIDTH_A-ADDR_WIDTH_B] = addr_b_i;
        assign addr_a_eq_wr_w[ADDR_WIDTH_A-ADDR_WIDTH_B-1:0] = {(ADDR_WIDTH_A-ADDR_WIDTH_B){1'b0}};
        wire [DATA_WIDTH_B-1:0] old_data_w;
        wire [DATA_WIDTH_B-1:0] ben_w;
        for(ben0 = 0; ben0 < EQUIV_LEN_B; ben0 = ben0 + 1) begin
            assign ben_w[ben0*BYTE_SIZE_B+BYTE_SIZE_B-1:ben0*BYTE_SIZE_B] = {BYTE_SIZE_B{ben_b_r[ben0]}};
        end
        for(split0 = 0; split0 < W_FACTOR; split0 = split0 + 1) begin
            assign old_data_w[DATA_WIDTH_A*split0+DATA_WIDTH_A-1:DATA_WIDTH_A*split0] = mem[addr_a_eq_wr_w + split0];
        end
        wire [DATA_WIDTH_B-1:0] towrite_w;
        for(split0 = 0; split0 < DATA_WIDTH_B; split0 = split0 + 1) begin
            assign towrite_w[split0] = (ben_w[split0] == 1'b1) ? wr_data_b_i[split0] : old_data_w[split0];
        end
        for(split0 = 0; split0 < W_FACTOR; split0 = split0 + 1) begin
            always @ (posedge clk_b_i) begin
                if(wr_en_b_i == 1'b1 && clk_en_b_i == 1'b1) begin
                    mem[addr_a_eq_wr_w + split0] <= towrite_w[DATA_WIDTH_A*split0+DATA_WIDTH_A-1:DATA_WIDTH_A*split0];
                end
            end
        end
    end
    /*
     *    READING AT PORT A
     */
    wire [DATA_WIDTH_A-1:0] out_mem_raw_a = (addr_a_i >= ADDR_DEPTH_A) ? ((INIT_MODE == "all_one") ? {DATA_WIDTH_A{1'b1}} : {DATA_WIDTH_A{1'b0}}): mem[addr_a_i];
    reg [DATA_WIDTH_A-1:0] data_out_buff_a = {DATA_WIDTH_A{1'b0}};
    always @ (posedge clk_a_i) begin
        if(wr_en_a_i == 1'b0 && clk_en_a_i == 1'b1) begin
            data_out_buff_a <= out_mem_raw_a;
        end
    end
    if(REGMODE_A == "noreg") begin
        always @ (*) begin
            data_out_a = data_out_buff_a;
        end        
    end
    else begin
        always @ (posedge clk_a_i) begin
            data_out_a <= data_out_buff_a;
        end
    end
    /*
     *    READING AT PORT B
     */
    localparam FACTOR = DATA_WIDTH_B/DATA_WIDTH_A;
    wire [ADDR_WIDTH_A-1:0] addr_a_eq_w;
    assign addr_a_eq_w[ADDR_WIDTH_A-1:ADDR_WIDTH_A-ADDR_WIDTH_B] = addr_b_i;
    assign addr_a_eq_w[ADDR_WIDTH_A-ADDR_WIDTH_B-1:0] = {(ADDR_WIDTH_A-ADDR_WIDTH_B){1'b0}};
    wire [DATA_WIDTH_B-1:0] out_mem_raw_b;
    for(split0 = 0; split0 < FACTOR; split0 = split0 + 1) begin
        assign out_mem_raw_b[DATA_WIDTH_A*split0+DATA_WIDTH_A-1:DATA_WIDTH_A*split0] = (addr_a_eq_w + split0 >= ADDR_DEPTH_A) ? (INIT_MODE == "all_one" ? {DATA_WIDTH_A{1'b1}} : {DATA_WIDTH_A{1'b0}})
                                                                                                                              : mem[addr_a_eq_w + split0];
    end
    reg [DATA_WIDTH_B-1:0] data_out_buff_b = {DATA_WIDTH_B{1'b0}};
    always @ (posedge clk_b_i) begin
        if(wr_en_b_i == 1'b0 && clk_en_b_i == 1'b1) begin
            data_out_buff_b <= out_mem_raw_b;
        end
    end
    if(REGMODE_B == "noreg") begin
        always @ (*) begin
            data_out_b = data_out_buff_b;
        end        
    end
    else begin
        always @ (posedge clk_b_i) begin
            data_out_b <= data_out_buff_b;
        end
    end
end

endmodule
`endif