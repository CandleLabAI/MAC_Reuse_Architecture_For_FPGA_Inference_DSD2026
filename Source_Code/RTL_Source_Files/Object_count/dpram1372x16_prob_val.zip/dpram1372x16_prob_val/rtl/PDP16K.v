`ifdef SIMULATE_RAM
module PDP16K #(parameter DATA_WIDTH_W = 5'd16,
			DATA_WIDTH_R = 5'd16)
(
	input [DATA_WIDTH_W-1:0] DI,
	input [13:0]ADW,
	input [13:0]ADR,
	input CLKW,
	input CLKR,
	input CEW,
	input CER,
	input CSW,
	input CSR,
	input RST,
	output reg [DATA_WIDTH_R-1:0] DO,
	output ONEBITERR,
	output TWOBITERR
);

reg [DATA_WIDTH_W-1:0] mem_arr [0:1371];

always @(posedge CLKW)
	if (CEW && CSW) mem_arr[ADW] <= DI;
always @(posedge CLKR)
	if (CER && CSR) DO <= mem_arr[ADR];

assign ONEBITERR = 1'b0;

assign TWOBITERR = 1'b0;

endmodule

`endif



